# FRTS Weeks 13–19 Interactive Practice Package v0.5

## Contents

1. `01_FRTS_Weeks_13-19_Interactive_Question_Bank_v0.5.json` — canonical source of truth.
2. `02_FRTS_Weeks_13-19_Student_Payload_v0.5.json` — student-facing content only.
3. `03_FRTS_Weeks_13-19_Teacher_Answer_Payload_v0.5.json` — teacher-only answer content.
4. `04_FRTS_Weeks_13-19_Teacher_Answer_Guide_v0.5.md` — full teacher explanations and option rationales.
5. `05_FRTS_Weeks_13-19_Full_Revision_Report_v0.5.md` — findings addressed and unresolved dependencies.
6. `06_FRTS_Weeks_13-19_Stimulus_Diversity_Matrix_v0.5.csv` — 46 stimulus records.
7. `07_FRTS_Weeks_13-19_Item_Semantic_Review_v0.5.csv` — 440 item tracking rows, with targeted revisions distinguished from pending human review.
8. `08_FRTS_Weeks_13-19_Distractor_Audit_v0.5.csv` — 1,760 option rows; only targeted revised items have model scores, others remain unrated.
9. `09_FRTS_Weeks_13-19_Vocabulary_Audit_v0.5.csv` — 140 vocabulary cards and provenance status.
10. `10_FRTS_Weeks_13-19_Curriculum_Traceability_v0.5.csv` — 440 source-mapping rows.
11. `11_FRTS_Weeks_13-19_Cognitive_Difficulty_Distribution_v0.5.csv` — counts by session and overall subset.
12. `12_FRTS_Weeks_13-19_Issue_Register_v0.5.csv` — findings, actions, and open items.
13. `13_FRTS_Weeks_13-19_Research_Register_v0.5.md` — sources and limitations.
14. `14_FRTS_Weeks_13-19_Revision_Log_v0.5.md` — change record.
15. `scripts/validate_package.py`, `scripts/validate_deep_package.py`, `scripts/validate_release.py`, and `VALIDATION_OUTPUT.txt` — structural, JSON Schema, cross-payload, guide, evidence-reference, CSV-count, and leakage checks.
16. `schemas/FRTS_v0.5_Structure_Schema.json` — lightweight structural contract for key structures.
17. `PACKAGE_MANIFEST.sha256` — file integrity hashes.

## Scope

14 sessions; 440 single-select questions; 46 stimuli; 140 vocabulary cards; 56 NEW declarations and 84 RECYCLED declarations. Existing question and stimulus IDs are retained.

## Security

The Student Payload omits teacher-only answer fields. The consuming application must enforce server-side role authorization; client-side hiding is not a security control.

## Release status

`STRUCTURAL_QA_PASS_CONTENT_REVIEW_REQUIRED`. This package is not yet approved for student pilot or production use. Independent human review, owner crosswalk completion, classroom pilot, and technical authorization tests remain required.

## Audit boundary

The semantic-review and distractor CSVs explicitly separate targeted model revisions from independent human review still required. All distractor plausibility scores are `NOT_RATED`. A matching evidence quotation proves only that the quotation exists in the linked text; it does not prove that the quotation entails the answer. The package is not approved for student pilot until two qualified human reviewers sign off and curriculum/vocabulary crosswalk dependencies are supplied.
