# FRTS Weeks 13–19 v0.5 — Research and Curriculum Source Register

## A. Canonical FRTS source hierarchy consulted

| Source | Version/status available | Use in v0.5 | Limitation |
|---|---|---|---|
| FRTS Master Development Plan | v2.0, working draft pending owner review | Week 13–19 scope, question-first, no new strategy phase, evidence/traceability requirements | Not owner-approved or classroom-piloted in available copy |
| Batch 1 Weeks 1–4 Integrated Module | v0.4, revised draft | Reading foundation, question-first, scanning, paraphrase, source alignment | Stable objective/module/teacher lesson IDs are not present |
| Batch 2 Weeks 5–8 Module | v0.1, draft for owner review | Main idea, context clues, reference tracking, inference/evidence | Draft; no classroom pilot evidence |
| Batch 3 Weeks 9–12 Module | v0.3, revised draft | Distractor elimination, reading micro-grammar, integration, text-type simulation | Draft; no classroom pilot evidence |
| FRTS v0.4 bank and audit package | v0.4 | Base content, IDs, item counts, report issues and audit regression list | Previous item validity was not fully established |
| FRTS Technical Specification v1.0 | Referenced by independent audit as approved design baseline | Cognitive-level distribution comparison | Full bank aggregate W1–W12 was not available in this revision run; target cannot be reconciled on W13–W19 subset alone |

## B. External research and guidance actually consulted

1. **Institute of Education Sciences / What Works Clearinghouse.** *Providing Reading Interventions for Students in Grades 4–9* (March 2022). https://ies.ed.gov/ncee/wwc/PracticeGuide/29/Published
   - Relevant points: build word/world knowledge; provide opportunities to ask and answer comprehension questions; teach gist routines; monitor comprehension.
   - Application: preserve the taught reading skills and ensure main-idea/inference items require text-based comprehension rather than vocabulary guessing.
   - Limitation: this is an intervention practice guide, not an FRTS assessment blueprint and not a validation of Question-First as a universal approach.

2. **National Assessment of Educational Progress (NAEP).** *Reading Assessment Framework*. https://www.nationsreportcard.gov/reading/about/framework/
   - Relevant points: distinguishes Locate and Recall, Integrate and Interpret, and Critique and Evaluate cognitive targets.
   - Application: review the actual operation needed to answer an item rather than assign cognitive level from vocabulary or item length.
   - Limitation: NAEP framework categories are a comparison lens, not an automatic FRTS target distribution.

3. **Cambridge English.** *B1 Preliminary for Schools — Exam Format*. https://www.cambridgeenglish.org/exams-and-tests/qualifications/preliminary/format/
   - Relevant points: reading includes real-world notices, messages, and longer texts for main message, detail, and interpretation.
   - Application: supports a range of functional and informational genres.
   - Limitation: no CEFR equivalence or B1 certification is claimed for FRTS.

4. **Berkeley Lab Training.** *Writing Multiple Choice Questions*. https://training.lbl.gov/ehs/training/blt/Resources/MultipleChoice.html
   - Relevant points: align items with learning objectives; use plausible options; keep choices clear and concise; avoid unintended clues from length, grammar, formatting, or language.
   - Application: reconstruct near-equivalent main-idea options and improve option-level rationales.
   - Limitation: general item-writing guidance; not a psychometric standard for this specific program.

5. **Kim, S.K. & Webb, S. (2022).** *The Effects of Spaced Practice on Second Language Learning: A Meta-Analysis*. Language Learning, 72, 269–319. https://doi.org/10.1111/lang.12479
   - Relevant point: spaced practice has benefits in second-language learning.
   - Application: retain cumulative vocabulary recycling as a program design choice.
   - Limitation: it does not validate the exact FRTS ratio of 4 NEW and 6 RECYCLED cards.

## C. Claim boundaries

- Question-First Reading is an FRTS program design choice, not a universal rule asserted by external research.
- The package is not an official TKA English SMP blueprint.
- No CEFR level is certified.
- No psychometric facility, discrimination, reliability, or validity statistics are claimed.
- All external sources above inform editorial decisions; they do not replace owner approval, expert sign-off, or classroom response data.
