#!/usr/bin/env python3
"""Extended structural and cross-file validator; not an academic sign-off."""
import csv,json,re,sys,pathlib,collections
from jsonschema import Draft202012Validator
ROOT=pathlib.Path(__file__).resolve().parents[1]
errors=[]
def j(name):
 try:return json.loads((ROOT/name).read_text(encoding='utf-8'))
 except Exception as e: errors.append(f'JSON {name}: {e}');return None
def c(name):
 try:
  with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 except Exception as e: errors.append(f'CSV {name}: {e}');return []
b=j('01_FRTS_Weeks_13-19_Interactive_Question_Bank_v0.5.json');sp=j('02_FRTS_Weeks_13-19_Student_Payload_v0.5.json');tp=j('03_FRTS_Weeks_13-19_Teacher_Answer_Payload_v0.5.json');sch=j('schemas/FRTS_v0.5_Structure_Schema.json')
if b and sch:
 e=list(Draft202012Validator(sch).iter_errors(b))
 if e: errors += ['Schema '+x.json_path+': '+x.message for x in e[:30]]
else: errors.append('Missing bank/schema for formal schema validation')
if b and sp and tp:
 bs=b['sessions'];ss=sp['sessions'];ts=tp['sessions'];expected=[30,30,30,30,30,30,25,40,25,40,25,40,25,40]
 if [x['session_id'] for x in bs] != [x['session_id'] for x in ss] or [x['session_id'] for x in bs] != [x['session_id'] for x in ts]:errors.append('Session ID/order differs between payloads')
 BQ={};SQ={};TA={};BT={};ST={};vocab=[]
 for i,s in enumerate(bs):
  if len(s.get('questions',[]))!=expected[i] or s.get('target_question_count')!=expected[i]:errors.append(f'{s["session_id"]} question count mismatch')
  for q in s.get('questions',[]):
   if q['id'] in BQ:errors.append('Duplicate bank question '+q['id'])
   BQ[q['id']]=q
  for q in ss[i].get('questions',[]): SQ[q['id']]=q
  for a in ts[i].get('answers',[]): TA[a['question_id']]=a
  for t in s.get('stimuli',[]):
   if t['id'] in BT:errors.append('Duplicate stimulus '+t['id'])
   BT[t['id']]=t
  for t in ss[i].get('stimuli',[]): ST[t['id']]=t
  vs=s.get('vocabulary_targets',[]);vocab.extend(vs)
  n=sum(v.get('status')=='NEW' for v in vs);r=sum(v.get('status')=='RECYCLED' for v in vs)
  if len(vs)!=10 or (n,r)!=(4,6):errors.append(f'{s["session_id"]} vocabulary distribution {n}/{r}')
  if len({re.sub(r'[^a-z]','',v.get('word','').lower()) for v in vs})!=10:errors.append(f'{s["session_id"]} duplicate lemma')
  vf=['word','part_of_speech','english_definition','meaning_id','status','useful_relation','antonym_or_contrast','contextual_example']
  if ss[i].get('vocabulary_targets') != [{k:v.get(k) for k in vf} for v in vs]:errors.append(f'{s["session_id"]} student vocabulary projection mismatch')
  for f in ['week','session_number','title','target_question_count','display_policy']:
   if ss[i].get(f)!=s.get(f):errors.append(f'{s["session_id"]} student metadata mismatch {f}')
  if len(ss[i].get('stimuli',[]))!=len(s.get('stimuli',[])):errors.append(f'{s["session_id"]} student stimulus count mismatch')
  for t in s.get('stimuli',[]):
   x=next((x for x in ss[i].get('stimuli',[]) if x['id']==t['id']),None)
   if not x or x.get('text')!=t.get('text') or x.get('title')!=t.get('title'):errors.append(f'{s["session_id"]} student stimulus projection mismatch {t["id"]}')
 if len(BQ)!=440 or len(BT)!=46:errors.append('Bank totals do not equal 440/46')
 if set(BQ)!=set(SQ):errors.append('Bank/student question IDs differ')
 if set(BQ)!=set(TA):errors.append('Bank/teacher answer IDs differ')
 if set(BT)!=set(ST):errors.append('Bank/student stimulus IDs differ')
 for qid,q in BQ.items():
  sq=SQ.get(qid);a=TA.get(qid);to=q.get('teacher_only',{});opts={o['value']:o['label'] for o in q.get('student',{}).get('options',[])}
  if sq:
   for f in ['type','difficulty','skill','stimulus_id','student']:
    if sq.get(f)!=q.get(f):errors.append(f'{qid} student mismatch {f}')
  if a:
   expected_a={'stimulus_id':q['stimulus_id'],'skill':q.get('skill_id') or q.get('skill'),'difficulty':q.get('difficulty'),
    'correct_value':to.get('correct_value'),'correct_answer':to.get('correct_answer'),'explanation':to.get('explanation'),
    'textual_evidence':to.get('textual_evidence'),'evidence_excerpts':to.get('evidence_excerpts'),
    'option_rationales':to.get('option_rationales'),'distractor_analysis':to.get('distractor_analysis'),
    'error_classifications':to.get('error_classifications'),'semantic_review_status':to.get('semantic_review_status')}
   for f,v in expected_a.items():
    if a.get(f)!=v:errors.append(f'{qid} teacher mismatch {f}')
  if set(opts)!=set('ABCD') or len(set(x.strip().casefold() for x in opts.values()))!=4:errors.append(f'{qid} option labels/text not unique A-D')
  if to.get('correct_value') not in opts or opts.get(to.get('correct_value'))!=to.get('correct_answer'):errors.append(f'{qid} key-option mismatch')
  st=BT.get(q.get('stimulus_id'))
  if not st or not st.get('text','').strip():errors.append(f'{qid} stimulus missing')
  else:
   for ex in to.get('evidence_excerpts',[]):
    if ex not in st['text']:errors.append(f'{qid} evidence excerpt absent from linked stimulus')
  if set(to.get('option_rationales',{}))!=set('ABCD'):errors.append(f'{qid} lacks one or more rationales')
 # Recursive leakage scan.
 forbidden={'teacher_only','correct_value','correct_answer','answer_key','textual_evidence','evidence_excerpts','option_rationales','distractor_analysis','error_classifications','explanation','hidden_score','teacher_lesson_id'}
 def scan(x,p='$'):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in forbidden: errors.append('Student payload forbidden field '+p+'.'+k)
    scan(v,p+'.'+str(k))
  elif isinstance(x,list):
   for i,v in enumerate(x):scan(v,f'{p}[{i}]')
 scan(sp)
 newlem=[re.sub(r'[^a-z]','',v.get('word','').lower()) for v in vocab if v.get('status')=='NEW']
 if len(newlem)!=56 or len(set(newlem))!=56:errors.append('Declared NEW lemma list is not 56 unique entries')
 for tid,t in BT.items():
  actual=len(re.findall(r"\b[\w’'-]+\b",t.get('text','')))
  if actual!=t.get('word_count'):errors.append(f'{tid}: word count field {t.get("word_count")} vs actual {actual}')
# CSV row counts and unique composite sets.
expect={'06_FRTS_Weeks_13-19_Stimulus_Diversity_Matrix_v0.5.csv':46,'07_FRTS_Weeks_13-19_Item_Semantic_Review_v0.5.csv':440,'08_FRTS_Weeks_13-19_Distractor_Audit_v0.5.csv':1760,'09_FRTS_Weeks_13-19_Vocabulary_Audit_v0.5.csv':140,'10_FRTS_Weeks_13-19_Curriculum_Traceability_v0.5.csv':440}
for fn,n in expect.items():
 rows=c(fn)
 if len(rows)!=n:errors.append(f'{fn}: {len(rows)} rows expected {n}')
 if fn.startswith('06_') and len({r['stimulus_id'] for r in rows})!=46:errors.append('Stimulus matrix IDs duplicate')
 if fn.startswith('07_'):
  if len({r['question_id'] for r in rows})!=440:errors.append('Item semantic IDs not unique')
  nrev=sum(r['semantic_review_status'].startswith('TARGETED_MODEL_REVISION_COMPLETED') for r in rows)
  if nrev!=73:errors.append(f'Item-level targeted revision count {nrev}, expected 73')
 if fn.startswith('08_'):
  if len({(r['question_id'],r['option_label']) for r in rows})!=1760:errors.append('Distractor composite key duplicates')
  if any(r['plausibility_score']!='NOT_RATED' for r in rows):errors.append('Distractor scores must remain NOT_RATED pending human rating')
# Teacher guide section-level alignment, not mere ID substring presence.
gp=ROOT/'04_FRTS_Weeks_13-19_Teacher_Answer_Guide_v0.5.md'
if gp.exists() and b:
 guide=gp.read_text(encoding='utf-8');parts=re.split(r'(?=^### (W\d+S\d+-Q\d+) — )',guide,flags=re.M);parsed={}
 for i in range(1,len(parts),2):parsed[parts[i]]=parts[i+1] if i+1<len(parts) else ''
 if len(parsed)!=440:errors.append(f'Teacher guide sections {len(parsed)}, expected 440')
 for qid,q in BQ.items():
  body=parsed.get(qid)
  if body is None:errors.append('Teacher guide missing '+qid);continue
  if f'**Kunci:** {q["teacher_only"]["correct_value"]}. {q["teacher_only"]["correct_answer"]}' not in body:errors.append('Teacher guide key mismatch '+qid)
  if q['student']['question'] not in body:errors.append('Teacher guide stem mismatch '+qid)
  for o in q['student']['options']:
   if f'**{o["value"]}.** {o["label"]}' not in body:errors.append(f'Teacher guide option mismatch {qid} {o["value"]}')
# Residual punctuation artifact.
if b:
 for s in b['sessions']:
  for q in s['questions']:
   vals=[q['teacher_only'].get('explanation','')]+list(q['teacher_only'].get('option_rationales',{}).values())
   if any(re.search(r'[.!?][”"\']\.(?=\s|$)',v) for v in vals):errors.append('Redundant quote stop in '+q['id'])
print('Deep structural/cross-file validation: 14 sessions, 440 questions, 46 stimuli, 140 vocabulary cards; CSV record targets and cross-file projections checked.')
if errors:
 print(f'FAIL — {len(errors)} issue(s)')
 for e in errors[:200]:print('ERROR:',e)
 sys.exit(1)
print('PASS — technical checks only; does not certify semantic validity or student readiness.')
