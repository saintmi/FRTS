#!/usr/bin/env python3
"""Release-accountability checks for FRTS v0.5; not semantic sign-off."""
import csv,json,re,sys,pathlib,collections
from jsonschema import Draft202012Validator
ROOT=pathlib.Path(__file__).resolve().parents[1]
errs=[]
def loadj(n): return json.loads((ROOT/n).read_text(encoding='utf-8'))
def loadc(n):
 with (ROOT/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
b=loadj('01_FRTS_Weeks_13-19_Interactive_Question_Bank_v0.5.json')
schema=loadj('schemas/FRTS_v0.5_Structure_Schema.json')
se=list(Draft202012Validator(schema).iter_errors(b))
if se: errs += [f'JSON_SCHEMA {x.json_path}: {x.message}' for x in se]
q=[q for s in b['sessions'] for q in s['questions']]
st=[t for s in b['sessions'] for t in s['stimuli']]
vm=[(s,v) for s in b['sessions'] for v in s['vocabulary_targets']]
if len(b['sessions'])!=14:errs.append('session_count')
if len(q)!=440:errs.append('question_count')
if len(st)!=46:errs.append('stimulus_count')
if len(vm)!=140:errs.append('vocabulary_count')
qmap={x['id']:x for x in q};tmap={x['id']:x for x in st}
if len(qmap)!=440:errs.append('duplicate_question_id')
if len(tmap)!=46:errs.append('duplicate_stimulus_id')
# Link / answer / evidence / context-vocabulary checks
ex_count=0
ctx=0
for x in q:
 opts={o['value']:o['label'] for o in x['student']['options']};to=x['teacher_only']
 if set(opts)!=set('ABCD'):errs.append('option_labels:'+x['id'])
 if opts.get(to.get('correct_value'))!=to.get('correct_answer'):errs.append('key_option:'+x['id'])
 t=tmap.get(x['stimulus_id'])
 if not t:errs.append('missing_stim:'+x['id']);continue
 for e in to.get('evidence_excerpts',[]):
  ex_count+=1
  if e not in t['text']:errs.append('evidence_missing:'+x['id'])
 if x.get('question_type')=='contextual_vocabulary':
  ctx+=1
  terms=re.findall(r'[“\"]([^”\"]+)[”\"]',x['student']['question'])
  if not any(re.search(r'(?<![a-z])'+re.escape(term.lower())+r'(?![a-z])',t['text'].lower()) for term in terms):errs.append('context_vocab_target_absent:'+x['id'])
# CSV accountability
items=loadc('07_FRTS_Weeks_13-19_Item_Semantic_Review_v0.5.csv')
dist=loadc('08_FRTS_Weeks_13-19_Distractor_Audit_v0.5.csv')
voc=loadc('09_FRTS_Weeks_13-19_Vocabulary_Audit_v0.5.csv')
trace=loadc('10_FRTS_Weeks_13-19_Curriculum_Traceability_v0.5.csv')
if len(items)!=440 or len({r['question_id'] for r in items})!=440:errs.append('item_review_csv_count_or_unique')
rev=sum(r['overall_item_status'].startswith('TARGETED_MODEL_REVISION') for r in items)
if rev!=73:errs.append(f'targeted_item_count:{rev}')
if len(dist)!=1760 or len({(r['question_id'],r['option_label']) for r in dist})!=1760:errs.append('distractor_csv_count_or_unique')
if sum(r['status'].startswith('RATIONALE_REWRITTEN') for r in dist)!=292:errs.append('rewritten_rationales_count')
if sum(r['status']=='HUMAN_REVIEW_REQUIRED' for r in dist)!=1468:errs.append('pending_rationales_count')
if any(r['plausibility_score']!='NOT_RATED' for r in dist):errs.append('plausibility_score_claim')
if len(voc)!=140:errs.append('vocab_csv_count')
if sum(r['status_current']=='NEW' for r in voc)!=56 or sum(r['status_current']=='RECYCLED' for r in voc)!=84:errs.append('new_recycled_counts')
if sum(r['provenance_status']=='TRACEABILITY_UNVERIFIED' for r in voc)!=30:errs.append('unverified_recycled_count')
if sum(r['provenance_status'].startswith('SESSION_REFERENCE_RECORDED') for r in voc)!=54:errs.append('session_reference_count')
if sum(r['status_current']=='NEW' and r['provenance_status'].startswith('NEW_TARGET_IN_CURRENT_SESSION') for r in voc)!=56:errs.append('new_history_caveat_count')
if len(trace)!=440:errs.append('traceability_csv_count')
if sum(not r['learning_objective_id'] for r in trace)!=218:errs.append('missing_LO_count')
if sum(not r['module_section_id'] for r in trace)!=218:errs.append('missing_module_section_count')
if sum(not r['teacher_lesson_id'] for r in trace)!=440:errs.append('missing_teacher_lesson_count')
# Punctuation + exact word counts
for s in b['sessions']:
 for t in s['stimuli']:
  wc=len(re.findall(r"\b[\w’'-]+\b",t['text']))
  if t.get('word_count')!=wc:errs.append('word_count:'+t['id'])
 for x in s['questions']:
  texts=[x['teacher_only'].get('explanation','')]+list(x['teacher_only'].get('option_rationales',{}).values())
  if any(re.search(r'\.\.(?:\s|$)|[.!?][”\"\']\.(?:\s|$)',z) for z in texts):errs.append('punctuation:'+x['id'])
# Current subset distributions
cog=collections.Counter(x.get('cognitive_level') for x in q); diff=collections.Counter(x.get('difficulty') for x in q)
print('FRTS v0.5 release-accountability validation')
print(f'Schema: Draft 2020-12 | questions={len(q)} | stimuli={len(st)} | sessions={len(b["sessions"])} | vocab_cards={len(vm)}')
print(f'Evidence excerpts found in linked stimuli={ex_count} | contextual-vocabulary targets present={ctx}/{ctx}')
print(f'Targeted revised items={rev}/440 | rewritten option rationales=292/1760 | human review required for remaining=1468/1760')
print(f'Vocabulary provenance: NEW history checks=56 pending; RECYCLED session refs=54; RECYCLED unverified=30')
print(f'Curriculum IDs: LO missing=218; module section missing=218; teacher lesson missing=440')
print('Cognitive:',dict(cog),'Difficulty:',dict(diff))
if errs:
 print('FAIL',len(errs));[print('ERROR',e) for e in errs[:100]];sys.exit(1)
print('PASS — counts, schema, evidence-reference presence, contextual vocabulary target presence, revision accounting, provenance caveats, curriculum gaps, word counts, punctuation. This is not semantic or human sign-off.')
