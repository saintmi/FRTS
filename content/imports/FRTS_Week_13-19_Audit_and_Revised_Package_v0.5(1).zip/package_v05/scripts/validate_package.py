#!/usr/bin/env python3
import json, re, sys, hashlib, pathlib, collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
files={
 'bank':ROOT/'01_FRTS_Weeks_13-19_Interactive_Question_Bank_v0.5.json',
 'student':ROOT/'02_FRTS_Weeks_13-19_Student_Payload_v0.5.json',
 'teacher':ROOT/'03_FRTS_Weeks_13-19_Teacher_Answer_Payload_v0.5.json'
}
errors=[]; warnings=[]
def load(k):
 try:return json.load(open(files[k],encoding='utf-8'))
 except Exception as e: errors.append(f'{k} JSON parse error: {e}'); return None
b=load('bank'); sp=load('student'); tp=load('teacher')
if b and sp and tp:
 qs=[]; ts=[]; ss=[]; tqs=[]; sqs=[]; aqs=[]
 for s in b['sessions']:
  qs.extend(s.get('questions',[])); ts.extend(s.get('stimuli',[]))
 for s in sp['sessions']:
  sqs.extend(s.get('questions',[])); ss.extend(s.get('stimuli',[]))
 for s in tp['sessions']:
  aqs.extend(s.get('answers',[]))
 def unique(seq,label):
  if len(seq)!=len(set(seq)):errors.append(f'{label} duplicate IDs: {len(seq)-len(set(seq))}')
 unique([q['id'] for q in qs],'question')
 unique([t['id'] for t in ts],'stimulus')
 if len(b['sessions'])!=14:errors.append(f'bank sessions={len(b["sessions"])} expected 14')
 if len(qs)!=440:errors.append(f'questions={len(qs)} expected 440')
 if len(ts)!=46:errors.append(f'stimuli={len(ts)} expected 46')
 vc=sum(len(s.get('vocabulary_targets',[])) for s in b['sessions'])
 if vc!=140:errors.append(f'vocab cards={vc} expected 140')
 counts=[len(s['questions']) for s in b['sessions']]
 expected=[30,30,30,30,30,30,25,40,25,40,25,40,25,40]
 if counts!=expected:errors.append(f'session counts mismatch: {counts}')
 tmap={t['id']:t for t in ts}; qids={q['id'] for q in qs}; sqids={q['id'] for q in sqs}; aqids={q['question_id'] for q in aqs}
 if qids!=sqids:errors.append(f'student payload ID mismatch missing={len(qids-sqids)} extra={len(sqids-qids)}')
 if qids!=aqids:errors.append(f'teacher payload ID mismatch missing={len(qids-aqids)} extra={len(aqids-qids)}')
 if len(sqs)!=440 or len(aqs)!=440:errors.append('payload counts are not 440')
 for q in qs:
  if q['stimulus_id'] not in tmap:errors.append(f'{q["id"]} missing stimulus {q["stimulus_id"]}');continue
  opts=q['student'].get('options',[]); labels={o['value']:o['label'] for o in opts}
  if len(opts)!=4 or set(labels)!=set('ABCD'):errors.append(f'{q["id"]} does not have exactly A-D options')
  k=q['teacher_only'].get('correct_value')
  if k not in labels:errors.append(f'{q["id"]} key not in options')
  elif q['teacher_only'].get('correct_answer')!=labels[k]:errors.append(f'{q["id"]} correct_answer mismatch')
  for e in q['teacher_only'].get('evidence_excerpts',[]):
   if e not in tmap[q['stimulus_id']]['text']:errors.append(f'{q["id"]} evidence excerpt absent from stimulus')
  for f in ['A','B','C','D']:
   if f not in q['teacher_only'].get('option_rationales',{}):errors.append(f'{q["id"]} missing rationale {f}')
  # This is structural and phrase-presence checking, not semantic entailment.
  if not q['teacher_only'].get('explanation'):errors.append(f'{q["id"]} missing teacher explanation')
 forbidden={'teacher_only','correct_value','correct_answer','answer_key','textual_evidence','evidence_excerpts','option_rationales','distractor_analysis','error_classifications','explanation','hidden_score','teacher_lesson_id'}
 def scan(x,path='$'):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in forbidden:errors.append(f'student payload forbidden field {path}.{k}')
    scan(v,path+'.'+str(k))
  elif isinstance(x,list):
   for i,v in enumerate(x):scan(v,f'{path}[{i}]')
 scan(sp)
 for s in b['sessions']:
  n=sum(1 for v in s['vocabulary_targets'] if v['status']=='NEW'); r=sum(1 for v in s['vocabulary_targets'] if v['status']=='RECYCLED')
  if len(s['vocabulary_targets'])!=10 or (n,r)!=(4,6):errors.append(f'{s["session_id"]} vocab structure is {n} NEW/{r} RECYCLED')
 # Verify teacher guide ID coverage.
 guide=ROOT/'04_FRTS_Weeks_13-19_Teacher_Answer_Guide_v0.5.md'
 gt=guide.read_text(encoding='utf-8') if guide.exists() else ''
 for q in qs:
  if q['id'] not in gt:errors.append(f'teacher guide missing {q["id"]}')
 # Punctuation artifact scan after cleanup.
 double=[]
 for q in qs:
  text=q['teacher_only'].get('explanation','')+' '+' '.join(q['teacher_only'].get('option_rationales',{}).values())
  if '..' in text:double.append(q['id'])
 if double:errors.append(f'double full-stop artifacts remain in {len(double)} question records')
 print(f'Sessions: {len(b["sessions"])}; questions: {len(qs)}; stimuli: {len(ts)}; vocabulary cards: {vc}')
 print(f'Payload IDs synchronized: student={len(sqids)} teacher={len(aqids)}')
 print(f'Student recursive leakage findings: {sum(1 for e in errors if "student payload forbidden field" in e)}')
 print(f'Key/option records structurally checked: {len(qs)}')
 print(f'Evidence excerpt presence checked: {sum(len(q["teacher_only"].get("evidence_excerpts",[])) for q in qs)}')
if errors:
 print('FAIL')
 for e in errors[:200]:print('ERROR:',e)
 sys.exit(1)
print('PASS — structural checks only; this does not certify semantic validity or student readiness.')
