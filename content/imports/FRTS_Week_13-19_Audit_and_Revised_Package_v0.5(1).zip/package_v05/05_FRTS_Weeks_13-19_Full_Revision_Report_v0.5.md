# FRTS Weeks 13–19 v0.5 — Revision and Validation Report

**Base package:** FRTS v0.4 + Independent Deep Audit Report dated 16 November 2026  
**Version:** 0.5  
**Release status:** `STRUCTURAL_QA_PASS_CONTENT_REVIEW_REQUIRED`

## 1. Executive decision

v0.5 implements the specific corrective actions supported by the independent v0.4 audit. It is a **revised content candidate**, not a student-ready or production-ready assessment. The known critical answer-support defect was corrected; all 26 main-idea overlap flags and all 19 inference candidates were substantively revised; identified editorial stimulus phrases and the W17S2 contextual-vocabulary clue were repaired.

The package must still receive independent review by two qualified English/assessment reviewers and a student pilot. This report does not claim that every one of 440 items has a human semantic sign-off. The revision log and item-level CSV distinguish targeted model changes from items that remain unchanged and await human review.

## 2. Fixed scope and counts

| Component | Actual | Expected | Result |
|---|---:|---:|---|
| Sessions | 14 | 14 | PASS |
| Questions | 440 | 440 | PASS |
| Stimuli | 46 | 46 | PASS |
| Vocabulary cards | 140 | 140 | PASS |
| NEW cards | 56 | 56 | PASS (declared distribution) |
| RECYCLED cards | 84 | 84 | PASS (provenance partial) |
| Unique question IDs | 440 | 440 | PASS |
| Unique stimulus IDs | 46 | 46 | PASS |

## 3. Audit findings addressed

### CRIT-01 — W18S2-Q04 unsupported premise

**Resolved by model revision.** The stem no longer asks where students moved a pot. It asks which location is associated with the pot that dried faster. The key remains A and the supporting sentence is quoted exactly: “One pot had dried more quickly because it stood in direct sunlight.” The stimulus was also clarified so no movement is implied. Human sign-off remains required.

### HIGH-01 — 26 main-idea overlap items

**Targeted model revision complete.** Replaced one near-equivalent/overlapping option for each of the 26 flagged items, retained the existing correct key, and regenerated all four option rationales with item-specific text-based explanations. IDs retained: W15S1-Q11, W15S2-Q11, W15S2-Q21, W16S1-Q17, W16S2-Q01, W16S2-Q11, W16S2-Q21, W16S2-Q31, W17S1-Q01, W17S1-Q17, W17S2-Q01, W17S2-Q11, W17S2-Q21, W17S2-Q31, W18S1-Q01, W18S2-Q01, W18S2-Q11, W18S2-Q21, W18S2-Q31, W19S1-Q01, W19S1-Q09, W19S1-Q17, W19S2-Q01, W19S2-Q11, W19S2-Q21, W19S2-Q31.

The revised distractors now target narrower supporting details, wrong scope, unsupported assertions, contradictions, or misreadings rather than restating the key in alternate wording. This is not an empirically tested distractor analysis; human reviewers must verify mutual exclusivity and plausibility.

### HIGH-02 — W17S2-Q37 contextual vocabulary

**Targeted model revision complete.** The sentence now describes a user setting a second reminder after noticing that the sound may be hard to hear in a busy room. This supplies a contextual action from which “cautious” can be inferred. The vocabulary example, evidence, explanation, and option rationales are synchronized.

### HIGH-03 — editorial/meta statements

The following stimuli were revised: W13S2-T2, W13S2-T3, W14S1-T3, W14S2-T3, W16S1-T3, W16S2-T2, W17S1-T1, W17S2-T2, W17S2-T4, W18S1-T3, W18S2-T1. Explicit comments that named a main idea, inferred conclusion, perspective, or lesson have been removed or replaced with natural text information. Dependent question stems, options, keys, evidence, rationales, and vocabulary targets affected by those text edits were synchronized, including W13S2-Q16/Q19/Q30, W14S1-Q25/Q27/Q30, W14S2-Q25–Q27/Q30, W16S1-Q21/Q22/Q23/Q24/Q25, W16S2-Q16/Q18, W17S1-Q06/Q07/Q08, W17S2-Q15–Q17/Q20, W18S1-Q24, and W18S2-Q07/Q10.

### HIGH-04 — 19 inference candidates

All 19 audit-flagged items were processed: 18 retain an inference/application construct after revision; W14S2-Q18 was correctly reclassified as an explicit-detail item because the required preparation is stated directly. Targeted IDs: W13S2-Q18, W14S1-Q28, W14S2-Q18, W14S2-Q28, W16S1-Q16, W16S1-Q24, W16S2-Q18, W16S2-Q38, W17S1-Q08, W17S1-Q16, W17S2-Q18, W17S2-Q28, W17S2-Q38, W18S1-Q08, W18S1-Q16, W18S1-Q24, W18S2-Q08, W18S2-Q28, W18S2-Q38. The remaining inference items use comparison, limits of evidence, combining viewpoints, or applying context. A human reviewer must still verify the construct of every item.

## 4. Stimulus quality

All 46 stimuli remain present. Word counts were recalculated from final text. Eleven stimuli received targeted editorial revision; dependent items on revised stimuli were also synchronized. No claim of professional readability calibration is made. Genres and reading complexity remain subject to human review for authenticity, naturalness, and learner fit.

## 5. Main-idea and distractor revisions

26 main-idea items were revised. Their option rationales were rebuilt for all four choices. The 19 inference candidates also received new item-specific rationales. Other options outside these targeted sets were retained from v0.4, with punctuation cleanup only; they have **not** received a full new human distractor audit.

No option-length equality target was forced. The audit focuses on semantic distinctness and text support; length is only a secondary cue check.

## 6. Evidence and answer synchronization

- Final `evidence_excerpts` for revised questions were checked against the final stimulus strings by the build script.
- Teacher answer payload and teacher guide were regenerated from the canonical question bank.
- Student payload was regenerated from student-facing fields only.
- A recursive field scan is run by the included validator.

An exact text match proves the excerpt exists; it does not by itself prove that the excerpt entails the answer. The targeted rationales explain the intended reasoning, but independent human entailment review remains mandatory.

## 7. Curriculum traceability

All source references previously identified as cross-batch mismatches were reconciled by skill to the available module source: Batch 1 v0.4 for foundational/detail/question-first/paraphrase skills; Batch 2 v0.1 for main idea/context/reference/inference; Batch 3 v0.3 for distractor elimination and integrated practice.

The 222 source-bank `learning_objective_id` and `module_section_id` values were preserved and their skill/source references reconciled. Those IDs remain only partially verified because the available modules are drafts and the owner-approved crosswalk is absent. Both fields remain null on 218 items; `teacher_lesson_id` remains null on all 440 items. No identifiers were fabricated. The source modules are drafts, not owner-approved classroom-validated materials.

## 8. Vocabulary provenance

The 54 RECYCLED cards whose v0.4 field contained session identifiers now have separate `source_week` and `source_session` fields. The session identifier has been preserved; exact source-file/version and vocabulary-section locators remain unverified. Thirty RECYCLED cards remain `TRACEABILITY_UNVERIFIED`. The 56 NEW labels are session declarations, not proof of historical uniqueness, until checked against the complete W1–W12 vocabulary register. Thus the formal 4 NEW + 6 RECYCLED structure is present, but the historical provenance of all 140 cards is not fully certified.

W16S1-Q23 now quotes the printed form “extracted” while its card retains the normalized lemma “extract”. W13S2 “restrictive” was changed to “restriction” and “literal” to “caption”; W14S2 “effective” was changed to “filter” so the tested lemma occurs in the passage; W17S1 “viewpoint” was changed to “concern” and W17S2 “perspective” to “delivery” to remove deleted editorial targets; W17S2 “cautious” was retained with an improved contextual clue. Historical NEW/RECYCLED status still requires the owner’s complete W1–W12 vocabulary register.

## 9. Cognitive-level and difficulty distribution

W13–W19 subset cognitive-level distribution after revision: **L1 133 (30.2%), L2 294 (66.8%), L3 13 (3.0%).**

Difficulty labels: developing=218, easy=92, medium=130.

Technical Specification v1.0’s earlier 30/50/20 target was described as a full-bank target. It cannot be applied to this 440-item subset in isolation. The W1–W12 aggregate bank and owner confirmation are required before any full-bank reconciliation. No item labels were manipulated merely to force a target percentage.

## 10. Editorial and technical checks

- Teacher explanation and option-rationale text was cleaned for repeated full stops / double punctuation.
- Word counts were recomputed from final stimulus text.
- IDs, session counts, and question counts are preserved.
- Three JSON files are generated from one canonical bank.
- Student payload excludes `teacher_only` and answer-bearing objects.
- A clean local validator and result file are included; the previous validator’s environmental warmup warning is not reused.

## 11. Unresolved dependencies / human requirements

1. Provide the owner-approved stable crosswalk for 218 missing LO IDs, 218 missing module-section IDs, and 440 teacher lesson IDs.
2. Provide the complete canonical W1–W12 vocabulary target register, including file/version/section locations, to verify NEW and RECYCLED labels.
3. Two qualified human reviewers must assess all 440 items, including the 1,760 options, stimulus-question alignment, key uniqueness, evidence entailment, language naturalness, difficulty, and curriculum traceability.
4. Conduct a student pilot; gather response data before making claims about item difficulty, discrimination, reliability, or psychometric validity.
5. Test API role authorization and server-side separation of student and teacher data in the application.

## 12. Release decision

`STRUCTURAL_QA_PASS_CONTENT_REVIEW_REQUIRED`

**v0.5 must not yet be published as a validated student assessment.** It is a substantive correction candidate for the next independent audit.


## 13. Independent-audit coverage and limits (required reading)

| Review unit | Actual work in v0.5 | What this does **not** prove |
|---|---:|---|
| Whole question bank | 440 records structurally reconciled | Does not mean all 440 received independent semantic sign-off |
| Targeted item revisions | 73 unique items received specific model revisions | Not a substitute for independent human review |
| Retained items | 367 items retained from v0.4 | Their answerability, distractor strength, and language remain human-review requirements |
| Main-idea items revised | 26 | Semantic exclusivity still requires human confirmation |
| Option rationales rewritten | 292 of 1,760 | Remaining 1468 rationales were retained; all options remain unscored for plausibility |
| Stimuli | 11 revised; 35 retained | All 46 still require final genre/naturalness/reading-load review |
| Evidence excerpts | 614 excerpts found in the linked final stimuli | String presence is not proof of entailment |
| Contextual-vocabulary question targets | 46 candidates located; target-form presence algorithmically cross-checked within linked texts | Does not certify that every vocabulary inference is fair or sufficiently cued |
| RECYCLED provenance | 54 with an earlier session reference; 30 without a session reference | Even the 54 lack a precise source file/version/section locator |
| LO IDs | 222 present; 218 missing | Present IDs are preserved but lack owner-approved crosswalk sign-off |
| Module section IDs | 222 present; 218 missing | Present IDs are not evidence of owner approval |
| Teacher lesson IDs | 440 missing | Owner must supply the teacher-lesson crosswalk |

### Item-level audit interpretation

The item semantic review CSV distinguishes 73 targeted model-revised items from 367 retained items. Every row includes the exact current stem and four options. The file records `NOT_INDEPENDENTLY_ESTABLISHED` for the number of defensible answers, marks alternative-answer tests as pending human sign-off, and leaves all four distractor plausibility scores as `NOT_RATED`. This is intentionally conservative: availability of option rationales does not establish that the options are plausible or mutually exclusive.

The distractor audit contains 1,760 records. Exactly 292 rationales were rebuilt for targeted items; 1468 remain from v0.4 and require human review. **All 1,760 plausibility scores remain `NOT_RATED`.**

### Vocabulary interpretation

The 56 NEW entries are declared as new targets in their current sessions only. Their historical uniqueness has not been proven without the complete owner-approved W1–W12 target register. For the 84 RECYCLED entries, 54 retain a source session reference and 30 remain unverified; none are claimed to have a fully verified source-file/version/section locator. The vocabulary audit now distinguishes exact lemma occurrence, inflected/derived occurrence, and absence from the associated session texts. A card not occurring in a session passage is not automatically defective if it is not the target of a contextual-vocabulary question.

### Cognitive and difficulty distribution (verified subset counts)

| Measure | Category | Count | Share |
|---|---|---:|---:|
| Cognitive level | L1 | 133 | 30.2% |
| Cognitive level | L2 | 294 | 66.8% |
| Cognitive level | L3 | 13 | 3.0% |
| Difficulty label | easy | 92 | 20.9% |
| Difficulty label | developing | 218 | 49.5% |
| Difficulty label | medium | 130 | 29.5% |

These are counts of current metadata labels, not calibrated difficulty or construct ratings. The Technical Specification v1.0 target (30/50/20) relates to the full 600-question bank; W1–W12 aggregates and owner confirmation are required before reconciliation.

### Punctuation

The duplicate full-stop artifact detected in v0.4 explanations was cleaned. The included validators check for residual doubled sentence punctuation. This mechanical check does not certify editorial quality or clarity.

### Release boundary

The package passes technical structure and cross-file checks. It is **not safe for student use or classroom pilot yet** because there is no independent human sign-off for all items, no student response data, and unresolved curriculum/vocabulary provenance dependencies. Release remains `STRUCTURAL_QA_PASS_CONTENT_REVIEW_REQUIRED`.
