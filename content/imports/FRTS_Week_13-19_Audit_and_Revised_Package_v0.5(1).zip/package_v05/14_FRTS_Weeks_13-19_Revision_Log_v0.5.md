# FRTS Weeks 13–19 — Revision Log v0.5

**Base:** v0.4 bank + independent deep audit dated 16 November 2026.

## Changes implemented

1. Corrected W18S2-Q04: the unsupported “moved pot” premise was removed; the question now asks which location is associated with the pot that dried faster, and the evidence is the exact sentence in the stimulus.
2. Reconstructed all 26 main-idea items flagged for semantic overlap by the independent audit. One near-equivalent option per item was replaced with a distinct, text-related alternative; all four option rationales were rewritten with item-specific reasoning.
3. Reworked all 19 inference candidates flagged for direct-answer/paraphrase risk. Stems and options now require interpretation, combining clues, or application of the text.
4. Removed/rewrote editorial or meta statements in 11 stimuli: W13S2-T2, W13S2-T3, W14S1-T3, W14S2-T3, W16S1-T3, W16S2-T2, W17S1-T1, W17S2-T2, W17S2-T4, W18S1-T3, and W18S2-T1. Dependent items were synchronized, including W16S1-Q21/Q22/Q23/Q25 and W16S2-Q16.
5. Improved W17S2-T4 contextual clue for “cautious” and matched its vocabulary example and Q37 evidence to the final passage.
6. Rewrote W13S2 restriction/caption vocabulary and the associated contextual-vocabulary questions to match natural final stimulus wording.
7. Clarified W18S2-T1 and removed any implication that the pot was moved; corrected Q04 accordingly.
8. Cleaned repeated punctuation artifacts in teacher explanations/rationales.
9. Reconciled canonical source labels and references for all skills; preserved 222 existing learning-objective/module-section IDs and left the 218 missing pairs and all 440 teacher-lesson IDs null.
10. Split RECYCLED `source_week` and `source_session`; preserved 54 session references while leaving 30 cards unverified; exact source sections were not fabricated. NEW labels remain subject to full W1–W12 uniqueness verification.
11. Regenerated student payload, teacher answer payload, and teacher answer guide from the canonical v0.5 question bank.

## Not changed / unresolved by design

- 440 questions, 14 sessions, 46 stimulus IDs, 140 vocabulary cards, and established question IDs are preserved.
- 30 recycled vocabulary entries remain `TRACEABILITY_UNVERIFIED`; 54 have a session ID recorded but still lack an exact source-file/section locator.
- Learning objective IDs are absent on 218 items, module section IDs are absent on 218 items, and teacher lesson IDs are absent on all 440; none were invented.
- Cognitive-level distribution remains a measured subset result, not forced to match a full-bank target without the W1–W12 aggregate.
- Independent human academic sign-off, classroom pilot, and psychometric analysis remain pending.
