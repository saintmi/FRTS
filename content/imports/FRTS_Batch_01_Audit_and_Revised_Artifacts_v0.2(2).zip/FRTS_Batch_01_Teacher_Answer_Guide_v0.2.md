# FRTS Batch 1 — Teacher Answer & Explanation Guide
## Weeks 1–4 | 8 sesi online | 96 soal

**Versi:** 0.2 | **Basis:** Modul v0.4 dan Master Question Bank v0.2

## Aturan akses dan privasi

Dokumen ini memuat kunci dan pembahasan guru. Jangan mengirim bagian `teacher_only` ke browser siswa. Endpoint guru harus memverifikasi autentikasi dan peran guru di server; menyembunyikan jawaban dengan CSS/JavaScript bukan kontrol akses.

## Panduan penggunaan

Minta siswa menunjukkan bukti teks dan menjelaskan alasan memilih jawaban. Untuk soal strategy transfer, siswa harus menjelaskan langkah membaca yang diterapkan.

# W1-ONLINE-01 — Reading Foundation: School Gardens

**Kesulitan:** Easy 5 | Developing 5 | Medium 2
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **drainage** (noun; NEW) — drainase; aliran pembuangan air. Contoh: *Good drainage helps excess water leave the soil.* Sinonim/terkait: water flow, runoff system. Antonim/kontras: —.
- **nutrient** (noun; NEW) — zat hara/nutrisi. Contoh: *Plants need nutrients to grow.* Sinonim/terkait: nourishing substance. Antonim/kontras: —.
- **shelter** (noun/verb; NEW) — tempat perlindungan; melindungi. Contoh: *Bushes provide shelter for small animals.* Sinonim/terkait: protection, refuge. Antonim/kontras: exposure (kontekstual).
- **harvest** (verb/noun; NEW) — memanen; hasil panen. Contoh: *Students harvest vegetables when they are ready.* Sinonim/terkait: gather, collect. Antonim/kontras: sow/plant (berbeda tahap).
- **purpose** (noun; RECYCLED) — tujuan. Contoh: *The purpose of the notice is to inform students.* Sinonim/terkait: aim, intention. Antonim/kontras: —.
- **record** (verb/noun; RECYCLED) — mencatat; catatan. Contoh: *Students record changes in plant growth.* Sinonim/terkait: write down; report. Antonim/kontras: —.
- **available** (adjective; RECYCLED) — tersedia. Contoh: *Clean water is available near the garden.* Sinonim/terkait: obtainable, ready. Antonim/kontras: unavailable.
- **sequence** (noun; RECYCLED) — urutan. Contoh: *Put the garden activities in sequence.* Sinonim/terkait: order, series. Antonim/kontras: disorder (kontekstual).
- **specific** (adjective; RECYCLED) — khusus/spesifik. Contoh: *The question asks for a specific date.* Sinonim/terkait: particular, exact. Antonim/kontras: general.
- **general** (adjective; RECYCLED) — umum. Contoh: *The report gives general information.* Sinonim/terkait: broad, overall. Antonim/kontras: specific.

### Stimulus

#### W1S1-T1 — Planning a School Garden

**Genre:** Report / informational | **Jumlah kata:** 160 | **Estimasi:** A2+/B1-inspired

A school garden needs more than seeds and a sunny corner. Before planting, students should examine the site and record what is already there. They may notice areas that receive strong sunlight, places where water collects after rain, and paths that people use every day. These observations help the class decide where to place garden beds. Soil also matters. If water cannot move through the soil easily, poor drainage may leave roots too wet. Plants need nutrients—substances that help them grow—as well as water and light. Fallen leaves can become compost, which adds useful organic matter to the soil. A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks. At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned. Even a small plot can become a useful outdoor classroom when students share tasks and monitor changes carefully.

**Basis referensi:** SRC-01, SRC-07

#### W1S1-T2 — A Garden Workday

**Genre:** Recount | **Jumlah kata:** 125 | **Estimasi:** A2+/B1-inspired

Last month, Class 8B organised a garden workday behind the science room. At first, the ground looked uneven and several areas were covered with dry leaves. The students divided the work into small teams. One team measured the space, another collected fallen leaves, and a third checked the water tap. Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects. After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string. The class did not plant vegetables that day. Instead, they prepared the area and wrote a short record of what still needed to be done. The students agreed to return the following week to review the plan.

**Basis referensi:** SRC-01, SRC-07
**Catatan skenario:** Nama kelas, waktu kegiatan, dan peristiwa merupakan skenario latihan fiktif.

### Pembahasan soal

#### W1S1-Q01 — Easy / scanning_strategy / strategy_transfer

You need to locate what students should examine before planting. Which phrase should guide your scan?

• **A. The price of lunch** — Tidak tepat. Opsi “The price of lunch” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Before planting, students should examine the site and record what is already there.”.
✅ **B. The garden site** — Benar. Pilihan “The garden site” menjawab pertanyaan dan didukung oleh bukti: “Before planting, students should examine the site and record what is already there.”.
• **C. The classroom windows** — Tidak tepat. Opsi “The classroom windows” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Before planting, students should examine the site and record what is already there.”.
• **D. The school timetable** — Tidak tepat. Opsi “The school timetable” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Before planting, students should examine the site and record what is already there.”.

**Kunci:** B. The garden site
**Penjelasan guru:** Jawaban B benar karena “The garden site” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Before planting, students should examine the site and record what is already there.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Before planting, students should examine the site and record what is already there.”
**Target kosakata:** record
**Supporting vocabulary:** site

#### W1S1-Q02 — Easy / explicit_detail / reading_comprehension

What can poor drainage cause?

✅ **A. Roots to become too wet** — Benar. Pilihan “Roots to become too wet” menjawab pertanyaan dan didukung oleh bukti: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
• **B. Plants to receive more sunlight** — Tidak tepat. Opsi “Plants to receive more sunlight” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
• **C. Tools to disappear** — Tidak tepat. Opsi “Tools to disappear” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
• **D. Leaves to change colour immediately** — Tidak tepat. Opsi “Leaves to change colour immediately” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.

**Kunci:** A. Roots to become too wet
**Penjelasan guru:** Jawaban A benar karena “Roots to become too wet” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “If water cannot move through the soil easily, poor drainage may leave roots too wet.”
**Target kosakata:** specific, available
**Supporting vocabulary:** —

#### W1S1-Q03 — Developing / main_idea / reading_comprehension

Which sentence best expresses the main idea?

• **A. Students should remove all bushes before planting.** — Tidak tepat. Opsi “Students should remove all bushes before planting.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
✅ **B. A successful school garden requires observation and planning.** — Benar. Pilihan “A successful school garden requires observation and planning.” menjawab pertanyaan dan didukung oleh bukti: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
• **C. Every school must grow vegetables for sale.** — Tidak tepat. Opsi “Every school must grow vegetables for sale.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
• **D. A garden is useful only when it is very large.** — Tidak tepat. Opsi “A garden is useful only when it is very large.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.

**Kunci:** B. A successful school garden requires observation and planning.
**Penjelasan guru:** Jawaban B benar karena “A successful school garden requires observation and planning.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”
**Target kosakata:** purpose, available
**Supporting vocabulary:** —

#### W1S1-Q04 — Developing / text_structure / reading_comprehension

Which feature most strongly shows that this is a report or informational text?

✅ **A. It presents general information about what a school garden needs.** — Benar. Pilihan “It presents general information about what a school garden needs.” menjawab pertanyaan dan didukung oleh bukti: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
• **B. It gives a fictional problem and its solution.** — Tidak tepat. Opsi “It gives a fictional problem and its solution.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
• **C. It lists exact steps for preparing one particular garden.** — Tidak tepat. Opsi “It lists exact steps for preparing one particular garden.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.
• **D. It tells one student’s personal experience in time order.** — Tidak tepat. Opsi “It tells one student’s personal experience in time order.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”.

**Kunci:** A. It presents general information about what a school garden needs.
**Penjelasan guru:** Jawaban A benar karena “It presents general information about what a school garden needs.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A school garden needs more than seeds and a sunny corner.” “A garden plan should also include a safe place to store tools and a source of water that remains available during dry weeks.”
**Target kosakata:** general, sequence
**Supporting vocabulary:** —

#### W1S1-Q05 — Developing / explicit_detail / reading_comprehension

Why did the teacher ask students to keep some small bushes?

• **A. They blocked the water tap.** — Tidak tepat. Opsi “They blocked the water tap.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
• **B. They were used to mark the planting beds.** — Tidak tepat. Opsi “They were used to mark the planting beds.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
• **C. They were ready to be sold.** — Tidak tepat. Opsi “They were ready to be sold.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
✅ **D. They could provide shelter for insects.** — Benar. Pilihan “They could provide shelter for insects.” menjawab pertanyaan dan didukung oleh bukti: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.

**Kunci:** D. They could provide shelter for insects.
**Penjelasan guru:** Jawaban D benar karena “They could provide shelter for insects.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”
**Target kosakata:** record
**Supporting vocabulary:** protect

#### W1S1-Q06 — Developing / sequence / reading_comprehension

What did the students do after collecting the fallen leaves?

• **A. They watered every planting bed.** — Tidak tepat. Opsi “They watered every planting bed.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”.
• **B. They planted vegetables immediately.** — Tidak tepat. Opsi “They planted vegetables immediately.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”.
• **C. They opened the tool store.** — Tidak tepat. Opsi “They opened the tool store.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”.
✅ **D. They placed the leaves in a compost box.** — Benar. Pilihan “They placed the leaves in a compost box.” menjawab pertanyaan dan didukung oleh bukti: “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”.

**Kunci:** D. They placed the leaves in a compost box.
**Penjelasan guru:** Jawaban D benar karena “They placed the leaves in a compost box.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “After the teams finished, they placed the leaves in a compost box and marked two future planting beds with string.”
**Target kosakata:** sequence
**Supporting vocabulary:** event

#### W1S1-Q07 — Medium / purpose / reading_comprehension

What is the writer’s main purpose?

• **A. To invite readers to a school concert.** — Tidak tepat. Opsi “To invite readers to a school concert.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”.
• **B. To explain the life cycle of insects.** — Tidak tepat. Opsi “To explain the life cycle of insects.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”.
• **C. To advertise gardening tools for sale.** — Tidak tepat. Opsi “To advertise gardening tools for sale.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”.
✅ **D. To recount how a class prepared a garden area.** — Benar. Pilihan “To recount how a class prepared a garden area.” menjawab pertanyaan dan didukung oleh bukti: “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”.

**Kunci:** D. To recount how a class prepared a garden area.
**Penjelasan guru:** Jawaban D benar karena “To recount how a class prepared a garden area.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Last month, Class 8B organised a garden workday behind the science room.” “Instead, they prepared the area and wrote a short record of what still needed to be done.”
**Target kosakata:** purpose, sequence
**Supporting vocabulary:** —

#### W1S1-Q08 — Easy / explicit_detail / reading_comprehension

What did the students plan to do the following week?

• **A. The students planted all the vegetables.** — Tidak tepat. Opsi “The students planted all the vegetables.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The students agreed to return the following week to review the plan.”.
✅ **B. The class planned to continue the work later.** — Benar. Pilihan “The class planned to continue the work later.” menjawab pertanyaan dan didukung oleh bukti: “The students agreed to return the following week to review the plan.”.
• **C. The garden was completely finished that day.** — Tidak tepat. Opsi “The garden was completely finished that day.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The students agreed to return the following week to review the plan.”.
• **D. The teacher cancelled the project.** — Tidak tepat. Opsi “The teacher cancelled the project.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The students agreed to return the following week to review the plan.”.

**Kunci:** B. The class planned to continue the work later.
**Penjelasan guru:** Jawaban B benar karena “The class planned to continue the work later.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The students agreed to return the following week to review the plan.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The students agreed to return the following week to review the plan.”
**Target kosakata:** available
**Supporting vocabulary:** improve

#### W1S1-Q09 — Easy / vocabulary_in_context / vocabulary

In the passage, “nutrients” are substances that plants need for ...

• **A. faster transportation** — Tidak tepat. Opsi “faster transportation” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Plants need nutrients—substances that help them grow—as well as water and light.”.
✅ **B. healthy growth** — Benar. Pilihan “healthy growth” menjawab pertanyaan dan didukung oleh bukti: “Plants need nutrients—substances that help them grow—as well as water and light.”.
• **C. stronger sunlight** — Tidak tepat. Opsi “stronger sunlight” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Plants need nutrients—substances that help them grow—as well as water and light.”.
• **D. tool storage** — Tidak tepat. Opsi “tool storage” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Plants need nutrients—substances that help them grow—as well as water and light.”.

**Kunci:** B. healthy growth
**Penjelasan guru:** Jawaban B benar karena “healthy growth” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Plants need nutrients—substances that help them grow—as well as water and light.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Plants need nutrients—substances that help them grow—as well as water and light.”
**Target kosakata:** nutrient, available
**Supporting vocabulary:** —

#### W1S1-Q10 — Developing / vocabulary_in_context / vocabulary

Which phrase is closest in meaning to “poor drainage” in this passage?

• **A. The garden receives too much sunlight.** — Tidak tepat. Opsi “The garden receives too much sunlight.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
• **B. The plants are ready to be harvested.** — Tidak tepat. Opsi “The plants are ready to be harvested.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
• **C. The soil has too many tools in it.** — Tidak tepat. Opsi “The soil has too many tools in it.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.
✅ **D. Water does not move away from the soil easily.** — Benar. Pilihan “Water does not move away from the soil easily.” menjawab pertanyaan dan didukung oleh bukti: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”.

**Kunci:** D. Water does not move away from the soil easily.
**Penjelasan guru:** Jawaban D benar karena “Water does not move away from the soil easily.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “If water cannot move through the soil easily, poor drainage may leave roots too wet.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “If water cannot move through the soil easily, poor drainage may leave roots too wet.”
**Target kosakata:** drainage, specific
**Supporting vocabulary:** —

#### W1S1-Q11 — Easy / synonym_context / vocabulary

Which word is closest in meaning to “shelter” as used in the recount?

• **A. Schedule** — Tidak tepat. Opsi “Schedule” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
• **B. Harvest** — Tidak tepat. Opsi “Harvest” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
• **C. Measurement** — Tidak tepat. Opsi “Measurement” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.
✅ **D. Protection** — Benar. Pilihan “Protection” menjawab pertanyaan dan didukung oleh bukti: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”.

**Kunci:** D. Protection
**Penjelasan guru:** Jawaban D benar karena “Protection” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Their teacher asked them not to remove every plant because some small bushes could provide shelter for insects.”
**Target kosakata:** shelter
**Supporting vocabulary:** protect

#### W1S1-Q12 — Medium / vocabulary_in_context / vocabulary

In the passage, “harvest suitable crops” means ...

• **A. water the plants every morning** — Tidak tepat. Opsi “water the plants every morning” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”.
• **B. prepare the soil before planting** — Tidak tepat. Opsi “prepare the soil before planting” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”.
✅ **C. collect crops when they are ready** — Benar. Pilihan “collect crops when they are ready” menjawab pertanyaan dan didukung oleh bukti: “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”.
• **D. remove tools from the storage area** — Tidak tepat. Opsi “remove tools from the storage area” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”.

**Kunci:** C. collect crops when they are ready
**Penjelasan guru:** Jawaban C benar karena “collect crops when they are ready” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “At the end of the growing period, students may harvest (collect) suitable crops and record what the class has learned.”
**Target kosakata:** harvest, record
**Supporting vocabulary:** —

# W1-ONLINE-02 — Text Types and Meaning in Context: Urban Wildlife

**Kesulitan:** Easy 4 | Developing 5 | Medium 3
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **urban** (adjective; NEW) — perkotaan. Contoh: *Urban animals sometimes use parks as shelter.* Sinonim/terkait: city-related. Antonim/kontras: rural.
- **forage** (verb; NEW) — mencari makanan (hewan). Contoh: *Some birds forage for food near gardens.* Sinonim/terkait: search for food. Antonim/kontras: —.
- **monitor** (verb/noun; NEW) — memantau; pemantau. Contoh: *The team monitors animal activity.* Sinonim/terkait: observe, track. Antonim/kontras: ignore.
- **survive** (verb; NEW) — bertahan hidup. Contoh: *Some animals survive in changing environments.* Sinonim/terkait: remain alive, endure. Antonim/kontras: die (kontekstual).
- **shelter** (noun/verb; RECYCLED) — tempat perlindungan; melindungi. Contoh: *Bushes provide shelter for small animals.* Sinonim/terkait: protection, refuge. Antonim/kontras: exposure (kontekstual).
- **harvest** (verb/noun; RECYCLED) — memanen; hasil panen. Contoh: *Students harvest vegetables when they are ready.* Sinonim/terkait: gather, collect. Antonim/kontras: sow/plant (berbeda tahap).
- **nutrient** (noun; RECYCLED) — zat hara/nutrisi. Contoh: *Plants need nutrients to grow.* Sinonim/terkait: nourishing substance. Antonim/kontras: —.
- **purpose** (noun; RECYCLED) — tujuan. Contoh: *The purpose of the notice is to inform students.* Sinonim/terkait: aim, intention. Antonim/kontras: —.
- **specific** (adjective; RECYCLED) — khusus/spesifik. Contoh: *The question asks for a specific date.* Sinonim/terkait: particular, exact. Antonim/kontras: general.
- **protect** (verb; RECYCLED) — melindungi. Contoh: *Mangrove roots help protect the coast.* Sinonim/terkait: guard, defend, preserve. Antonim/kontras: harm, endanger.

### Stimulus

#### W1S2-T1 — Wild Neighbours in Towns

**Genre:** Report / informational | **Jumlah kata:** 138 | **Estimasi:** A2+/B1-inspired

Wild animals sometimes enter towns and cities to forage for food or seek shelter. Parks, roofs and gardens can offer places to rest, so some species survive in urban areas. Birds and squirrels often adjust to these environments. Larger animals may create more difficult situations. They can damage gardens, approach rubbish bins or cross busy roads. Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food. Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas. A useful response depends on the species and local conditions. People can help by keeping food waste secure and observing wildlife from a safe distance. The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.

**Basis referensi:** SRC-02

#### W1S2-T2 — The Notice Near the Park

**Genre:** Functional notice | **Jumlah kata:** 95 | **Estimasi:** A2+/B1-inspired

WILDLIFE OBSERVATION MORNING
Saturday, 22 August
Meet at 7:15 a.m. beside the north gate of River Park.
A local guide will explain how birds and small mammals use the park. Participants will record observations from marked paths. Please do not feed or touch wild animals. Bring a notebook, drinking water and a hat. Children under 13 must come with an adult. The activity ends at 9:30 a.m. Registration closes on Thursday. There is no entry fee, but places are limited to 25 participants. To register, send your name and class to the park education office.

**Basis referensi:** SRC-02, SRC-08
**Catatan skenario:** Tanggal, lokasi, kapasitas, dan rincian kegiatan merupakan skenario latihan fiktif; bukan pengumuman acara nyata.

### Pembahasan soal

#### W1S2-Q01 — Easy / main_idea / reading_comprehension

What is the passage mainly about?

• **A. How to train every wild animal as a pet.** — Tidak tepat. Opsi “How to train every wild animal as a pet.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **B. Why all city parks should be closed.** — Tidak tepat. Opsi “Why all city parks should be closed.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
✅ **C. How wild animals interact with towns and how people can reduce conflict.** — Benar. Pilihan “How wild animals interact with towns and how people can reduce conflict.” menjawab pertanyaan dan didukung oleh bukti: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **D. How residents can build houses for birds.** — Tidak tepat. Opsi “How residents can build houses for birds.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.

**Kunci:** C. How wild animals interact with towns and how people can reduce conflict.
**Penjelasan guru:** Jawaban C benar karena “How wild animals interact with towns and how people can reduce conflict.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”
**Target kosakata:** purpose
**Supporting vocabulary:** general

#### W1S2-Q02 — Easy / explicit_detail / reading_comprehension

Why do some wild animals enter towns?

• **A. To avoid all other animals.** — Tidak tepat. Opsi “To avoid all other animals.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **B. To attend school activities.** — Tidak tepat. Opsi “To attend school activities.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **C. To find shopping centres.** — Tidak tepat. Opsi “To find shopping centres.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
✅ **D. To look for food or shelter.** — Benar. Pilihan “To look for food or shelter.” menjawab pertanyaan dan didukung oleh bukti: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.

**Kunci:** D. To look for food or shelter.
**Penjelasan guru:** Jawaban D benar karena “To look for food or shelter.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”
**Target kosakata:** specific
**Supporting vocabulary:** detail

#### W1S2-Q03 — Developing / text_type / reading_comprehension

Which text type best fits this passage?

• **A. A procedure for building a bird cage.** — Tidak tepat. Opsi “A procedure for building a bird cage.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
✅ **B. A report giving general information about urban wildlife.** — Benar. Pilihan “A report giving general information about urban wildlife.” menjawab pertanyaan dan didukung oleh bukti: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **C. A narrative about a talking squirrel.** — Tidak tepat. Opsi “A narrative about a talking squirrel.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **D. A recount of one family’s weekend.** — Tidak tepat. Opsi “A recount of one family’s weekend.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.

**Kunci:** B. A report giving general information about urban wildlife.
**Penjelasan guru:** Jawaban B benar karena “A report giving general information about urban wildlife.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Wild animals sometimes enter towns and cities to forage for food or seek shelter.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** general, describe

#### W1S2-Q04 — Developing / purpose / reading_comprehension

What is the main purpose of the notice?

• **A. To explain how to build a park gate.** — Tidak tepat. Opsi “To explain how to build a park gate.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”.
• **B. To advertise animal food for sale.** — Tidak tepat. Opsi “To advertise animal food for sale.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”.
• **C. To report the results of a bird survey.** — Tidak tepat. Opsi “To report the results of a bird survey.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”.
✅ **D. To invite people to a guided wildlife observation activity.** — Benar. Pilihan “To invite people to a guided wildlife observation activity.” menjawab pertanyaan dan didukung oleh bukti: “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”.

**Kunci:** D. To invite people to a guided wildlife observation activity.
**Penjelasan guru:** Jawaban D benar karena “To invite people to a guided wildlife observation activity.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “WILDLIFE OBSERVATION MORNING” “Registration closes on Thursday.”
**Target kosakata:** purpose
**Supporting vocabulary:** event

#### W1S2-Q05 — Developing / scanning_strategy / strategy_transfer

To find the meeting point quickly, which label should you scan for first?

• **A. Date** — Tidak tepat. Opsi “Date” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Meet at 7:15 a.m. beside the north gate of River Park.”.
• **B. Bring** — Tidak tepat. Opsi “Bring” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Meet at 7:15 a.m. beside the north gate of River Park.”.
• **C. Registration closes** — Tidak tepat. Opsi “Registration closes” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Meet at 7:15 a.m. beside the north gate of River Park.”.
✅ **D. Meet at** — Benar. Pilihan “Meet at” menjawab pertanyaan dan didukung oleh bukti: “Meet at 7:15 a.m. beside the north gate of River Park.”.

**Kunci:** D. Meet at
**Penjelasan guru:** Jawaban D benar karena “Meet at” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Meet at 7:15 a.m. beside the north gate of River Park.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Meet at 7:15 a.m. beside the north gate of River Park.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** location, available

#### W1S2-Q06 — Developing / genre_structure / reading_comprehension

Which detail shows that the activity has limited capacity?

• **A. The meeting is on Saturday.** — Tidak tepat. Opsi “The meeting is on Saturday.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “There is no entry fee, but places are limited to 25 participants.”.
✅ **B. Places are limited to 25 participants.** — Benar. Pilihan “Places are limited to 25 participants.” menjawab pertanyaan dan didukung oleh bukti: “There is no entry fee, but places are limited to 25 participants.”.
• **C. Participants should bring a notebook.** — Tidak tepat. Opsi “Participants should bring a notebook.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “There is no entry fee, but places are limited to 25 participants.”.
• **D. The activity ends at 9:30 a.m.** — Tidak tepat. Opsi “The activity ends at 9:30 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “There is no entry fee, but places are limited to 25 participants.”.

**Kunci:** B. Places are limited to 25 participants.
**Penjelasan guru:** Jawaban B benar karena “Places are limited to 25 participants.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “There is no entry fee, but places are limited to 25 participants.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “There is no entry fee, but places are limited to 25 participants.”
**Target kosakata:** specific
**Supporting vocabulary:** detail

#### W1S2-Q07 — Medium / stated_reason / reading_comprehension

Why does the writer say that the goal is not to remove every wild animal?

✅ **A. Because people should reduce conflict while protecting wildlife too.** — Benar. Pilihan “Because people should reduce conflict while protecting wildlife too.” menjawab pertanyaan dan didukung oleh bukti: “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **B. Because every animal should be fed by residents.** — Tidak tepat. Opsi “Because every animal should be fed by residents.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **C. Because wild animals are always harmless in cities.** — Tidak tepat. Opsi “Because wild animals are always harmless in cities.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.
• **D. Because city parks are natural homes for all large animals.** — Tidak tepat. Opsi “Because city parks are natural homes for all large animals.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”.

**Kunci:** A. Because people should reduce conflict while protecting wildlife too.
**Penjelasan guru:** Jawaban A benar karena “Because people should reduce conflict while protecting wildlife too.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Residents may try to feed them, but this can encourage animals to return and may expose them to unhealthy food.” “The goal is not to remove every wild animal, but to reduce conflict and protect both people and animals.”
**Target kosakata:** protect, purpose
**Supporting vocabulary:** —

#### W1S2-Q08 — Easy / explicit_detail / reading_comprehension

Which participant must be accompanied by an adult?

• **A. A participant who is 14 years old.** — Tidak tepat. Opsi “A participant who is 14 years old.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Children under 13 must come with an adult.”.
• **B. A participant who is 18 years old.** — Tidak tepat. Opsi “A participant who is 18 years old.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Children under 13 must come with an adult.”.
✅ **C. A participant who is 12 years old.** — Benar. Pilihan “A participant who is 12 years old.” menjawab pertanyaan dan didukung oleh bukti: “Children under 13 must come with an adult.”.
• **D. A participant who is 16 years old.** — Tidak tepat. Opsi “A participant who is 16 years old.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Children under 13 must come with an adult.”.

**Kunci:** C. A participant who is 12 years old.
**Penjelasan guru:** Jawaban C benar karena “A participant who is 12 years old.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Children under 13 must come with an adult.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Children under 13 must come with an adult.”
**Target kosakata:** specific
**Supporting vocabulary:** required

#### W1S2-Q09 — Easy / vocabulary_in_context / vocabulary

In this passage, “urban” means ...

• **A. used only for farming** — Tidak tepat. Opsi “used only for farming” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **B. located deep in the ocean** — Tidak tepat. Opsi “located deep in the ocean” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **C. connected with ancient history** — Tidak tepat. Opsi “connected with ancient history” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
✅ **D. related to a town or city** — Benar. Pilihan “related to a town or city” menjawab pertanyaan dan didukung oleh bukti: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.

**Kunci:** D. related to a town or city
**Penjelasan guru:** Jawaban D benar karena “related to a town or city” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”
**Target kosakata:** urban
**Supporting vocabulary:** general

#### W1S2-Q10 — Developing / vocabulary_in_context / vocabulary

Which word is closest in meaning to “monitor” as used in the passage?

✅ **A. Observe** — Benar. Pilihan “Observe” menjawab pertanyaan dan didukung oleh bukti: “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”.
• **B. Ignore** — Tidak tepat. Opsi “Ignore” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”.
• **C. Damage** — Tidak tepat. Opsi “Damage” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”.
• **D. Release** — Tidak tepat. Opsi “Release” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”.

**Kunci:** A. Observe
**Penjelasan guru:** Jawaban A benar karena “Observe” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Some cities use trained teams to monitor, or watch, animal activity and guide animals away from crowded areas.”
**Target kosakata:** monitor
**Supporting vocabulary:** record

#### W1S2-Q11 — Medium / synonym_context / vocabulary

Which phrase is closest in meaning to “forage” in the passage?

✅ **A. Search for food** — Benar. Pilihan “Search for food” menjawab pertanyaan dan didukung oleh bukti: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **B. Watch an animal carefully** — Tidak tepat. Opsi “Watch an animal carefully” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **C. Build a safe place** — Tidak tepat. Opsi “Build a safe place” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.
• **D. Move away from a place** — Tidak tepat. Opsi “Move away from a place” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”.

**Kunci:** A. Search for food
**Penjelasan guru:** Jawaban A benar karena “Search for food” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Wild animals sometimes enter towns and cities to forage for food or seek shelter.”
**Target kosakata:** forage, monitor
**Supporting vocabulary:** —

#### W1S2-Q12 — Medium / vocabulary_in_context / vocabulary

In the sentence “Some species survive in urban areas”, what does “survive” mean?

✅ **A. Continue to live** — Benar. Pilihan “Continue to live” menjawab pertanyaan dan didukung oleh bukti: “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”.
• **B. Become more dangerous** — Tidak tepat. Opsi “Become more dangerous” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”.
• **C. Build a city** — Tidak tepat. Opsi “Build a city” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”.
• **D. Travel for a holiday** — Tidak tepat. Opsi “Travel for a holiday” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”.

**Kunci:** A. Continue to live
**Penjelasan guru:** Jawaban A benar karena “Continue to live” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Parks, roofs and gardens can offer places to rest, so some species survive in urban areas.”
**Target kosakata:** survive, urban
**Supporting vocabulary:** —

# W2-ONLINE-01 — Question-First Reading: Water Planning

**Kesulitan:** Easy 3 | Developing 5 | Medium 4
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **conserve** (verb; NEW) — menghemat/melestarikan. Contoh: *The class tries to conserve water.* Sinonim/terkait: save, preserve. Antonim/kontras: waste.
- **reliable** (adjective; NEW) — dapat diandalkan. Contoh: *A reliable water source is important.* Sinonim/terkait: dependable, trustworthy. Antonim/kontras: unreliable.
- **supply** (noun/verb; NEW) — persediaan/pasokan; memasok. Contoh: *The school checks its water supply.* Sinonim/terkait: provision, provide. Antonim/kontras: shortage (kontekstual).
- **allocate** (verb; NEW) — mengalokasikan/membagikan. Contoh: *The teacher allocates tasks to each group.* Sinonim/terkait: assign, distribute. Antonim/kontras: withhold.
- **urban** (adjective; RECYCLED) — perkotaan. Contoh: *Urban animals sometimes use parks as shelter.* Sinonim/terkait: city-related. Antonim/kontras: rural.
- **monitor** (verb/noun; RECYCLED) — memantau; pemantau. Contoh: *The team monitors animal activity.* Sinonim/terkait: observe, track. Antonim/kontras: ignore.
- **survive** (verb; RECYCLED) — bertahan hidup. Contoh: *Some animals survive in changing environments.* Sinonim/terkait: remain alive, endure. Antonim/kontras: die (kontekstual).
- **nutrient** (noun; RECYCLED) — zat hara/nutrisi. Contoh: *Plants need nutrients to grow.* Sinonim/terkait: nourishing substance. Antonim/kontras: —.
- **shelter** (noun/verb; RECYCLED) — tempat perlindungan; melindungi. Contoh: *Bushes provide shelter for small animals.* Sinonim/terkait: protection, refuge. Antonim/kontras: exposure (kontekstual).
- **reason** (noun; RECYCLED) — alasan. Contoh: *Find the reason for the schedule change.* Sinonim/terkait: cause, explanation. Antonim/kontras: —.

### Stimulus

#### W2S1-T1 — A Reliable Water Plan

**Genre:** Informational / explanation | **Jumlah kata:** 126 | **Estimasi:** A2+/B1-inspired

A school garden cannot depend on rain alone, especially during a long dry period. A class can begin by checking how much water is available and where it comes from. Some schools collect rainwater from roofs and store it in covered tanks. The water can then be used for suitable garden tasks. Students should also look for leaks and use a watering method that sends water close to plant roots. A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture. The plan works best when the water supply is reliable and the class avoids wasting water. These steps do not remove every problem, but they help students make informed decisions.

**Basis referensi:** SRC-04, SRC-01

#### W2S1-T2 — Message About the Garden Meeting

**Genre:** Email / message | **Jumlah kata:** 88 | **Estimasi:** A2+/B1-inspired

To: Garden Team
Subject: Thursday planning meeting
Hi everyone,
According to our last discussion, we need to review the water plan before the next planting day. Please bring the observation record and mention any problem you noticed near the storage tank. We will meet in the science room at 1:45 p.m. Ms. Rani will explain which tasks are required before the weekend. If you cannot attend, send your notes to the team leader by Wednesday afternoon. The meeting should take about 30 minutes.
Thank you,
Dimas
Team coordinator

**Basis referensi:** SRC-04, SRC-07
**Catatan skenario:** Nama pengirim, jadwal rapat, dan rincian koordinasi merupakan skenario latihan fiktif.

### Pembahasan soal

#### W2S1-Q01 — Easy / question_target / strategy_transfer

In the question “Where does the school collect rainwater?”, what information should the reader search for?

✅ **A. A place or source** — Benar. Pilihan “A place or source” menjawab pertanyaan dan didukung oleh bukti: “Some schools collect rainwater from roofs and store it in covered tanks.”.
• **B. A person’s name** — Tidak tepat. Opsi “A person’s name” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.
• **C. A reason** — Tidak tepat. Opsi “A reason” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.
• **D. A number of students** — Tidak tepat. Opsi “A number of students” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.

**Kunci:** A. A place or source
**Penjelasan guru:** Jawaban A benar karena “A place or source” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Some schools collect rainwater from roofs and store it in covered tanks.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Some schools collect rainwater from roofs and store it in covered tanks.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** identify, detail

#### W2S1-Q02 — Easy / explicit_detail / reading_comprehension

Where can some schools collect rainwater from?

• **A. Classroom bookshelves** — Tidak tepat. Opsi “Classroom bookshelves” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.
✅ **B. Roofs** — Benar. Pilihan “Roofs” menjawab pertanyaan dan didukung oleh bukti: “Some schools collect rainwater from roofs and store it in covered tanks.”.
• **C. Playground lights** — Tidak tepat. Opsi “Playground lights” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.
• **D. Sports uniforms** — Tidak tepat. Opsi “Sports uniforms” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Some schools collect rainwater from roofs and store it in covered tanks.”.

**Kunci:** B. Roofs
**Penjelasan guru:** Jawaban B benar karena “Roofs” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Some schools collect rainwater from roofs and store it in covered tanks.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Some schools collect rainwater from roofs and store it in covered tanks.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** specific, available

#### W2S1-Q03 — Developing / question_to_target / reading_comprehension

The question “Why is a reliable water supply important?” asks for ...

• **A. a date** — Tidak tepat. Opsi “a date” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **B. a person** — Tidak tepat. Opsi “a person” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
✅ **C. a reason** — Benar. Pilihan “a reason” menjawab pertanyaan dan didukung oleh bukti: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **D. a place** — Tidak tepat. Opsi “a place” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.

**Kunci:** C. a reason
**Penjelasan guru:** Jawaban C benar karena “a reason” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The plan works best when the water supply is reliable and the class avoids wasting water.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The plan works best when the water supply is reliable and the class avoids wasting water.”
**Target kosakata:** reason
**Supporting vocabulary:** required

#### W2S1-Q04 — Developing / evidence / reading_comprehension

Which statement is supported by the passage?

• **A. Every plant needs the same amount of water.** — Tidak tepat. Opsi “Every plant needs the same amount of water.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
• **B. The garden plan removes every possible problem.** — Tidak tepat. Opsi “The garden plan removes every possible problem.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
✅ **C. Students can check for leaks and observe soil moisture.** — Benar. Pilihan “Students can check for leaks and observe soil moisture.” menjawab pertanyaan dan didukung oleh bukti: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
• **D. Rainwater must never be stored in tanks.** — Tidak tepat. Opsi “Rainwater must never be stored in tanks.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.

**Kunci:** C. Students can check for leaks and observe soil moisture.
**Penjelasan guru:** Jawaban C benar karena “Students can check for leaks and observe soil moisture.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** according to, detail

#### W2S1-Q05 — Developing / task_word / reading_comprehension

In the instruction “Mention any problem you noticed”, the word “mention” asks students to ...

✅ **A. state or name a problem** — Benar. Pilihan “state or name a problem” menjawab pertanyaan dan didukung oleh bukti: “Please bring the observation record and mention any problem you noticed near the storage tank.”.
• **B. compare two teachers** — Tidak tepat. Opsi “compare two teachers” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please bring the observation record and mention any problem you noticed near the storage tank.”.
• **C. write a fictional story** — Tidak tepat. Opsi “write a fictional story” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please bring the observation record and mention any problem you noticed near the storage tank.”.
• **D. calculate the tank volume** — Tidak tepat. Opsi “calculate the tank volume” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please bring the observation record and mention any problem you noticed near the storage tank.”.

**Kunci:** A. state or name a problem
**Penjelasan guru:** Jawaban A benar karena “state or name a problem” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Please bring the observation record and mention any problem you noticed near the storage tank.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Please bring the observation record and mention any problem you noticed near the storage tank.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** mention, identify

#### W2S1-Q06 — Developing / explicit_detail / reading_comprehension

When will the meeting take place?

• **A. Saturday afternoon** — Tidak tepat. Opsi “Saturday afternoon” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “We will meet in the science room at 1:45 p.m.”.
✅ **B. Thursday at 1:45 p.m.** — Benar. Pilihan “Thursday at 1:45 p.m.” menjawab pertanyaan dan didukung oleh bukti: “We will meet in the science room at 1:45 p.m.”.
• **C. Friday at noon** — Tidak tepat. Opsi “Friday at noon” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “We will meet in the science room at 1:45 p.m.”.
• **D. Wednesday morning** — Tidak tepat. Opsi “Wednesday morning” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “We will meet in the science room at 1:45 p.m.”.

**Kunci:** B. Thursday at 1:45 p.m.
**Penjelasan guru:** Jawaban B benar karena “Thursday at 1:45 p.m.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “We will meet in the science room at 1:45 p.m.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “We will meet in the science room at 1:45 p.m.”
**Target kosakata:** reason
**Supporting vocabulary:** according to

#### W2S1-Q07 — Medium / evidence_multiple_details / reading_comprehension

What should a student do if they cannot attend the meeting?

• **A. Call the school office on Friday.** — Tidak tepat. Opsi “Call the school office on Friday.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”.
✅ **B. Send notes to the team leader by Wednesday afternoon.** — Benar. Pilihan “Send notes to the team leader by Wednesday afternoon.” menjawab pertanyaan dan didukung oleh bukti: “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”.
• **C. Wait until the next planting day.** — Tidak tepat. Opsi “Wait until the next planting day.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”.
• **D. Bring the water tank to the science room.** — Tidak tepat. Opsi “Bring the water tank to the science room.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”.

**Kunci:** B. Send notes to the team leader by Wednesday afternoon.
**Penjelasan guru:** Jawaban B benar karena “Send notes to the team leader by Wednesday afternoon.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “If you cannot attend, send your notes to the team leader by Wednesday afternoon.” “Team coordinator”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** required, detail

#### W2S1-Q08 — Medium / purpose / reading_comprehension

Why was the message written?

✅ **A. To organise a meeting and explain what team members should bring or do.** — Benar. Pilihan “To organise a meeting and explain what team members should bring or do.” menjawab pertanyaan dan didukung oleh bukti: “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”.
• **B. To advertise a new water tank for sale.** — Tidak tepat. Opsi “To advertise a new water tank for sale.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”.
• **C. To invite the public to a sports event.** — Tidak tepat. Opsi “To invite the public to a sports event.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”.
• **D. To report that the garden project has ended.** — Tidak tepat. Opsi “To report that the garden project has ended.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”.

**Kunci:** A. To organise a meeting and explain what team members should bring or do.
**Penjelasan guru:** Jawaban A benar karena “To organise a meeting and explain what team members should bring or do.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Subject: Thursday planning meeting” “Rani will explain which tasks are required before the weekend.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, event

#### W2S1-Q09 — Easy / vocabulary_in_context / vocabulary

In the passage, “reliable” means ...

• **A. temporary** — Tidak tepat. Opsi “temporary” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **B. expensive** — Tidak tepat. Opsi “expensive” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
✅ **C. dependable** — Benar. Pilihan “dependable” menjawab pertanyaan dan didukung oleh bukti: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **D. difficult to reach** — Tidak tepat. Opsi “difficult to reach” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.

**Kunci:** C. dependable
**Penjelasan guru:** Jawaban C benar karena “dependable” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The plan works best when the water supply is reliable and the class avoids wasting water.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The plan works best when the water supply is reliable and the class avoids wasting water.”
**Target kosakata:** reliable
**Supporting vocabulary:** available

#### W2S1-Q10 — Developing / vocabulary_in_context / vocabulary

What does “allocate” mean in “allocate different tasks to different groups”?

• **A. Remove completely** — Tidak tepat. Opsi “Remove completely” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
✅ **B. Assign or distribute** — Benar. Pilihan “Assign or distribute” menjawab pertanyaan dan didukung oleh bukti: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
• **C. Hide from others** — Tidak tepat. Opsi “Hide from others” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.
• **D. Measure carefully** — Tidak tepat. Opsi “Measure carefully” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”.

**Kunci:** B. Assign or distribute
**Penjelasan guru:** Jawaban B benar karena “Assign or distribute” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A simple plan may allocate, or assign, different tasks to different groups: one group checks the tank, another records watering times, and another observes soil moisture.”
**Target kosakata:** allocate
**Supporting vocabulary:** sequence

#### W2S1-Q11 — Medium / synonym_context / vocabulary

Which phrase is closest in meaning to “water supply”?

• **A. The list of students in a group.** — Tidak tepat. Opsi “The list of students in a group.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A class can begin by checking how much water is available and where it comes from.”.
✅ **B. The amount or source of water available.** — Benar. Pilihan “The amount or source of water available.” menjawab pertanyaan dan didukung oleh bukti: “A class can begin by checking how much water is available and where it comes from.”.
• **C. The time when a class begins.** — Tidak tepat. Opsi “The time when a class begins.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A class can begin by checking how much water is available and where it comes from.”.
• **D. The tools used to measure sunlight.** — Tidak tepat. Opsi “The tools used to measure sunlight.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A class can begin by checking how much water is available and where it comes from.”.

**Kunci:** B. The amount or source of water available.
**Penjelasan guru:** Jawaban B benar karena “The amount or source of water available.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A class can begin by checking how much water is available and where it comes from.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A class can begin by checking how much water is available and where it comes from.”
**Target kosakata:** supply
**Supporting vocabulary:** available

#### W2S1-Q12 — Medium / word_relation / vocabulary

Which word is closest in meaning to “conserve” in the context of water?

✅ **A. Save** — Benar. Pilihan “Save” menjawab pertanyaan dan didukung oleh bukti: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **B. Pollute** — Tidak tepat. Opsi “Pollute” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **C. Ignore** — Tidak tepat. Opsi “Ignore” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.
• **D. Waste** — Tidak tepat. Opsi “Waste” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The plan works best when the water supply is reliable and the class avoids wasting water.”.

**Kunci:** A. Save
**Penjelasan guru:** Jawaban A benar karena “Save” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The plan works best when the water supply is reliable and the class avoids wasting water.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The plan works best when the water supply is reliable and the class avoids wasting water.”
**Target kosakata:** conserve
**Supporting vocabulary:** required

# W2-ONLINE-02 — Question-First Reading: Notices, Updates and EXCEPT

**Kesulitan:** Easy 3 | Developing 4 | Medium 5
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **register** (verb; NEW) — mendaftar. Contoh: *Visitors must register online.* Sinonim/terkait: sign up, enrol. Antonim/kontras: withdraw (kontekstual).
- **confirm** (verb; NEW) — memastikan/mengonfirmasi. Contoh: *The email confirms the workshop time.* Sinonim/terkait: verify, make certain. Antonim/kontras: deny (kontekstual).
- **accessible** (adjective; NEW) — dapat diakses/dijangkau. Contoh: *The centre provides an accessible entrance.* Sinonim/terkait: reachable, usable. Antonim/kontras: inaccessible.
- **admission** (noun; NEW) — izin masuk/biaya masuk. Contoh: *Admission is free for all visitors.* Sinonim/terkait: entry, entrance. Antonim/kontras: —.
- **conserve** (verb; RECYCLED) — menghemat/melestarikan. Contoh: *The class tries to conserve water.* Sinonim/terkait: save, preserve. Antonim/kontras: waste.
- **reliable** (adjective; RECYCLED) — dapat diandalkan. Contoh: *A reliable water source is important.* Sinonim/terkait: dependable, trustworthy. Antonim/kontras: unreliable.
- **supply** (noun/verb; RECYCLED) — persediaan/pasokan; memasok. Contoh: *The school checks its water supply.* Sinonim/terkait: provision, provide. Antonim/kontras: shortage (kontekstual).
- **allocate** (verb; RECYCLED) — mengalokasikan/membagikan. Contoh: *The teacher allocates tasks to each group.* Sinonim/terkait: assign, distribute. Antonim/kontras: withhold.
- **schedule** (noun; RECYCLED) — jadwal. Contoh: *Check the updated event schedule.* Sinonim/terkait: timetable, programme. Antonim/kontras: —.
- **deadline** (noun; RECYCLED) — batas waktu. Contoh: *The registration deadline is Friday.* Sinonim/terkait: due date, closing date. Antonim/kontras: —.

### Stimulus

#### W2S2-T1 — Community Science Day — Announcement

**Genre:** Announcement | **Jumlah kata:** 81 | **Estimasi:** A2+/B1-inspired

COMMUNITY SCIENCE DAY
Date: Saturday, 19 September
Venue: Borneo Learning Centre
Opening: 9:00 a.m.
Last entry: 12:30 p.m.
The event includes a student project display, a short planetarium show and a recycling workshop. Admission is free, but visitors must register (sign up) online because the hall has a limited capacity. Registration closes on Wednesday, 16 September. Participants will receive a confirmation message after their forms have been checked. Please arrive at least ten minutes before the activity you wish to join.

**Basis referensi:** SRC-08, SRC-03
**Catatan skenario:** Nama acara, tempat, tanggal, jadwal, dan kapasitas merupakan data simulasi untuk latihan membaca.

#### W2S2-T2 — Email: A Change to the Workshop

**Genre:** Email | **Jumlah kata:** 87 | **Estimasi:** A2+/B1-inspired

To: Science Day Participants
Subject: Workshop time confirmed
Hello participants,
The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m. as stated in the first poster. The planetarium show remains at 11:15 a.m. Please check the updated schedule before arriving. If you have already registered, you do not need to send the form again. Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps. We apologise for the change and appreciate your understanding.
Event team

**Basis referensi:** SRC-08, SRC-03
**Catatan skenario:** Perubahan jadwal dan informasi akses merupakan skenario latihan fiktif.

### Pembahasan soal

#### W2S2-Q01 — Easy / explicit_detail / reading_comprehension

Where will Community Science Day take place?

✅ **A. Borneo Learning Centre** — Benar. Pilihan “Borneo Learning Centre” menjawab pertanyaan dan didukung oleh bukti: “Venue: Borneo Learning Centre”.
• **B. River Park** — Tidak tepat. Opsi “River Park” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Borneo Learning Centre”.
• **C. The school library** — Tidak tepat. Opsi “The school library” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Borneo Learning Centre”.
• **D. The city museum** — Tidak tepat. Opsi “The city museum” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Borneo Learning Centre”.

**Kunci:** A. Borneo Learning Centre
**Penjelasan guru:** Jawaban A benar karena “Borneo Learning Centre” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Venue: Borneo Learning Centre”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Venue: Borneo Learning Centre”
**Target kosakata:** schedule
**Supporting vocabulary:** available

#### W2S2-Q02 — Easy / question_target / strategy_transfer

Before scanning the announcement for the answer to “When does registration close?”, what type of detail should you look for?

• **A. The name of the event team** — Tidak tepat. Opsi “The name of the event team” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration closes on Wednesday, 16 September.”.
✅ **B. The registration deadline** — Benar. Pilihan “The registration deadline” menjawab pertanyaan dan didukung oleh bukti: “Registration closes on Wednesday, 16 September.”.
• **C. The length of the planetarium show** — Tidak tepat. Opsi “The length of the planetarium show” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration closes on Wednesday, 16 September.”.
• **D. The number of project displays** — Tidak tepat. Opsi “The number of project displays” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration closes on Wednesday, 16 September.”.

**Kunci:** B. The registration deadline
**Penjelasan guru:** Jawaban B benar karena “The registration deadline” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Registration closes on Wednesday, 16 September.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Registration closes on Wednesday, 16 September.”
**Target kosakata:** deadline
**Supporting vocabulary:** according to

#### W2S2-Q03 — Developing / evidence / reading_comprehension

Why must visitors register online?

• **A. Because the event is only for teachers.** — Tidak tepat. Opsi “Because the event is only for teachers.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **B. Because the venue is difficult to find.** — Tidak tepat. Opsi “Because the venue is difficult to find.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
✅ **C. Because the hall has a limited capacity.** — Benar. Pilihan “Because the hall has a limited capacity.” menjawab pertanyaan dan didukung oleh bukti: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **D. Because admission has a high price.** — Tidak tepat. Opsi “Because admission has a high price.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.

**Kunci:** C. Because the hall has a limited capacity.
**Penjelasan guru:** Jawaban C benar karena “Because the hall has a limited capacity.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** reason, required

#### W2S2-Q04 — Medium / NOT_EXCEPT / reading_comprehension

Which activity is NOT mentioned in the announcement?

• **A. A student project display** — Tidak tepat. Opsi “A student project display” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The event includes a student project display, a short planetarium show and a recycling workshop.”.
✅ **B. A cooking competition** — Benar. Pilihan “A cooking competition” menjawab pertanyaan dan didukung oleh bukti: “The event includes a student project display, a short planetarium show and a recycling workshop.”.
• **C. A planetarium show** — Tidak tepat. Opsi “A planetarium show” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The event includes a student project display, a short planetarium show and a recycling workshop.”.
• **D. A recycling workshop** — Tidak tepat. Opsi “A recycling workshop” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The event includes a student project display, a short planetarium show and a recycling workshop.”.

**Kunci:** B. A cooking competition
**Penjelasan guru:** Jawaban B benar karena “A cooking competition” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The event includes a student project display, a short planetarium show and a recycling workshop.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The event includes a student project display, a short planetarium show and a recycling workshop.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** mention, purpose

#### W2S2-Q05 — Developing / explicit_detail / reading_comprehension

What time will the water-filter workshop begin?

• **A. 12:30 p.m.** — Tidak tepat. Opsi “12:30 p.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
• **B. 10:00 a.m.** — Tidak tepat. Opsi “10:00 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
✅ **C. 10:30 a.m.** — Benar. Pilihan “10:30 a.m.” menjawab pertanyaan dan didukung oleh bukti: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
• **D. 11:15 a.m.** — Tidak tepat. Opsi “11:15 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.

**Kunci:** C. 10:30 a.m.
**Penjelasan guru:** Jawaban C benar karena “10:30 a.m.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”
**Target kosakata:** schedule
**Supporting vocabulary:** available

#### W2S2-Q06 — Developing / evidence / reading_comprehension

Who should contact the centre by Tuesday?

• **A. Visitors who want a free ticket.** — Tidak tepat. Opsi “Visitors who want a free ticket.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
✅ **B. Students who need step-free access.** — Benar. Pilihan “Students who need step-free access.” menjawab pertanyaan dan didukung oleh bukti: “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **C. All students who have registered.** — Tidak tepat. Opsi “All students who have registered.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **D. Teachers who lead the planetarium show.** — Tidak tepat. Opsi “Teachers who lead the planetarium show.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.

**Kunci:** B. Students who need step-free access.
**Penjelasan guru:** Jawaban B benar karena “Students who need step-free access.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “If you have already registered, you do not need to send the form again.” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** required, detail

#### W2S2-Q07 — Medium / NOT_EXCEPT / reading_comprehension

Which statement is NOT correct according to the two messages?

• **A. Registration closes on 16 September.** — Tidak tepat. Opsi “Registration closes on 16 September.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
• **B. Admission is free.** — Tidak tepat. Opsi “Admission is free.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
• **C. The planetarium show begins at 11:15 a.m.** — Tidak tepat. Opsi “The planetarium show begins at 11:15 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.
✅ **D. The water-filter workshop still begins at 10:00 a.m.** — Benar. Pilihan “The water-filter workshop still begins at 10:00 a.m.” menjawab pertanyaan dan didukung oleh bukti: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”.

**Kunci:** D. The water-filter workshop still begins at 10:00 a.m.
**Penjelasan guru:** Jawaban D benar karena “The water-filter workshop still begins at 10:00 a.m.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The water-filter workshop will begin at 10:30 a.m., not 10:00 a.m.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** according to, mention

#### W2S2-Q08 — Medium / purpose / reading_comprehension

Why was the second email sent?

• **A. To ask visitors to register again.** — Tidak tepat. Opsi “To ask visitors to register again.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
✅ **B. To correct a workshop time and give access information.** — Benar. Pilihan “To correct a workshop time and give access information.” menjawab pertanyaan dan didukung oleh bukti: “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **C. To cancel the whole science day.** — Tidak tepat. Opsi “To cancel the whole science day.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **D. To announce a new venue.** — Tidak tepat. Opsi “To announce a new venue.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.

**Kunci:** B. To correct a workshop time and give access information.
**Penjelasan guru:** Jawaban B benar karena “To correct a workshop time and give access information.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Subject: Workshop time confirmed” “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, available

#### W2S2-Q09 — Easy / vocabulary_in_context / vocabulary

In the announcement, “admission is free” means visitors ...

• **A. must buy a workshop ticket** — Tidak tepat. Opsi “must buy a workshop ticket” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
✅ **B. do not have to pay to enter** — Benar. Pilihan “do not have to pay to enter” menjawab pertanyaan dan didukung oleh bukti: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **C. can enter only with a teacher** — Tidak tepat. Opsi “can enter only with a teacher” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **D. must pay at the entrance** — Tidak tepat. Opsi “must pay at the entrance” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.

**Kunci:** B. do not have to pay to enter
**Penjelasan guru:** Jawaban B benar karena “do not have to pay to enter” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”
**Target kosakata:** admission
**Supporting vocabulary:** purpose

#### W2S2-Q10 — Developing / vocabulary_in_context / vocabulary

What does “register” mean in this announcement?

✅ **A. Sign up for a place online.** — Benar. Pilihan “Sign up for a place online.” menjawab pertanyaan dan didukung oleh bukti: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **B. Pay for a ticket at the door.** — Tidak tepat. Opsi “Pay for a ticket at the door.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **C. Arrive after the event ends.** — Tidak tepat. Opsi “Arrive after the event ends.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.
• **D. Change the event venue.** — Tidak tepat. Opsi “Change the event venue.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”.

**Kunci:** A. Sign up for a place online.
**Penjelasan guru:** Jawaban A benar karena “Sign up for a place online.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Admission is free, but visitors must register (sign up) online because the hall has a limited capacity.”
**Target kosakata:** register, deadline
**Supporting vocabulary:** —

#### W2S2-Q11 — Medium / vocabulary_in_context / vocabulary

Which word is closest in meaning to “confirm” in “workshop time confirmed”?

✅ **A. Verify** — Benar. Pilihan “Verify” menjawab pertanyaan dan didukung oleh bukti: “Subject: Workshop time confirmed”.
• **B. Hide** — Tidak tepat. Opsi “Hide” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed”.
• **C. Cancel** — Tidak tepat. Opsi “Cancel” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed”.
• **D. Postpone** — Tidak tepat. Opsi “Postpone” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: Workshop time confirmed”.

**Kunci:** A. Verify
**Penjelasan guru:** Jawaban A benar karena “Verify” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Subject: Workshop time confirmed”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Subject: Workshop time confirmed”
**Target kosakata:** confirm
**Supporting vocabulary:** according to

#### W2S2-Q12 — Medium / vocabulary_in_context / vocabulary

In this context, “step-free access” means ...

✅ **A. an entrance that can be used without steps** — Benar. Pilihan “an entrance that can be used without steps” menjawab pertanyaan dan didukung oleh bukti: “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **B. a room with no chairs** — Tidak tepat. Opsi “a room with no chairs” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **C. a ticket that has no price** — Tidak tepat. Opsi “a ticket that has no price” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.
• **D. a route that is open only at night** — Tidak tepat. Opsi “a route that is open only at night” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”.

**Kunci:** A. an entrance that can be used without steps
**Penjelasan guru:** Jawaban A benar karena “an entrance that can be used without steps” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Students who need step-free access should contact the centre by Tuesday so staff can arrange an accessible entrance with no steps.”
**Target kosakata:** accessible
**Supporting vocabulary:** required

# W3-ONLINE-01 — Scanning: Coastal Ecosystems and Field Trip Poster

**Kesulitan:** Easy 2 | Developing 5 | Medium 5
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **coastal** (adjective; NEW) — pesisir. Contoh: *Mangroves grow in coastal areas.* Sinonim/terkait: shoreline-related. Antonim/kontras: inland (kontekstual).
- **erosion** (noun; NEW) — erosi/pengikisan. Contoh: *Roots can reduce soil erosion.* Sinonim/terkait: wearing away. Antonim/kontras: deposition (proses berbeda).
- **sediment** (noun; NEW) — sedimen/endapan. Contoh: *Water can carry sediment to the coast.* Sinonim/terkait: deposited material. Antonim/kontras: —.
- **nursery** (noun; NEW) — area pembesaran satwa muda. Contoh: *A mangrove nursery supports young fish.* Sinonim/terkait: breeding/growing area. Antonim/kontras: —.
- **register** (verb; RECYCLED) — mendaftar. Contoh: *Visitors must register online.* Sinonim/terkait: sign up, enrol. Antonim/kontras: withdraw (kontekstual).
- **confirm** (verb; RECYCLED) — memastikan/mengonfirmasi. Contoh: *The email confirms the workshop time.* Sinonim/terkait: verify, make certain. Antonim/kontras: deny (kontekstual).
- **accessible** (adjective; RECYCLED) — dapat diakses/dijangkau. Contoh: *The centre provides an accessible entrance.* Sinonim/terkait: reachable, usable. Antonim/kontras: inaccessible.
- **admission** (noun; RECYCLED) — izin masuk/biaya masuk. Contoh: *Admission is free for all visitors.* Sinonim/terkait: entry, entrance. Antonim/kontras: —.
- **date** (noun; RECYCLED) — tanggal. Contoh: *Check the date of the field trip.* Sinonim/terkait: day (berkaitan, bukan sinonim mutlak). Antonim/kontras: —.
- **venue** (noun; RECYCLED) — tempat acara. Contoh: *The venue is the school hall.* Sinonim/terkait: location, site. Antonim/kontras: —.

### Stimulus

#### W3S1-T1 — Mangroves Along the Coast

**Genre:** Report / informational | **Jumlah kata:** 147 | **Estimasi:** A2+/B1-inspired

Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water. Their roots help hold soil in place and slow the movement of water near the shore. This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood. The tangled roots also create a protected nursery area where young fish and other animals can grow safely. Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web. Mangroves therefore support biodiversity as well as nearby communities. However, these forests can be damaged by pollution, land development and the removal of trees. Protecting a mangrove area requires local planning and long-term care. Water movement may increase after heavy rain and decrease during calmer conditions, so local observations are important.

**Basis referensi:** SRC-05, SRC-06

#### W3S1-T2 — Coast Discovery Field Trip

**Genre:** Functional poster | **Jumlah kata:** 76 | **Estimasi:** A2+/B1-inspired

COAST DISCOVERY FIELD TRIP
Date: 6 November
Departure: 7:00 a.m. from the school gate
Venue: Sungai Bakau Learning Site
Return: 1:30 p.m.
Contribution: Rp25,000 per student
Registration deadline: 30 October
Bring: a notebook, refillable water bottle and sun hat.
The trip includes a guided walk, a short observation task and a discussion with local educators. Students must stay with their group and follow the marked path. For further information, contact the science teacher before the deadline.

**Basis referensi:** SRC-08, SRC-05
**Catatan skenario:** Tanggal, tempat, biaya, dan jadwal kunjungan merupakan data simulasi untuk latihan membaca.

### Pembahasan soal

#### W3S1-Q01 — Easy / anchor_words / strategy_transfer

Which label should a student look for to find the place of the field trip?

• **A. Return** — Tidak tepat. Opsi “Return” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Sungai Bakau Learning Site”.
✅ **B. Venue** — Benar. Pilihan “Venue” menjawab pertanyaan dan didukung oleh bukti: “Venue: Sungai Bakau Learning Site”.
• **C. Contribution** — Tidak tepat. Opsi “Contribution” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Sungai Bakau Learning Site”.
• **D. Bring** — Tidak tepat. Opsi “Bring” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Venue: Sungai Bakau Learning Site”.

**Kunci:** B. Venue
**Penjelasan guru:** Jawaban B benar karena “Venue” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Venue: Sungai Bakau Learning Site”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Venue: Sungai Bakau Learning Site”
**Target kosakata:** venue
**Supporting vocabulary:** location

#### W3S1-Q02 — Medium / explicit_detail / reading_comprehension

What is the registration deadline?

• **A. 6 November** — Tidak tepat. Opsi “6 November” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration deadline: 30 October”.
• **B. 1:30 p.m.** — Tidak tepat. Opsi “1:30 p.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration deadline: 30 October”.
✅ **C. 30 October** — Benar. Pilihan “30 October” menjawab pertanyaan dan didukung oleh bukti: “Registration deadline: 30 October”.
• **D. 7:00 a.m.** — Tidak tepat. Opsi “7:00 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Registration deadline: 30 October”.

**Kunci:** C. 30 October
**Penjelasan guru:** Jawaban C benar karena “30 October” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Registration deadline: 30 October”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Registration deadline: 30 October”
**Target kosakata:** date
**Supporting vocabulary:** deadline

#### W3S1-Q03 — Developing / scanning_detail / reading_comprehension

How much is the contribution for one student?

• **A. Rp30,000** — Tidak tepat. Opsi “Rp30,000” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Contribution: Rp25,000 per student”.
• **B. Rp20,000** — Tidak tepat. Opsi “Rp20,000” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Contribution: Rp25,000 per student”.
✅ **C. Rp25,000** — Benar. Pilihan “Rp25,000” menjawab pertanyaan dan didukung oleh bukti: “Contribution: Rp25,000 per student”.
• **D. Rp15,000** — Tidak tepat. Opsi “Rp15,000” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Contribution: Rp25,000 per student”.

**Kunci:** C. Rp25,000
**Penjelasan guru:** Jawaban C benar karena “Rp25,000” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Contribution: Rp25,000 per student”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Contribution: Rp25,000 per student”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** amount, specific

#### W3S1-Q04 — Developing / scanning_detail / reading_comprehension

What time will the students return to school?

• **A. 7:00 a.m.** — Tidak tepat. Opsi “7:00 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Return: 1:30 p.m.”.
• **B. 11:30 a.m.** — Tidak tepat. Opsi “11:30 a.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Return: 1:30 p.m.”.
✅ **C. 1:30 p.m.** — Benar. Pilihan “1:30 p.m.” menjawab pertanyaan dan didukung oleh bukti: “Return: 1:30 p.m.”.
• **D. 1:00 p.m.** — Tidak tepat. Opsi “1:00 p.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Return: 1:30 p.m.”.

**Kunci:** C. 1:30 p.m.
**Penjelasan guru:** Jawaban C benar karena “1:30 p.m.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Return: 1:30 p.m.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Return: 1:30 p.m.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** schedule, location

#### W3S1-Q05 — Developing / text_type / reading_comprehension

Which text type best describes the mangrove passage?

• **A. An invitation to a music show.** — Tidak tepat. Opsi “An invitation to a music show.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
• **B. A procedure for building a boat.** — Tidak tepat. Opsi “A procedure for building a boat.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
• **C. A personal recount of a beach holiday.** — Tidak tepat. Opsi “A personal recount of a beach holiday.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
✅ **D. A report about a type of coastal ecosystem.** — Benar. Pilihan “A report about a type of coastal ecosystem.” menjawab pertanyaan dan didukung oleh bukti: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.

**Kunci:** D. A report about a type of coastal ecosystem.
**Penjelasan guru:** Jawaban D benar karena “A report about a type of coastal ecosystem.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** general, describe

#### W3S1-Q06 — Developing / explicit_detail / reading_comprehension

What do mangrove roots help to do?

• **A. Remove all storm water.** — Tidak tepat. Opsi “Remove all storm water.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their roots help hold soil in place and slow the movement of water near the shore.”.
• **B. Increase the salt level in rivers.** — Tidak tepat. Opsi “Increase the salt level in rivers.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their roots help hold soil in place and slow the movement of water near the shore.”.
• **C. Stop every coastal flood.** — Tidak tepat. Opsi “Stop every coastal flood.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Their roots help hold soil in place and slow the movement of water near the shore.”.
✅ **D. Hold soil in place.** — Benar. Pilihan “Hold soil in place.” menjawab pertanyaan dan didukung oleh bukti: “Their roots help hold soil in place and slow the movement of water near the shore.”.

**Kunci:** D. Hold soil in place.
**Penjelasan guru:** Jawaban D benar karena “Hold soil in place.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Their roots help hold soil in place and slow the movement of water near the shore.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Their roots help hold soil in place and slow the movement of water near the shore.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** protect, increase

#### W3S1-Q07 — Medium / main_idea / reading_comprehension

Which is the best main idea?

• **A. Mangroves grow only in fresh water.** — Tidak tepat. Opsi “Mangroves grow only in fresh water.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”.
• **B. Mangroves are useful only for timber.** — Tidak tepat. Opsi “Mangroves are useful only for timber.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”.
• **C. Mangroves prevent every natural disaster.** — Tidak tepat. Opsi “Mangroves prevent every natural disaster.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”.
✅ **D. Mangroves support coastal ecosystems and communities but face human-related threats.** — Benar. Pilihan “Mangroves support coastal ecosystems and communities but face human-related threats.” menjawab pertanyaan dan didukung oleh bukti: “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”.

**Kunci:** D. Mangroves support coastal ecosystems and communities but face human-related threats.
**Penjelasan guru:** Jawaban D benar karena “Mangroves support coastal ecosystems and communities but face human-related threats.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Mangroves therefore support biodiversity as well as nearby communities.” “However, these forests can be damaged by pollution, land development and the removal of trees.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, general

#### W3S1-Q08 — Medium / evidence_multiple_details / reading_comprehension

Why are mangroves described as a nursery area?

• **A. They contain only adult fish.** — Tidak tepat. Opsi “They contain only adult fish.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
• **B. They are used to store boats during winter.** — Tidak tepat. Opsi “They are used to store boats during winter.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
• **C. They are built by local communities.** — Tidak tepat. Opsi “They are built by local communities.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
✅ **D. Their roots provide a protected place for young fish and other animals.** — Benar. Pilihan “Their roots provide a protected place for young fish and other animals.” menjawab pertanyaan dan didukung oleh bukti: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.

**Kunci:** D. Their roots provide a protected place for young fish and other animals.
**Penjelasan guru:** Jawaban D benar karena “Their roots provide a protected place for young fish and other animals.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** specific, detail

#### W3S1-Q09 — Easy / vocabulary_in_context / vocabulary

In the passage, “coastal” means ...

• **A. connected with city transport** — Tidak tepat. Opsi “connected with city transport” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”.
• **B. found only on mountains** — Tidak tepat. Opsi “found only on mountains” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”.
✅ **C. related to the area beside the sea** — Benar. Pilihan “related to the area beside the sea” menjawab pertanyaan dan didukung oleh bukti: “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”.
• **D. located in a dry desert** — Tidak tepat. Opsi “located in a dry desert” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”.

**Kunci:** C. related to the area beside the sea
**Penjelasan guru:** Jawaban C benar karena “related to the area beside the sea” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Mangrove forests grow along tropical and subtropical coastlines, where land meets salty or brackish water.”
**Target kosakata:** coastal
**Supporting vocabulary:** location

#### W3S1-Q10 — Developing / vocabulary_in_context / vocabulary

What is “erosion” in the context of a coastline?

• **A. The arrival of a group of visitors.** — Tidak tepat. Opsi “The arrival of a group of visitors.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
• **B. The growth of new leaves.** — Tidak tepat. Opsi “The growth of new leaves.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
✅ **C. The gradual wearing away of land.** — Benar. Pilihan “The gradual wearing away of land.” menjawab pertanyaan dan didukung oleh bukti: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.
• **D. The storage of fresh water.** — Tidak tepat. Opsi “The storage of fresh water.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”.

**Kunci:** C. The gradual wearing away of land.
**Penjelasan guru:** Jawaban C benar karena “The gradual wearing away of land.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “This can reduce coastal erosion—the gradual wearing away of land along the shore—although mangroves cannot prevent every storm or flood.”
**Target kosakata:** erosion
**Supporting vocabulary:** protect

#### W3S1-Q11 — Medium / vocabulary_in_context / vocabulary

In the passage, what does “sediment” refer to?

• **A. a tall tree that grows on the coast** — Tidak tepat. Opsi “a tall tree that grows on the coast” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”.
• **B. a timetable for a field trip** — Tidak tepat. Opsi “a timetable for a field trip” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”.
• **C. a group of people guiding visitors** — Tidak tepat. Opsi “a group of people guiding visitors” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”.
✅ **D. material such as small particles that settles on the bottom** — Benar. Pilihan “material such as small particles that settles on the bottom” menjawab pertanyaan dan didukung oleh bukti: “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”.

**Kunci:** D. material such as small particles that settles on the bottom
**Penjelasan guru:** Jawaban D benar karena “material such as small particles that settles on the bottom” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Small organisms live among fallen leaves and fine sediment—tiny particles of sand and soil that settle on the shore—providing food for parts of the coastal food web.”
**Target kosakata:** sediment
**Supporting vocabulary:** specific

#### W3S1-Q12 — Medium / vocabulary_relation / vocabulary

Which word is closest in meaning to “nursery” in the ecological phrase “nursery area”?

• **A. A market where fish are sold** — Tidak tepat. Opsi “A market where fish are sold” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
✅ **B. A protected place where young animals develop** — Benar. Pilihan “A protected place where young animals develop” menjawab pertanyaan dan didukung oleh bukti: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
• **C. A place where adult animals sleep only** — Tidak tepat. Opsi “A place where adult animals sleep only” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.
• **D. A building where school lessons take place** — Tidak tepat. Opsi “A building where school lessons take place” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”.

**Kunci:** B. A protected place where young animals develop
**Penjelasan guru:** Jawaban B benar karena “A protected place where young animals develop” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The tangled roots also create a protected nursery area where young fish and other animals can grow safely.”
**Target kosakata:** nursery
**Supporting vocabulary:** purpose

# W3-ONLINE-02 — Scanning and Evidence: Mangrove Restoration

**Kesulitan:** Easy 2 | Developing 4 | Medium 6
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **restore** (verb; NEW) — memulihkan. Contoh: *The team works to restore the damaged area.* Sinonim/terkait: repair, bring back. Antonim/kontras: damage (kontekstual).
- **buffer** (noun; NEW) — penyangga/perisai alami. Contoh: *Mangroves form a buffer between sea and land.* Sinonim/terkait: barrier, protection. Antonim/kontras: —.
- **biodiversity** (noun; NEW) — keanekaragaman hayati. Contoh: *The habitat supports biodiversity.* Sinonim/terkait: variety of life. Antonim/kontras: —.
- **habitat** (noun; NEW) — habitat/tempat hidup. Contoh: *The roots provide habitat for young animals.* Sinonim/terkait: natural home, environment. Antonim/kontras: —.
- **coastal** (adjective; RECYCLED) — pesisir. Contoh: *Mangroves grow in coastal areas.* Sinonim/terkait: shoreline-related. Antonim/kontras: inland (kontekstual).
- **erosion** (noun; RECYCLED) — erosi/pengikisan. Contoh: *Roots can reduce soil erosion.* Sinonim/terkait: wearing away. Antonim/kontras: deposition (proses berbeda).
- **sediment** (noun; RECYCLED) — sedimen/endapan. Contoh: *Water can carry sediment to the coast.* Sinonim/terkait: deposited material. Antonim/kontras: —.
- **nursery** (noun; RECYCLED) — area pembesaran satwa muda. Contoh: *A mangrove nursery supports young fish.* Sinonim/terkait: breeding/growing area. Antonim/kontras: —.
- **protect** (verb; RECYCLED) — melindungi. Contoh: *Mangrove roots help protect the coast.* Sinonim/terkait: guard, defend, preserve. Antonim/kontras: harm, endanger.
- **record** (verb/noun; RECYCLED) — mencatat; catatan. Contoh: *Students record changes in plant growth.* Sinonim/terkait: write down; report. Antonim/kontras: —.

### Stimulus

#### W3S2-T1 — Restoring a Mangrove Edge

**Genre:** Informational / report | **Jumlah kata:** 130 | **Estimasi:** A2+/B1-inspired

A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land. Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area. However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings. Local teams first need to understand water movement, soil conditions and the species that naturally grow there. They may also remove rubbish and protect young plants from being trampled. A restoration project should be monitored over time because some seedlings may not survive. Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.

**Basis referensi:** SRC-05, SRC-06

#### W3S2-T2 — Community Mangrove Day — Field Record

**Genre:** Recount / field report | **Jumlah kata:** 126 | **Estimasi:** A2+/B1-inspired

On 12 June, our class joined a community mangrove day near the estuary. The local guide first explained why the area had become damaged. Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area. We collected plastic rubbish from the paths, but we did not pull plants out of the mud. After lunch, the guide showed us a map of the restoration area. It included sections that needed more observation and places where new plants might be added later. Before leaving, our group discussed how to explain the project to other students. We learned that restoration takes time and that careful monitoring is as important as planting.

**Basis referensi:** SRC-05, SRC-06, SRC-07
**Catatan skenario:** Kelas, tanggal, dan kegiatan lapangan merupakan skenario latihan fiktif.

### Pembahasan soal

#### W3S2-Q01 — Easy / explicit_detail / reading_comprehension

What can mangrove roots help trap?

• **A. School equipment** — Tidak tepat. Opsi “School equipment” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **B. Traffic signs** — Tidak tepat. Opsi “Traffic signs” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
✅ **C. Sediment** — Benar. Pilihan “Sediment” menjawab pertanyaan dan didukung oleh bukti: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **D. Plastic bottles only** — Tidak tepat. Opsi “Plastic bottles only” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.

**Kunci:** C. Sediment
**Penjelasan guru:** Jawaban C benar karena “Sediment” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”
**Target kosakata:** protect
**Supporting vocabulary:** specific

#### W3S2-Q02 — Easy / explicit_detail / reading_comprehension

When did the class join the mangrove activity?

• **A. 16 June** — Tidak tepat. Opsi “16 June” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “On 12 June, our class joined a community mangrove day near the estuary.”.
• **B. 22 June** — Tidak tepat. Opsi “22 June” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “On 12 June, our class joined a community mangrove day near the estuary.”.
• **C. 12 July** — Tidak tepat. Opsi “12 July” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “On 12 June, our class joined a community mangrove day near the estuary.”.
✅ **D. 12 June** — Benar. Pilihan “12 June” menjawab pertanyaan dan didukung oleh bukti: “On 12 June, our class joined a community mangrove day near the estuary.”.

**Kunci:** D. 12 June
**Penjelasan guru:** Jawaban D benar karena “12 June” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “On 12 June, our class joined a community mangrove day near the estuary.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “On 12 June, our class joined a community mangrove day near the estuary.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** event, date

#### W3S2-Q03 — Developing / sequence / reading_comprehension

What did the guide do before the groups checked their sections?

✅ **A. Explained why the area had become damaged.** — Benar. Pilihan “Explained why the area had become damaged.” menjawab pertanyaan dan didukung oleh bukti: “The local guide first explained why the area had become damaged.”.
• **B. Counted the plants for every group.** — Tidak tepat. Opsi “Counted the plants for every group.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The local guide first explained why the area had become damaged.”.
• **C. Showed the restoration map.** — Tidak tepat. Opsi “Showed the restoration map.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The local guide first explained why the area had become damaged.”.
• **D. Asked students to leave the site.** — Tidak tepat. Opsi “Asked students to leave the site.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The local guide first explained why the area had become damaged.”.

**Kunci:** A. Explained why the area had become damaged.
**Penjelasan guru:** Jawaban A benar karena “Explained why the area had become damaged.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The local guide first explained why the area had become damaged.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The local guide first explained why the area had become damaged.”
**Target kosakata:** record
**Supporting vocabulary:** sequence

#### W3S2-Q04 — Developing / purpose / reading_comprehension

What is the main purpose of the informational passage?

• **A. To give instructions for building a fishing boat.** — Tidak tepat. Opsi “To give instructions for building a fishing boat.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
• **B. To retell a family holiday.** — Tidak tepat. Opsi “To retell a family holiday.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
✅ **C. To explain why mangrove restoration needs planning and monitoring.** — Benar. Pilihan “To explain why mangrove restoration needs planning and monitoring.” menjawab pertanyaan dan didukung oleh bukti: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
• **D. To advertise a new beach resort.** — Tidak tepat. Opsi “To advertise a new beach resort.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.

**Kunci:** C. To explain why mangrove restoration needs planning and monitoring.
**Penjelasan guru:** Jawaban C benar karena “To explain why mangrove restoration needs planning and monitoring.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, improve

#### W3S2-Q05 — Developing / evidence / reading_comprehension

Why did the students record the number of healthy young plants?

• **A. To calculate the price of the trip.** — Tidak tepat. Opsi “To calculate the price of the trip.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”.
• **B. To decide which students could go home.** — Tidak tepat. Opsi “To decide which students could go home.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”.
• **C. To count plastic bottles for sale.** — Tidak tepat. Opsi “To count plastic bottles for sale.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”.
✅ **D. To monitor the condition of the restoration area.** — Benar. Pilihan “To monitor the condition of the restoration area.” menjawab pertanyaan dan didukung oleh bukti: “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”.

**Kunci:** D. To monitor the condition of the restoration area.
**Penjelasan guru:** Jawaban D benar karena “To monitor the condition of the restoration area.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Then, each group checked a marked section and recorded the number of young plants that were still healthy. This record helped us monitor the condition of the restoration area.”
**Target kosakata:** record
**Supporting vocabulary:** detail

#### W3S2-Q06 — Medium / scanning_strategy / strategy_transfer

You need to locate what happened after lunch quickly. Which time or sequence marker should you scan for first?

• **A. On 12 June** — Tidak tepat. Opsi “On 12 June” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After lunch, the guide showed us a map of the restoration area.”.
• **B. Then** — Tidak tepat. Opsi “Then” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After lunch, the guide showed us a map of the restoration area.”.
✅ **C. After lunch** — Benar. Pilihan “After lunch” menjawab pertanyaan dan didukung oleh bukti: “After lunch, the guide showed us a map of the restoration area.”.
• **D. Before leaving** — Tidak tepat. Opsi “Before leaving” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “After lunch, the guide showed us a map of the restoration area.”.

**Kunci:** C. After lunch
**Penjelasan guru:** Jawaban C benar karena “After lunch” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “After lunch, the guide showed us a map of the restoration area.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “After lunch, the guide showed us a map of the restoration area.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** specific, sequence

#### W3S2-Q07 — Medium / main_idea / reading_comprehension

Which statement best expresses the main idea?

• **A. Mangroves grow best when all rubbish is buried in the soil.** — Tidak tepat. Opsi “Mangroves grow best when all rubbish is buried in the soil.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
• **B. Planting more seedlings always guarantees success.** — Tidak tepat. Opsi “Planting more seedlings always guarantees success.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
✅ **C. Mangrove recovery requires suitable natural conditions, monitoring and community cooperation.** — Benar. Pilihan “Mangrove recovery requires suitable natural conditions, monitoring and community cooperation.” menjawab pertanyaan dan didukung oleh bukti: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.
• **D. Restoration is complete as soon as the first seedlings are planted.** — Tidak tepat. Opsi “Restoration is complete as soon as the first seedlings are planted.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”.

**Kunci:** C. Mangrove recovery requires suitable natural conditions, monitoring and community cooperation.
**Penjelasan guru:** Jawaban C benar karena “Mangrove recovery requires suitable natural conditions, monitoring and community cooperation.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.” “Healthy recovery depends on suitable conditions, careful planning and cooperation with nearby communities.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** general, improve

#### W3S2-Q08 — Medium / explicit_detail / reading_comprehension

Which three factors should local teams understand before restoring a shoreline?

• **A. Road signs, sports equipment and building materials** — Tidak tepat. Opsi “Road signs, sports equipment and building materials” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”.
• **B. The age of visitors, food choices and classroom size** — Tidak tepat. Opsi “The age of visitors, food choices and classroom size” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”.
✅ **C. Water movement, soil conditions and local plant species** — Benar. Pilihan “Water movement, soil conditions and local plant species” menjawab pertanyaan dan didukung oleh bukti: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”.
• **D. Ticket prices, school schedules and bus routes** — Tidak tepat. Opsi “Ticket prices, school schedules and bus routes” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”.

**Kunci:** C. Water movement, soil conditions and local plant species
**Penjelasan guru:** Jawaban C benar karena “Water movement, soil conditions and local plant species” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Local teams first need to understand water movement, soil conditions and the species that naturally grow there.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** specific, detail

#### W3S2-Q09 — Medium / vocabulary_in_context / vocabulary

In the passage, a “buffer” is something that ...

• **A. replaces every plant in a forest** — Tidak tepat. Opsi “replaces every plant in a forest” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”.
✅ **B. reduces the force or impact between two areas** — Benar. Pilihan “reduces the force or impact between two areas” menjawab pertanyaan dan didukung oleh bukti: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”.
• **C. measures the height of a tree** — Tidak tepat. Opsi “measures the height of a tree” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”.
• **D. makes a place more crowded** — Tidak tepat. Opsi “makes a place more crowded” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”.

**Kunci:** B. reduces the force or impact between two areas
**Penjelasan guru:** Jawaban B benar karena “reduces the force or impact between two areas” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A mangrove forest can act as a natural buffer, reducing some of the force between the sea and the land.”
**Target kosakata:** buffer, protect
**Supporting vocabulary:** —

#### W3S2-Q10 — Developing / vocabulary_in_context / vocabulary

Which word is closest in meaning to “restore” in “a damaged shoreline cannot be restored simply by planting…”?

✅ **A. Repair or bring back to a healthier condition.** — Benar. Pilihan “Repair or bring back to a healthier condition.” menjawab pertanyaan dan didukung oleh bukti: “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”.
• **B. Move to another country.** — Tidak tepat. Opsi “Move to another country.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”.
• **C. Describe in a report.** — Tidak tepat. Opsi “Describe in a report.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”.
• **D. Make more expensive.** — Tidak tepat. Opsi “Make more expensive.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”.

**Kunci:** A. Repair or bring back to a healthier condition.
**Penjelasan guru:** Jawaban A benar karena “Repair or bring back to a healthier condition.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “However, a damaged shoreline cannot be restored, or brought back to a healthier condition, simply by planting a large number of seedlings.”
**Target kosakata:** restore
**Supporting vocabulary:** improve

#### W3S2-Q11 — Medium / synonym_context / vocabulary

In the passage, what does “habitat” mean?

• **A. A timetable for a school activity** — Tidak tepat. Opsi “A timetable for a school activity” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **B. A tool used to measure rainfall** — Tidak tepat. Opsi “A tool used to measure rainfall” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
✅ **C. The natural home or living place of an organism** — Benar. Pilihan “The natural home or living place of an organism” menjawab pertanyaan dan didukung oleh bukti: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **D. A group of people who guide visitors** — Tidak tepat. Opsi “A group of people who guide visitors” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.

**Kunci:** C. The natural home or living place of an organism
**Penjelasan guru:** Jawaban C benar karena “The natural home or living place of an organism” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”
**Target kosakata:** habitat, protect, record
**Supporting vocabulary:** —

#### W3S2-Q12 — Medium / vocabulary_in_context / vocabulary

In the passage, “biodiversity” would most closely refer to ...

• **A. the age of the oldest tree only** — Tidak tepat. Opsi “the age of the oldest tree only” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
✅ **B. the variety of living things in an area** — Benar. Pilihan “the variety of living things in an area” menjawab pertanyaan dan didukung oleh bukti: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **C. the number of roads near a forest** — Tidak tepat. Opsi “the number of roads near a forest” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.
• **D. the amount of money for a project** — Tidak tepat. Opsi “the amount of money for a project” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”.

**Kunci:** B. the variety of living things in an area
**Penjelasan guru:** Jawaban B benar karena “the variety of living things in an area” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Its roots slow some waves and help trap sediment, while the forest provides habitat—the natural place where organisms live—for many organisms and supports biodiversity, the variety of living things in an area.”
**Target kosakata:** biodiversity, habitat
**Supporting vocabulary:** —

# W4-ONLINE-01 — Vocabulary Relations: Travel Choices

**Kesulitan:** Easy 2 | Developing 4 | Medium 6
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **commute** (noun/verb; NEW) — perjalanan rutin ke sekolah/kerja. Contoh: *Her daily commute takes twenty minutes.* Sinonim/terkait: daily journey, travel to work/school. Antonim/kontras: —.
- **efficient** (adjective; NEW) — efisien. Contoh: *Cycling can be efficient for short journeys.* Sinonim/terkait: effective, economical. Antonim/kontras: inefficient.
- **durable** (adjective; NEW) — tahan lama. Contoh: *A durable plan can continue over time.* Sinonim/terkait: long-lasting, sturdy. Antonim/kontras: temporary (kontekstual).
- **alternative** (noun/adjective; NEW) — pilihan lain/alternatif. Contoh: *Public transport is an alternative to driving.* Sinonim/terkait: another option, substitute. Antonim/kontras: —.
- **restore** (verb; RECYCLED) — memulihkan. Contoh: *The team works to restore the damaged area.* Sinonim/terkait: repair, bring back. Antonim/kontras: damage (kontekstual).
- **buffer** (noun; RECYCLED) — penyangga/perisai alami. Contoh: *Mangroves form a buffer between sea and land.* Sinonim/terkait: barrier, protection. Antonim/kontras: —.
- **biodiversity** (noun; RECYCLED) — keanekaragaman hayati. Contoh: *The habitat supports biodiversity.* Sinonim/terkait: variety of life. Antonim/kontras: —.
- **habitat** (noun; RECYCLED) — habitat/tempat hidup. Contoh: *The roots provide habitat for young animals.* Sinonim/terkait: natural home, environment. Antonim/kontras: —.
- **improve** (verb; RECYCLED) — meningkatkan/memperbaiki. Contoh: *The project aims to improve the shoreline.* Sinonim/terkait: develop, make better. Antonim/kontras: worsen.
- **reduce** (verb; RECYCLED) — mengurangi. Contoh: *Walking can reduce short car journeys.* Sinonim/terkait: decrease, lower. Antonim/kontras: increase.

### Stimulus

#### W4S1-T1 — Choosing a Better Way to Travel

**Genre:** Informational / opinion-supported article | **Jumlah kata:** 133 | **Estimasi:** A2+/B1-inspired

A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment. When many people travel alone in private cars, roads become crowded and engines produce emissions. Walking, cycling and public transport are alternatives for some journeys. The most suitable choice depends on distance, road safety and the availability of services. A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well. Some schools encourage students to share rides or walk together when the route is safe. These changes will not solve every transport problem, but they can reduce the number of separate car journeys. A durable plan also needs regular review so that it continues to meet the community’s needs.

**Basis referensi:** SRC-03

#### W4S1-T2 — A Student Travel Survey

**Genre:** Report with simple data | **Jumlah kata:** 107 | **Estimasi:** A2+/B1-inspired

A school survey asked 120 students how they usually travelled to school. Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car. The survey team found that the number of students walking had increased since the previous term. However, some students explained that they did not cycle because the road near the school was busy. The team suggested discussing safer crossings with local officials. They also recommended keeping the bus service reliable. The survey did not prove that one travel method was best for everyone. Instead, it showed that students make different choices depending on distance, safety and available transport.

**Basis referensi:** SRC-03
**Catatan skenario:** Angka survei 120 siswa dan hasilnya merupakan data simulasi, bukan hasil survei sekolah nyata.

### Pembahasan soal

#### W4S1-Q01 — Easy / scanning_strategy / strategy_transfer

You need to locate the effect of many people travelling alone in private cars. Which phrase should you scan for first?

• **A. Walking, cycling and public transport** — Tidak tepat. Opsi “Walking, cycling and public transport” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “When many people travel alone in private cars, roads become crowded and engines produce emissions.”.
• **B. A well-planned bus route** — Tidak tepat. Opsi “A well-planned bus route” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “When many people travel alone in private cars, roads become crowded and engines produce emissions.”.
✅ **C. Roads become crowded and engines produce emissions** — Benar. Pilihan “Roads become crowded and engines produce emissions” menjawab pertanyaan dan didukung oleh bukti: “When many people travel alone in private cars, roads become crowded and engines produce emissions.”.
• **D. A durable plan** — Tidak tepat. Opsi “A durable plan” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “When many people travel alone in private cars, roads become crowded and engines produce emissions.”.

**Kunci:** C. Roads become crowded and engines produce emissions
**Penjelasan guru:** Jawaban C benar karena “Roads become crowded and engines produce emissions” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “When many people travel alone in private cars, roads become crowded and engines produce emissions.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “When many people travel alone in private cars, roads become crowded and engines produce emissions.”
**Target kosakata:** reduce
**Supporting vocabulary:** increase

#### W4S1-Q02 — Easy / vocabulary_context / vocabulary

What does “commute” mean in the passage?

• **A. A competition between buses.** — Tidak tepat. Opsi “A competition between buses.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”.
• **B. A short break during a lesson.** — Tidak tepat. Opsi “A short break during a lesson.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”.
• **C. A holiday in another country.** — Tidak tepat. Opsi “A holiday in another country.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”.
✅ **D. A regular journey between home and school or work.** — Benar. Pilihan “A regular journey between home and school or work.” menjawab pertanyaan dan didukung oleh bukti: “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”.

**Kunci:** D. A regular journey between home and school or work.
**Penjelasan guru:** Jawaban D benar karena “A regular journey between home and school or work.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A short daily commute—the regular journey between home and school or work—can still have an effect on a town’s environment.”
**Target kosakata:** commute
**Supporting vocabulary:** schedule

#### W4S1-Q03 — Developing / main_idea / reading_comprehension

Which is the best main idea?

• **A. Public transport is always the fastest option.** — Tidak tepat. Opsi “Public transport is always the fastest option.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
• **B. All students should cycle to school every day.** — Tidak tepat. Opsi “All students should cycle to school every day.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
✅ **C. Different travel choices can affect the environment, and safer alternatives may reduce separate car trips.** — Benar. Pilihan “Different travel choices can affect the environment, and safer alternatives may reduce separate car trips.” menjawab pertanyaan dan didukung oleh bukti: “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
• **D. Private cars are the only reliable form of transport.** — Tidak tepat. Opsi “Private cars are the only reliable form of transport.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”.

**Kunci:** C. Different travel choices can affect the environment, and safer alternatives may reduce separate car trips.
**Penjelasan guru:** Jawaban C benar karena “Different travel choices can affect the environment, and safer alternatives may reduce separate car trips.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “These changes will not solve every transport problem, but they can reduce the number of separate car journeys.” “A durable plan also needs regular review so that it continues to meet the community’s needs.”
**Target kosakata:** improve
**Supporting vocabulary:** purpose

#### W4S1-Q04 — Developing / explicit_detail / reading_comprehension

How many students travelled by bicycle?

• **A. 48** — Tidak tepat. Opsi “48” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”.
• **B. 18** — Tidak tepat. Opsi “18” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”.
✅ **C. 24** — Benar. Pilihan “24” menjawab pertanyaan dan didukung oleh bukti: “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”.
• **D. 30** — Tidak tepat. Opsi “30” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”.

**Kunci:** C. 24
**Penjelasan guru:** Jawaban C benar karena “24” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Forty-eight students came by bus, 30 walked, 24 travelled by bicycle and 18 arrived by private car.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** amount, specific

#### W4S1-Q05 — Developing / purpose / reading_comprehension

What is the main purpose of the survey passage?

✅ **A. To report travel patterns and suggestions from a school survey.** — Benar. Pilihan “To report travel patterns and suggestions from a school survey.” menjawab pertanyaan dan didukung oleh bukti: “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”.
• **B. To tell a fictional story about a bus driver.** — Tidak tepat. Opsi “To tell a fictional story about a bus driver.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”.
• **C. To advertise a new bicycle brand.** — Tidak tepat. Opsi “To advertise a new bicycle brand.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”.
• **D. To provide steps for repairing a road.** — Tidak tepat. Opsi “To provide steps for repairing a road.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”.

**Kunci:** A. To report travel patterns and suggestions from a school survey.
**Penjelasan guru:** Jawaban A benar karena “To report travel patterns and suggestions from a school survey.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A school survey asked 120 students how they usually travelled to school.” “The survey did not prove that one travel method was best for everyone.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, detail

#### W4S1-Q06 — Developing / explicit_detail / reading_comprehension

Why might some students avoid cycling to school?

✅ **A. They consider the road near the school busy.** — Benar. Pilihan “They consider the road near the school busy.” menjawab pertanyaan dan didukung oleh bukti: “However, some students explained that they did not cycle because the road near the school was busy.”.
• **B. They have no interest in travelling.** — Tidak tepat. Opsi “They have no interest in travelling.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, some students explained that they did not cycle because the road near the school was busy.”.
• **C. The bus service is free for everyone.** — Tidak tepat. Opsi “The bus service is free for everyone.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, some students explained that they did not cycle because the road near the school was busy.”.
• **D. The school has banned all bicycles.** — Tidak tepat. Opsi “The school has banned all bicycles.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “However, some students explained that they did not cycle because the road near the school was busy.”.

**Kunci:** A. They consider the road near the school busy.
**Penjelasan guru:** Jawaban A benar karena “They consider the road near the school busy.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “However, some students explained that they did not cycle because the road near the school was busy.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “However, some students explained that they did not cycle because the road near the school was busy.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** safe, reason

#### W4S1-Q07 — Medium / vocabulary_relation / vocabulary

Which phrase is closest in meaning to “efficient for short trips” in this context?

✅ **A. Uses time or resources well on short journeys.** — Benar. Pilihan “Uses time or resources well on short journeys.” menjawab pertanyaan dan didukung oleh bukti: “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”.
• **B. Requires a much longer route.** — Tidak tepat. Opsi “Requires a much longer route.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”.
• **C. Costs more money on every journey.** — Tidak tepat. Opsi “Costs more money on every journey.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”.
• **D. Cannot be used in a town.** — Tidak tepat. Opsi “Cannot be used in a town.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”.

**Kunci:** A. Uses time or resources well on short journeys.
**Penjelasan guru:** Jawaban A benar karena “Uses time or resources well on short journeys.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A well-planned bus route may carry many passengers at once, while cycling can be efficient for short trips because it uses time and resources well.”
**Target kosakata:** efficient
**Supporting vocabulary:** available

#### W4S1-Q08 — Medium / antonym_context / vocabulary

Which word is the best opposite of “durable” in the phrase “a durable plan”?

• **A. Careful** — Tidak tepat. Opsi “Careful” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
• **B. Useful** — Tidak tepat. Opsi “Useful” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
✅ **C. Temporary** — Benar. Pilihan “Temporary” menjawab pertanyaan dan didukung oleh bukti: “A durable plan also needs regular review so that it continues to meet the community’s needs.”.
• **D. Reliable** — Tidak tepat. Opsi “Reliable” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A durable plan also needs regular review so that it continues to meet the community’s needs.”.

**Kunci:** C. Temporary
**Penjelasan guru:** Jawaban C benar karena “Temporary” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A durable plan also needs regular review so that it continues to meet the community’s needs.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A durable plan also needs regular review so that it continues to meet the community’s needs.”
**Target kosakata:** durable, improve
**Supporting vocabulary:** —

#### W4S1-Q09 — Medium / vocabulary_in_context / vocabulary

Which word is closest in meaning to “alternative” as used in the passage?

• **A. A traffic accident** — Tidak tepat. Opsi “A traffic accident” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Walking, cycling and public transport are alternatives for some journeys.”.
✅ **B. Another possible choice** — Benar. Pilihan “Another possible choice” menjawab pertanyaan dan didukung oleh bukti: “Walking, cycling and public transport are alternatives for some journeys.”.
• **C. A fixed rule** — Tidak tepat. Opsi “A fixed rule” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Walking, cycling and public transport are alternatives for some journeys.”.
• **D. A final result** — Tidak tepat. Opsi “A final result” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Walking, cycling and public transport are alternatives for some journeys.”.

**Kunci:** B. Another possible choice
**Penjelasan guru:** Jawaban B benar karena “Another possible choice” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Walking, cycling and public transport are alternatives for some journeys.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Walking, cycling and public transport are alternatives for some journeys.”
**Target kosakata:** alternative
**Supporting vocabulary:** purpose

#### W4S1-Q10 — Medium / explicit_detail / reading_comprehension

What change did the survey team notice about students who walked?

✅ **A. The number had increased since the previous term.** — Benar. Pilihan “The number had increased since the previous term.” menjawab pertanyaan dan didukung oleh bukti: “The survey team found that the number of students walking had increased since the previous term.”.
• **B. The number had fallen to zero.** — Tidak tepat. Opsi “The number had fallen to zero.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey team found that the number of students walking had increased since the previous term.”.
• **C. All students had changed to buses.** — Tidak tepat. Opsi “All students had changed to buses.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey team found that the number of students walking had increased since the previous term.”.
• **D. The number had stayed exactly the same.** — Tidak tepat. Opsi “The number had stayed exactly the same.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey team found that the number of students walking had increased since the previous term.”.

**Kunci:** A. The number had increased since the previous term.
**Penjelasan guru:** Jawaban A benar karena “The number had increased since the previous term.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The survey team found that the number of students walking had increased since the previous term.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The survey team found that the number of students walking had increased since the previous term.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** increase, decrease

#### W4S1-Q11 — Medium / explicit_detail / reading_comprehension

What did the survey team suggest discussing with local officials?

✅ **A. Safer crossings near the school** — Benar. Pilihan “Safer crossings near the school” menjawab pertanyaan dan didukung oleh bukti: “The team suggested discussing safer crossings with local officials.”.
• **B. A new bicycle brand** — Tidak tepat. Opsi “A new bicycle brand” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The team suggested discussing safer crossings with local officials.”.
• **C. The removal of the bus service** — Tidak tepat. Opsi “The removal of the bus service” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The team suggested discussing safer crossings with local officials.”.
• **D. A ban on walking to school** — Tidak tepat. Opsi “A ban on walking to school” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The team suggested discussing safer crossings with local officials.”.

**Kunci:** A. Safer crossings near the school
**Penjelasan guru:** Jawaban A benar karena “Safer crossings near the school” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The team suggested discussing safer crossings with local officials.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The team suggested discussing safer crossings with local officials.”
**Target kosakata:** efficient, improve
**Supporting vocabulary:** —

#### W4S1-Q12 — Medium / evidence / reading_comprehension

What did the survey NOT prove?

✅ **A. That one travel method was best for everyone** — Benar. Pilihan “That one travel method was best for everyone” menjawab pertanyaan dan didukung oleh bukti: “The survey did not prove that one travel method was best for everyone.”.
• **B. That students used different ways to travel** — Tidak tepat. Opsi “That students used different ways to travel” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey did not prove that one travel method was best for everyone.”.
• **C. That distance and safety affected travel choices** — Tidak tepat. Opsi “That distance and safety affected travel choices” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey did not prove that one travel method was best for everyone.”.
• **D. That transport availability influenced decisions** — Tidak tepat. Opsi “That transport availability influenced decisions” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The survey did not prove that one travel method was best for everyone.”.

**Kunci:** A. That one travel method was best for everyone
**Penjelasan guru:** Jawaban A benar karena “That one travel method was best for everyone” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The survey did not prove that one travel method was best for everyone.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The survey did not prove that one travel method was best for everyone.”
**Target kosakata:** reduce
**Supporting vocabulary:** increase

# W4-ONLINE-02 — Cumulative Vocabulary: Library Resources and Paraphrase

**Kesulitan:** Easy 1 | Developing 4 | Medium 7
**Peran:** Reading 7 | Vocabulary 4 | Strategy transfer 1

### Vocabulary cards

- **preserve** (verb; NEW) — melestarikan/menjaga kondisi. Contoh: *Staff preserve books by handling them carefully.* Sinonim/terkait: protect, maintain. Antonim/kontras: damage, destroy (kontekstual).
- **access** (noun/verb; NEW) — akses/kesempatan menggunakan. Contoh: *Students have access to the library.* Sinonim/terkait: entry, opportunity to use. Antonim/kontras: restriction (kontekstual).
- **resource** (noun; NEW) — sumber daya/bahan yang dapat digunakan. Contoh: *Books and computers are learning resources.* Sinonim/terkait: material, supply. Antonim/kontras: —.
- **feature** (noun; NEW) — ciri/fitur/karakteristik. Contoh: *Quiet study space is a useful feature.* Sinonim/terkait: characteristic, aspect. Antonim/kontras: —.
- **commute** (noun/verb; RECYCLED) — perjalanan rutin ke sekolah/kerja. Contoh: *Her daily commute takes twenty minutes.* Sinonim/terkait: daily journey, travel to work/school. Antonim/kontras: —.
- **efficient** (adjective; RECYCLED) — efisien. Contoh: *Cycling can be efficient for short journeys.* Sinonim/terkait: effective, economical. Antonim/kontras: inefficient.
- **durable** (adjective; RECYCLED) — tahan lama. Contoh: *A durable plan can continue over time.* Sinonim/terkait: long-lasting, sturdy. Antonim/kontras: temporary (kontekstual).
- **alternative** (noun/adjective; RECYCLED) — pilihan lain/alternatif. Contoh: *Public transport is an alternative to driving.* Sinonim/terkait: another option, substitute. Antonim/kontras: —.
- **require** (verb; RECYCLED) — membutuhkan/mewajibkan. Contoh: *The service requires a library card.* Sinonim/terkait: need, demand (kontekstual). Antonim/kontras: waive (formal/kontekstual).
- **available** (adjective; RECYCLED) — tersedia. Contoh: *Clean water is available near the garden.* Sinonim/terkait: obtainable, ready. Antonim/kontras: unavailable.

### Stimulus

#### W4S2-T1 — A Library That Shares Resources

**Genre:** Informational / article | **Jumlah kata:** 106 | **Estimasi:** A2+/B1-inspired

A community library is more than a room full of books. It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials. Some libraries also organise reading clubs and short workshops. These features help people with different needs use the same public space. To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials. Digital resources can make some information easier to find, but they do not replace every printed book or face-to-face activity. A good library offers choices and helps readers select the resource that fits their purpose.

**Basis referensi:** SRC-03

#### W4S2-T2 — A Message About the Library Collection

**Genre:** Email / message | **Jumlah kata:** 105 | **Estimasi:** A2+/B1-inspired

To: Reading Club Members
Subject: New collection and borrowing rules
Hello everyone,
The library will begin a two-week trial of a new borrowing service on 4 December. Members may borrow up to three books at a time. Each book must be returned within 14 days. The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days. Please keep the books in good condition and report any damage when you return them. The trial will finish on 17 December. After that date, the library team will review the results before deciding whether to continue the service.
Best wishes,
Library Team

**Basis referensi:** SRC-03, SRC-08
**Catatan skenario:** Jadwal uji coba dan aturan layanan merupakan skenario latihan fiktif.

### Pembahasan soal

#### W4S2-Q01 — Easy / explicit_detail / reading_comprehension

Which resource is mentioned in the passage?

• **A. Cooking equipment** — Tidak tepat. Opsi “Cooking equipment” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”.
• **B. Bus tickets** — Tidak tepat. Opsi “Bus tickets” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”.
• **C. Sports uniforms** — Tidak tepat. Opsi “Sports uniforms” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”.
✅ **D. Dictionaries** — Benar. Pilihan “Dictionaries” menjawab pertanyaan dan didukung oleh bukti: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”.

**Kunci:** D. Dictionaries
**Penjelasan guru:** Jawaban D benar karena “Dictionaries” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.”
**Target kosakata:** resource, available
**Supporting vocabulary:** —

#### W4S2-Q02 — Developing / main_idea / reading_comprehension

Which is the best main idea?

• **A. Visitors may borrow as many books as they want.** — Tidak tepat. Opsi “Visitors may borrow as many books as they want.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”.
• **B. A library should lend only printed novels.** — Tidak tepat. Opsi “A library should lend only printed novels.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”.
✅ **C. A community library provides shared learning resources and services for different users.** — Benar. Pilihan “A community library provides shared learning resources and services for different users.” menjawab pertanyaan dan didukung oleh bukti: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”.
• **D. Digital resources make all printed materials unnecessary.** — Tidak tepat. Opsi “Digital resources make all printed materials unnecessary.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”.

**Kunci:** C. A community library provides shared learning resources and services for different users.
**Penjelasan guru:** Jawaban C benar karena “A community library provides shared learning resources and services for different users.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “A good library offers choices and helps readers select the resource that fits their purpose.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** purpose, general

#### W4S2-Q03 — Developing / explicit_detail / reading_comprehension

Which services can the community library provide besides lending books?

✅ **A. Quiet study space, reading clubs and short workshops** — Benar. Pilihan “Quiet study space, reading clubs and short workshops” menjawab pertanyaan dan didukung oleh bukti: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”.
• **B. Free transport to every school** — Tidak tepat. Opsi “Free transport to every school” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”.
• **C. Medical treatment and sports equipment** — Tidak tepat. Opsi “Medical treatment and sports equipment” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”.
• **D. A place to sell private computers** — Tidak tepat. Opsi “A place to sell private computers” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”.

**Kunci:** A. Quiet study space, reading clubs and short workshops
**Penjelasan guru:** Jawaban A benar karena “Quiet study space, reading clubs and short workshops” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “It can provide access to information, quiet study space and shared resources such as dictionaries, computers and learning materials.” “Some libraries also organise reading clubs and short workshops.”
**Target kosakata:** access, available
**Supporting vocabulary:** —

#### W4S2-Q04 — Medium / paraphrase / vocabulary

Which sentence best paraphrases “A good library offers choices and helps readers select the resource that fits their purpose”?

• **A. A good library keeps all resources away from visitors.** — Tidak tepat. Opsi “A good library keeps all resources away from visitors.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A good library offers choices and helps readers select the resource that fits their purpose.”.
✅ **B. A good library provides different resources so readers can choose what they need.** — Benar. Pilihan “A good library provides different resources so readers can choose what they need.” menjawab pertanyaan dan didukung oleh bukti: “A good library offers choices and helps readers select the resource that fits their purpose.”.
• **C. A good library requires every reader to choose the same book.** — Tidak tepat. Opsi “A good library requires every reader to choose the same book.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A good library offers choices and helps readers select the resource that fits their purpose.”.
• **D. A good library closes whenever readers have different purposes.** — Tidak tepat. Opsi “A good library closes whenever readers have different purposes.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “A good library offers choices and helps readers select the resource that fits their purpose.”.

**Kunci:** B. A good library provides different resources so readers can choose what they need.
**Penjelasan guru:** Jawaban B benar karena “A good library provides different resources so readers can choose what they need.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “A good library offers choices and helps readers select the resource that fits their purpose.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “A good library offers choices and helps readers select the resource that fits their purpose.”
**Target kosakata:** available
**Supporting vocabulary:** purpose

#### W4S2-Q05 — Developing / explicit_detail / reading_comprehension

How many books may a member borrow at one time?

✅ **A. Three** — Benar. Pilihan “Three” menjawab pertanyaan dan didukung oleh bukti: “Members may borrow up to three books at a time.”.
• **B. Four** — Tidak tepat. Opsi “Four” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Members may borrow up to three books at a time.”.
• **C. Two** — Tidak tepat. Opsi “Two” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Members may borrow up to three books at a time.”.
• **D. Five** — Tidak tepat. Opsi “Five” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Members may borrow up to three books at a time.”.

**Kunci:** A. Three
**Penjelasan guru:** Jawaban A benar karena “Three” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Members may borrow up to three books at a time.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Members may borrow up to three books at a time.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** amount, required

#### W4S2-Q06 — Medium / scanning_strategy / strategy_transfer

To locate the final day of the borrowing trial quickly, which phrase should you scan for?

• **A. Members may borrow up to three books at a time.** — Tidak tepat. Opsi “Members may borrow up to three books at a time.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The trial will finish on 17 December.”.
• **B. Each book must be returned within 14 days.** — Tidak tepat. Opsi “Each book must be returned within 14 days.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The trial will finish on 17 December.”.
✅ **C. The trial will finish on 17 December.** — Benar. Pilihan “The trial will finish on 17 December.” menjawab pertanyaan dan didukung oleh bukti: “The trial will finish on 17 December.”.
• **D. The service is available at the front desk from 8:00 a.m. to 3:00 p.m.** — Tidak tepat. Opsi “The service is available at the front desk from 8:00 a.m. to 3:00 p.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The trial will finish on 17 December.”.

**Kunci:** C. The trial will finish on 17 December.
**Penjelasan guru:** Jawaban C benar karena “The trial will finish on 17 December.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The trial will finish on 17 December.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The trial will finish on 17 December.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** begin, finish

#### W4S2-Q07 — Developing / purpose / reading_comprehension

Why was the message written?

• **A. To ask members to return every book immediately.** — Tidak tepat. Opsi “To ask members to return every book immediately.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”.
• **B. To invite members to buy books.** — Tidak tepat. Opsi “To invite members to buy books.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”.
• **C. To announce that the library has closed permanently.** — Tidak tepat. Opsi “To announce that the library has closed permanently.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”.
✅ **D. To explain a trial borrowing service and its rules.** — Benar. Pilihan “To explain a trial borrowing service and its rules.” menjawab pertanyaan dan didukung oleh bukti: “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”.

**Kunci:** D. To explain a trial borrowing service and its rules.
**Penjelasan guru:** Jawaban D benar karena “To explain a trial borrowing service and its rules.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Subject: New collection and borrowing rules” “The library will begin a two-week trial of a new borrowing service on 4 December.”
**Target kosakata:** require
**Supporting vocabulary:** purpose

#### W4S2-Q08 — Medium / meaning_preservation / vocabulary

Which statement keeps the meaning of “Each book must be returned within 14 days”?

• **A. Members are not allowed to borrow books for 14 days.** — Tidak tepat. Opsi “Members are not allowed to borrow books for 14 days.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Each book must be returned within 14 days.”.
• **B. Members should borrow each book for at least 14 days.** — Tidak tepat. Opsi “Members should borrow each book for at least 14 days.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Each book must be returned within 14 days.”.
• **C. Members may return each book whenever they want.** — Tidak tepat. Opsi “Members may return each book whenever they want.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Each book must be returned within 14 days.”.
✅ **D. Members are required to return each book within 14 days.** — Benar. Pilihan “Members are required to return each book within 14 days.” menjawab pertanyaan dan didukung oleh bukti: “Each book must be returned within 14 days.”.

**Kunci:** D. Members are required to return each book within 14 days.
**Penjelasan guru:** Jawaban D benar karena “Members are required to return each book within 14 days.” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Each book must be returned within 14 days.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Each book must be returned within 14 days.”
**Target kosakata:** require
**Supporting vocabulary:** allow

#### W4S2-Q09 — Medium / synonym_context / vocabulary

Which word is closest in meaning to “preserve” as used in the passage?

• **A. Sell at a higher price** — Tidak tepat. Opsi “Sell at a higher price” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”.
• **B. Replace immediately** — Tidak tepat. Opsi “Replace immediately” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”.
• **C. Hide permanently** — Tidak tepat. Opsi “Hide permanently” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”.
✅ **D. Protect and keep in good condition** — Benar. Pilihan “Protect and keep in good condition” menjawab pertanyaan dan didukung oleh bukti: “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”.

**Kunci:** D. Protect and keep in good condition
**Penjelasan guru:** Jawaban D benar karena “Protect and keep in good condition” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “To keep the service useful, staff must preserve books and equipment, update information and explain how visitors can borrow materials.”
**Target kosakata:** preserve
**Supporting vocabulary:** protect

#### W4S2-Q10 — Medium / explicit_detail / reading_comprehension

When is the borrowing service available?

✅ **A. From 8:00 a.m. to 3:00 p.m. on school days** — Benar. Pilihan “From 8:00 a.m. to 3:00 p.m. on school days” menjawab pertanyaan dan didukung oleh bukti: “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”.
• **B. Every evening until 8:00 p.m.** — Tidak tepat. Opsi “Every evening until 8:00 p.m.” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”.
• **C. Only on Saturdays** — Tidak tepat. Opsi “Only on Saturdays” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”.
• **D. From 7:00 a.m. to 12:00 p.m. every day** — Tidak tepat. Opsi “From 7:00 a.m. to 12:00 p.m. every day” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”.

**Kunci:** A. From 8:00 a.m. to 3:00 p.m. on school days
**Penjelasan guru:** Jawaban A benar karena “From 8:00 a.m. to 3:00 p.m. on school days” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “The service is available at the front desk from 8:00 a.m. to 3:00 p.m. on school days.”
**Target kosakata:** available, resource
**Supporting vocabulary:** —

#### W4S2-Q11 — Medium / explicit_detail / reading_comprehension

What should members do if they notice damage to a book?

✅ **A. Report the damage when they return the book** — Benar. Pilihan “Report the damage when they return the book” menjawab pertanyaan dan didukung oleh bukti: “Please keep the books in good condition and report any damage when you return them.”.
• **B. Keep the damage secret** — Tidak tepat. Opsi “Keep the damage secret” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please keep the books in good condition and report any damage when you return them.”.
• **C. Wait until the trial ends before telling staff** — Tidak tepat. Opsi “Wait until the trial ends before telling staff” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please keep the books in good condition and report any damage when you return them.”.
• **D. Buy a replacement book immediately** — Tidak tepat. Opsi “Buy a replacement book immediately” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “Please keep the books in good condition and report any damage when you return them.”.

**Kunci:** A. Report the damage when they return the book
**Penjelasan guru:** Jawaban A benar karena “Report the damage when they return the book” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “Please keep the books in good condition and report any damage when you return them.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “Please keep the books in good condition and report any damage when you return them.”
**Target kosakata:** Tidak ada target kartu eksplisit
**Supporting vocabulary:** begin, finish

#### W4S2-Q12 — Medium / vocabulary_in_context / vocabulary

In the passage, “features” most nearly means ...

• **A. places where buses stop** — Tidak tepat. Opsi “places where buses stop” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These features help people with different needs use the same public space.”.
✅ **B. important parts or characteristics** — Benar. Pilihan “important parts or characteristics” menjawab pertanyaan dan didukung oleh bukti: “These features help people with different needs use the same public space.”.
• **C. rules about returning books** — Tidak tepat. Opsi “rules about returning books” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These features help people with different needs use the same public space.”.
• **D. temporary visitors** — Tidak tepat. Opsi “temporary visitors” tidak sesuai dengan target informasi yang diminta atau tidak didukung oleh teks. Bukti yang menjawab pertanyaan adalah: “These features help people with different needs use the same public space.”.

**Kunci:** B. important parts or characteristics
**Penjelasan guru:** Jawaban B benar karena “important parts or characteristics” sesuai dengan informasi yang diminta. Bukti dalam stimulus: “These features help people with different needs use the same public space.”. Kutipan tersebut mendukung pilihan ini tanpa mengubah pelaku, waktu, tempat, jumlah, negasi, atau hubungan makna yang ditanyakan.
**Bukti teks:** “These features help people with different needs use the same public space.”
**Target kosakata:** feature, resource
**Supporting vocabulary:** —

# Catatan penilaian

- Distribusi kesulitan mengikuti target Modul v0.4; label belum dikalibrasi melalui pilot siswa.
- B1-inspired adalah estimasi desain, bukan sertifikasi CEFR.
- Jadwal, biaya, survei, dan peristiwa pada skenario yang diberi catatan adalah simulasi latihan.
