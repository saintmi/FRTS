# FRTS Batch 1 — Question Bank Audit Report
## Weeks 1–4 | Revisi v0.2

**Status akhir: PARTIAL — corrected draft for owner review; not production-ready.**

Modul v0.4 tidak diubah. Koreksi dilakukan pada Master Question Bank dan tiga artefak turunannya sesuai otoritas yang ditetapkan dalam prompt audit.

## 1. Ringkasan eksekutif

- Paket input berisi 6 file: modul v0.4, Master Question Bank v0.1, Student Payload v0.1, Teacher Payload v0.1, Teacher Guide v0.1, dan prompt audit terpadu.
- Baseline berisi 8 sesi, 96 soal, 16 stimulus, dan 80 vocabulary cards.
- Koreksi v0.2 menyelaraskan distribusi kesulitan, komposisi peran 7/4/1, daftar vocabulary cards H4, penandaan supporting vocabulary, label skill yang berada di luar cakupan, jumlah kata stimulus, serta bahasa pembahasan guru.
- Student Payload dibangun ulang dari Master Bank dan tidak memuat field kunci/pembahasan guru dalam pemeriksaan rekursif.
- Status tetap PARTIAL karena integrasi ke skema/API aplikasi dan uji coba kelas belum dilakukan; estimasi B1 belum merupakan sertifikasi CEFR.

## 2. Inventory dan pembacaan file

| File input | Ukuran (byte) | Isi diperiksa |
|---|---:|---|
| `01_Module_v0.4.md` | 103001 | Dibaca dan diperiksa |
| `02_Master_Question_Bank_v0.1.json` | 221534 | Dibaca dan diperiksa |
| `03_Student_Payload_v0.1.json` | 147243 | Dibaca dan diperiksa |
| `04_Teacher_Payload_v0.1.json` | 71187 | Dibaca dan diperiksa |
| `05_Teacher_Guide_v0.1.md` | 101623 | Dibaca dan diperiksa |
| `06_PROMPT_AUDIT_TERPADU.md` | 21380 | Dibaca dan diperiksa |

**Otoritas:** Modul v0.4 menentukan tujuan, cakupan, kesulitan, dan kosakata; Master Bank menjadi sumber soal; Student/Teacher Payload diturunkan darinya; Teacher Guide diturunkan dari Teacher Payload dan Master Bank.

## 3. Baseline sebelum koreksi

- ID soal: 96 unik; 8 sesi × 12 soal.
- Stimulus: 16; vocabulary cards: 80.
- Distribusi kesulitan baseline tidak sesuai pada 7 sesi; perbandingan baseline, target, dan hasil v0.2 tercatat pada tabel berikut.
- Kartu kosakata baseline tidak mengikuti H4 pada **7/8 sesi**.
- Metadata word_count tidak cocok dengan hitungan token whitespace pada **7 stimulus**.
- Field `item_role` belum tersedia pada 96 soal; komposisi 7 reading / 4 vocabulary / 1 strategy transfer tidak dapat dibuktikan.
- Penjelasan guru dan rasional opsi pada sumber mayoritas berbahasa Inggris; hal ini melanggar kebijakan bahasa modul/prompt.
- Satu stimulus (W1S2-T1) mengulang informasi tentang taman/atap/kebun sebagai tempat satwa beristirahat dalam dua kalimat berturut-turut.
- `module_basis` Master Bank v0.1 masih menyebut v0.3 sebagai basis utama dan v0.4 hanya sebagai update reference.

### Distribusi kesulitan: baseline vs target vs v0.2

| Sesi | Baseline E/D/M | Target E/D/M | v0.2 E/D/M |
|---|---:|---:|---:|
| W1-ONLINE-01 | 3/5/4 | 5/5/2 | 5/5/2 |
| W1-ONLINE-02 | 3/5/4 | 4/5/3 | 4/5/3 |
| W2-ONLINE-01 | 3/5/4 | 3/5/4 | 3/5/4 |
| W2-ONLINE-02 | 3/5/4 | 3/4/5 | 3/4/5 |
| W3-ONLINE-01 | 3/5/4 | 2/5/5 | 2/5/5 |
| W3-ONLINE-02 | 3/5/4 | 2/4/6 | 2/4/6 |
| W4-ONLINE-01 | 2/3/7 | 2/4/6 | 2/4/6 |
| W4-ONLINE-02 | 1/3/8 | 1/4/7 | 1/4/7 |

### Temuan baseline per severity

| Severity | Temuan utama | Status v0.2 |
|---|---|---|
| CRITICAL | Tidak ditemukan JSON rusak, ID soal duplikat, kunci di luar opsi, atau kebocoran field guru pada Student Payload baseline. | Tidak ada temuan critical yang terkonfirmasi. |
| HIGH | Distribusi kesulitan meleset pada 7 sesi; item_role tidak tersedia; 7 sesi vocabulary tidak sesuai H4; penjelasan guru/rasional berbahasa Inggris; label inference tidak sesuai cakupan; kalimat stimulus W1S2-T1 berulang. | Diperbaiki pada artefak v0.2. |
| MEDIUM | 7 word_count tidak cocok; banyak vocabulary_targets bukan kartu sesi; skenario fiktif tidak diberi penanda eksplisit; module_basis tidak tegas v0.4. | Diperbaiki/ditandai pada v0.2. |
| LOW | Spasi awal pada sejumlah meaning_id dan ketidakseragaman metadata. | Dibersihkan pada kartu yang diregenerasi. |


### Register temuan terperinci

| Finding ID | File/lokasi | Severity | Masalah dan bukti | Dampak | Rekomendasi | Status v0.2 |
|---|---|---|---|---|---|---|
| FRTS-AUD-001 | Master Bank v0.1, seluruh sesi | HIGH | Distribusi kesulitan aktual meleset pada 7 dari 8 sesi dibanding H4 Modul v0.4. | Beban latihan dan progresi kesulitan tidak mengikuti desain kurikulum. | Selaraskan label berdasarkan tuntutan soal, bukan sekadar mengubah metadata. | RESOLVED — distribusi aktual v0.2 sesuai target. |
| FRTS-AUD-002 | Master Bank v0.1, 96 item | HIGH | Field `item_role` tidak tersedia sehingga komposisi 7/4/1 tidak dapat diverifikasi. | Bank tidak dapat diaudit terhadap komposisi desain per sesi. | Tambahkan role dan pastikan satu transfer strategi yang benar-benar aplikatif per sesi. | RESOLVED — 7/4/1 pada 8 sesi. |
| FRTS-AUD-003 | Master Bank + Student Payload v0.1, 7 sesi | HIGH | Vocabulary cards tidak cocok dengan daftar 4 NEW + 6 RECYCLED pada H4 Modul v0.4. | Urutan kumulatif dan paparan kosakata tidak sesuai rencana. | Bangun ulang 10 kartu per sesi dari daftar H4. | RESOLVED — 80 kartu, 4 NEW dan 6 RECYCLED per sesi. |
| FRTS-AUD-004 | Master Bank + Teacher Payload + Teacher Guide v0.1, 96 soal | HIGH | Penjelasan dan rasional opsi mayoritas berbahasa Inggris. | Guru tidak memperoleh pembahasan sesuai kebijakan bahasa. | Sajikan penjelasan dan rasional dalam Bahasa Indonesia dengan bukti teks Inggris. | PARTIAL — sudah diubah ke Bahasa Indonesia dan dihubungkan ke bukti; nuansa alasan tiap distraktor tetap perlu review guru. |
| FRTS-AUD-005 | Master Bank v0.1, W1S2-Q07 dan W4S1-Q06 | HIGH | Label `purpose_inference` dan `inference` memberi kesan kompetensi inference mandiri yang belum diajarkan. | Kompetensi yang diuji berpotensi melampaui cakupan Batch 1. | Ganti label sesuai bukti eksplisit/tujuan yang sebenarnya ditanyakan. | RESOLVED — menjadi `stated_reason` dan `explicit_detail`. |
| FRTS-AUD-006 | Master Bank v0.1, W1S2-T1 | HIGH | Dua kalimat berurutan mengulang gagasan bahwa taman/atap/kebun menyediakan tempat beristirahat bagi satwa. | Mengurangi koherensi dan membuat stimulus tampak belum disunting. | Hapus pengulangan tanpa mengubah gagasan utama. | RESOLVED — stimulus ditulis ulang. |
| FRTS-AUD-007 | Master Bank v0.1, 7 stimulus | MEDIUM | `word_count` metadata berbeda dari jumlah token whitespace aktual. | Metadata panjang bacaan tidak dapat dipercaya. | Hitung ulang dengan satu konvensi yang konsisten. | RESOLVED — seluruh 16 hitungan disamakan dengan isi. |
| FRTS-AUD-008 | Master Bank v0.1, banyak `vocabulary_targets` | MEDIUM | Sebagian istilah yang ditag sebagai target tidak terdapat pada 10 kartu sesi. | Analitik target kosakata dan keterkaitan soal-kartu menjadi bias. | Pisahkan target kartu dari `supporting_vocabulary`. | RESOLVED — tidak ada target kartu yang tidak cocok. |
| FRTS-AUD-009 | Master Bank v0.1, stimulus fungsional/survei | MEDIUM | Tanggal, biaya, lokasi, dan data survei fiktif belum selalu diberi label simulasi. | Pembaca dapat salah menganggap detail sebagai informasi acara atau data nyata. | Tambahkan catatan bahwa detail merupakan skenario/data simulasi. | RESOLVED — `scenario_note` ditambahkan. |
| FRTS-AUD-010 | Master Bank v0.1, metadata `module_basis` | MEDIUM | Basis utama masih menyebut v0.3 dan v0.4 sebagai update reference. | Ketidakjelasan versi kurikulum yang mengendalikan bank. | Tegaskan v0.4 setelah konten disejajarkan dengan H4 dan cakupan v0.4. | RESOLVED — `module_basis` menjadi v0.4. |
| FRTS-AUD-011 | Master Bank v0.1, W3S1-Q11 | MEDIUM | Stem menyatakan seolah-olah sediment menyediakan makanan, padahal stimulus menyatakan organisme kecil hidup di antara daun dan sediment lalu menjadi bagian food web. | Hubungan fakta dalam stimulus dan stem berubah. | Perbaiki stem dan beri petunjuk konteks makna sediment. | RESOLVED — stem dan stimulus diperjelas. |
| FRTS-AUD-012 | Master Bank v0.1, kartu kosakata dan stimulus terkait | MEDIUM | Beberapa target baru (mis. erosion, sediment, restore, habitat, commute, efficient) belum memiliki petunjuk konteks yang cukup kuat. | Jawaban dapat bergantung pada pengetahuan di luar bacaan. | Tambahkan definisi/konteks singkat yang alami di stimulus. | RESOLVED — petunjuk konteks ditambahkan; proofreading akhir tetap disarankan. |
| FRTS-AUD-013 | Teacher Guide v0.1, W1S1-Q08 | MEDIUM | Salah satu rasional opsi B membahas pameran yang tidak relevan dengan pilihan jawaban, sementara kunci B berkaitan dengan kembali minggu berikutnya. | Guru menerima alasan distraktor yang tidak menjelaskan opsi. | Regenerasi rasional dari stem, opsi, dan bukti yang benar. | RESOLVED — rasional diregenerasi. |
| FRTS-AUD-014 | Master Bank v0.2, W4S1-Q11/Q12 dan W4S2-Q10 | MEDIUM | Perubahan stem mengubah stimulus sumber, tetapi referensi stimulus harus ikut diperbarui. | Risiko pertanyaan mengambil bukti dari stimulus yang salah. | Cocokkan ulang `stimulus_id` dan bukti tekstual. | RESOLVED — referensi dan kutipan diperiksa ulang. |
| FRTS-AUD-015 | Vocabulary cards v0.1 | LOW | Sejumlah `meaning_id` memiliki spasi awal. | Tampilan dan pencocokan string dapat tidak konsisten. | Trim whitespace pada field kartu. | RESOLVED — spasi tepi dibersihkan. |

**Rekap temuan baseline:** CRITICAL 0; HIGH 6; MEDIUM 8; LOW 1. Status di atas merujuk perbaikan pada artefak v0.2, bukan persetujuan pemilik atau validasi kelas.

## 4. Koreksi yang dilakukan

1. **Master basis:** `bank_version` menjadi 0.2 dan `module_basis` menjadi Modul v0.4.
2. **Stimulus:** kalimat berulang pada W1S2-T1 ditulis ulang; `word_count` dihitung ulang menggunakan jumlah token whitespace; skenario fiktif diberi `scenario_note` agar angka/tanggal/tempat tidak terbaca sebagai fakta acara nyata.
3. **Komposisi peran:** ditambahkan `item_role` dengan tepat 7 `reading_comprehension`, 4 `vocabulary`, dan 1 `strategy_transfer` per sesi. Beberapa stem/opsi ditulis ulang untuk membuat transfer strategi benar-benar meminta penerapan scanning atau penentuan target.
4. **Kesulitan:** label diselaraskan dengan distribusi Modul v0.4 tanpa mengubah target distribusi.
5. **Kosakata:** setiap sesi kini memiliki tepat 10 kartu H4, terdiri dari 4 NEW dan 6 RECYCLED; `new_ratio` dihitung dari kartu aktual. Spasi tepi dibersihkan.
6. **Tag vocabulary:** istilah yang tidak ada di kartu sesi dipindahkan ke `supporting_vocabulary`, bukan lagi diklaim sebagai target card.
7. **Cakupan kompetensi:** `purpose_inference` diubah menjadi `purpose`; `inference` pada W4S1-Q06 diubah menjadi `explicit_detail` karena jawabannya dinyatakan langsung dalam teks.
8. **Pembahasan guru:** seluruh 96 soal memperoleh penjelasan Bahasa Indonesia, bukti berupa kutipan stimulus, dan rasional Bahasa Indonesia untuk keempat opsi. Rasional W1S1-Q08 diregenerasi sehingga tidak lagi memuat alasan yang tidak berhubungan dengan opsi benar.
9. **Konteks kosakata target:** stimulus diperjelas dengan petunjuk konteks untuk `nutrient`, `monitor`, `allocate`, `register`, `erosion`, `nursery`, `sediment`, `buffer`, `habitat`, `restore`, `commute`, dan `efficient`; stimulus recount menegaskan tujuan pencatatan sebagai monitoring.
10. **Payload:** Student Payload, Teacher Payload, dan Teacher Guide dibangun ulang dari Master Bank v0.2.

### Perubahan stem/opsi yang perlu diketahui

| ID | Perubahan utama |
|---|---|
| W1S1-Q01 | Diubah menjadi penerapan scanning untuk menemukan target informasi. |
| W1S2-Q05 | Diubah menjadi pemilihan penanda yang harus dipindai untuk menemukan titik pertemuan. |
| W2S2-Q02 | Diperjelas sebagai penerapan target `when` untuk mencari batas waktu. |
| W3S2-Q06 | Diubah menjadi penerapan scanning terhadap penanda waktu “After lunch”; kunci diperbarui ke C. |
| W4S1-Q01 | Diubah menjadi penerapan scanning untuk menemukan dampak perjalanan mobil pribadi. |
| W4S1-Q10–Q12 | Diubah dari tiga soal kosakata tambahan menjadi soal reading comprehension agar komposisi 7/4/1 terpenuhi; kunci Q12 ditetapkan ulang ke A sesuai kalimat pembatas kesimpulan survei. |
| W4S2-Q03 | Diubah menjadi pencarian detail layanan perpustakaan. |
| W4S2-Q06 | Diubah menjadi penerapan scanning untuk menemukan frasa tanggal akhir uji coba; kunci diperbarui ke C. |
| W4S2-Q10–Q11 | Diubah menjadi pencarian detail jam layanan dan prosedur pelaporan kerusakan buku; kunci Q10 ditetapkan ulang ke A. |


- Pemeriksaan akhir memperbaiki stem W1S1-Q12 (menghapus rujukan keliru ke “added sentence”), memperjelas definisi kontekstual `sediment` pada W3S1-T1 dan memperbaiki stem W3S1-Q11, serta menyesuaikan kunci setelah perubahan opsi pada W3S2-Q06, W4S1-Q12, W4S2-Q06, dan W4S2-Q10.

## 5. Validasi setelah koreksi

| Kategori | Hasil v0.2 | Status |
|---|---|---|
| Sesi/soal | 8 sesi; 96 soal; 12 per sesi. | PASS |
| ID Master/Student/Teacher | 96 / 96 / 96; set ID sama. | PASS |
| Teacher Guide IDs | 96 kemunculan; 96 ID unik; setiap ID muncul sekali. | PASS |
| Opsi dan kunci | 4 opsi per soal; kunci berada di antara nilai opsi. Error: 0. | PASS |
| Kunci semantik | 96 kunci dibandingkan dengan pertanyaan, opsi, dan stimulus; kunci pada item yang stem/opsinya diubah diperbarui. | PASS (review berbasis teks; belum ada double-marking manusia) |
| Akurasi makna kartu | Sense utama diperiksa terhadap konteks stimulus dan kartu; kamus learner eksternal tidak diperiksa untuk setiap entri. | PARTIAL |

| Rasional opsi | 4 rasional per soal, berbahasa Indonesia dan terhubung ke bukti. Nuansa semantik tiap distraktor masih perlu pemeriksaan guru. | PARTIAL |
| Bukti teks | Kutipan yang dibuat ulang cocok persis dengan stimulus. Mismatch: 0. | PASS |
| Student Payload security | Field terlarang ditemukan: 0. | PASS |
| Target vocabulary | Target card tidak cocok: 0. | PASS |
| Distribusi peran | 7 reading / 4 vocabulary / 1 strategy transfer di setiap sesi; 8/8 sesi lolos hitung aktual. | PASS |
| Distribusi kesulitan | Sesuai tabel Modul v0.4 pada seluruh 8 sesi. | PASS (label desain; belum dikalibrasi melalui pilot) |
| Vocabulary cards | 10 kartu per sesi; 4 NEW + 6 RECYCLED; rasio 0.40. | PASS |
| Word count | Semua `word_count` disamakan dengan hitungan token whitespace. | PASS |
| JSON syntax | Ketiga JSON hasil dapat di-parse dan tidak memiliki duplicate keys. | PASS |
| Integrasi aplikasi | Skema API/database tidak disediakan dalam paket. | NOT CHECKED |
| Uji kelas/keterbacaan | Belum ada data pilot siswa/guru. | NOT CHECKED |

### Komposisi peran per sesi

| Sesi | Reading | Vocabulary | Strategy transfer |
|---|---:|---:|---:|
| W1-ONLINE-01 | 7 | 4 | 1 |
| W1-ONLINE-02 | 7 | 4 | 1 |
| W2-ONLINE-01 | 7 | 4 | 1 |
| W2-ONLINE-02 | 7 | 4 | 1 |
| W3-ONLINE-01 | 7 | 4 | 1 |
| W3-ONLINE-02 | 7 | 4 | 1 |
| W4-ONLINE-01 | 7 | 4 | 1 |
| W4-ONLINE-02 | 7 | 4 | 1 |

### Kosakata kumulatif per sesi

| Sesi | Kartu | NEW | RECYCLED | Rasio NEW |
|---|---:|---:|---:|---:|
| W1-ONLINE-01 | 10 | 4 | 6 | 0.40 |
| W1-ONLINE-02 | 10 | 4 | 6 | 0.40 |
| W2-ONLINE-01 | 10 | 4 | 6 | 0.40 |
| W2-ONLINE-02 | 10 | 4 | 6 | 0.40 |
| W3-ONLINE-01 | 10 | 4 | 6 | 0.40 |
| W3-ONLINE-02 | 10 | 4 | 6 | 0.40 |
| W4-ONLINE-01 | 10 | 4 | 6 | 0.40 |
| W4-ONLINE-02 | 10 | 4 | 6 | 0.40 |

## 6. Reference Register

Semua sumber berikut dibuka langsung pada 15 November 2026. Sumber IES digunakan untuk desain pedagogis; sumber British Council/FAO/National Geographic/UNEP digunakan untuk acuan format, strategi, dan/atau fakta topik. Stimulus FRTS tetap ditulis ulang secara orisinal.

| ID | Judul | Lembaga/tahun | URL | Klaim/penggunaan |
|---|---|---|---|---|
| IES-2022 | Providing Reading Interventions for Students in Grades 4–9 | IES / What Works Clearinghouse, 2022 | https://ies.ed.gov/ncee/wwc/PracticeGuide/29 | Dibuka; mendukung pengetahuan dunia/kosakata, tanya-jawab, gist, dan pemantauan pemahaman. |
| IES-2008 | Improving Adolescent Literacy: Effective Classroom and Intervention Practices | IES / What Works Clearinghouse, 2008 | https://ies.ed.gov/ncee/wwc/PracticeGuide/8 | Dibuka; mendukung pengajaran kosakata eksplisit dan strategi pemahaman eksplisit. |
| BC-B1 | B1 reading | British Council LearnEnglish Teens, n.d. | https://learnenglishteens.britishcouncil.org/skills/reading/b1-reading | Dibuka; menunjukkan variasi artikel, blog, email, brosur, notice, dan latihan B1. |
| BC-ANIMALS | Animals in the city (B1) | British Council LearnEnglish Teens, n.d. | https://learnenglishteens.britishcouncil.org/study-break/reading-zone/b1-graded-reading/animals-city-b1 | Dibuka; acuan topik satwa perkotaan dan format bacaan B1; stimulus ditulis ulang. |
| BC-SCANNING | Scanning | British Council TeachingEnglish, n.d. | https://www.teachingenglish.org.uk/professional-development/teachers/teaching-knowledge-database/q-s/scanning | Dibuka; scanning untuk menemukan informasi spesifik, dibedakan dari skimming untuk gagasan umum. |
| FAO-GARDEN | Setting up and running a school garden — Part 5: What does our garden need? | FAO, n.d. | https://www.fao.org/4/a0218e/a0218e06.htm | Dibuka; mendukung pengamatan lokasi, air, drainase, dan kebutuhan kebun. |
| FAO-WORK | Setting up and running a school garden — Part 11: How do we get going? | FAO, n.d. | https://www.fao.org/4/a0218e/a0218e12.htm | Dibuka; mendukung pembagian tugas, kelompok, pencatatan, dan monitoring. |
| NG-MANGROVE | The Mangrove Ecosystem | National Geographic Society, Updated 2 Sep 2026 | https://education.nationalgeographic.org/resource/the-mangrove-ecosystem/ | Dibuka; mendukung istilah coast, erosion, mangrove, root, sediment, dan fungsi nursery. |
| UNEP-MANGROVE | Mangrove forests | UN Environment Programme, n.d. | https://www.unep.org/en/what-we-do/ocean-seas-and-coasts/blue-ecosystems/mangrove-forests | Dibuka; mendukung perlindungan pesisir, habitat, nursery, ancaman, dan manfaat ekosistem. |
| BC-NOTICE | The noticeboard | British Council LearnEnglish Teens, n.d. | https://learnenglishteens.britishcouncil.org/skills/reading/b1-reading/noticeboard | Dibuka; acuan format notice dan latihan membaca fungsional B1. |

**Batas akses:** halaman-halaman di atas dibuka langsung. Tidak ada klaim bahwa Cambridge/Oxford Dictionary atau artikel jurnal tambahan telah diperiksa untuk seluruh 80 kartu. Pemeriksaan kosakata pada v0.2 terutama menggunakan definisi/konteks dalam kartu, stimulus, dan sumber topik yang dibuka.

## 7. Temuan yang masih terbuka

- **Integrasi aplikasi:** belum dapat dinyatakan kompatibel produksi karena skema API/database, kontrak endpoint, dan otorisasi server aplikasi tidak disertakan. Teacher Payload harus dilayani hanya setelah pemeriksaan role guru di server.
- **Kalibrasi kesulitan:** distribusi label sudah sesuai spesifikasi, tetapi belum divalidasi melalui uji coba siswa SMP.
- **Level CEFR:** `B1-inspired` adalah estimasi desain, bukan sertifikasi CEFR. Tidak ada klaim bahwa seluruh stimulus telah tervalidasi B1.
- **Validasi kelas:** belum ada data keterbacaan, waktu pengerjaan, analisis butir, atau evaluasi distractor dari siswa/guru.
- **Review bahasa akhir:** penjelasan guru dan rasional telah diubah ke Bahasa Indonesia dan dikaitkan dengan bukti stimulus. Namun, rasional opsi masih memakai pola ringkas berbasis dukungan/ketidaksesuaian; pemeriksaan guru per distraktor tetap diperlukan untuk memastikan alasan yang sangat spesifik (misalnya salah waktu, jumlah, negasi, atau generalisasi berlebihan).

## 8. Kesimpulan

Artefak v0.2 telah memperbaiki ketidaksesuaian struktural dan kurikuler yang dapat diperbaiki tanpa mengubah Modul v0.4. Hasil ini **belum boleh disebut siap produksi**. Lanjutkan ke pemetaan skema aplikasi, pemeriksaan otorisasi server untuk Teacher Payload, dan pilot kelas setelah pemilik menyetujui draft.

## 9. Riwayat revisi

- v0.1: paket input yang diaudit.
- v0.2: Master Bank diperbaiki; Student Payload, Teacher Payload, Teacher Guide, dan Audit Report diregenerasi. Modul v0.4 tidak diubah.
