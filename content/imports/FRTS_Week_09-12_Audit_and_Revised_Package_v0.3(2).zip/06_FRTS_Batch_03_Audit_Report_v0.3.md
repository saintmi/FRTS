# FRTS Batch 3 (Weeks 9–12) — Audit & Revision Report v0.3

**Tanggal audit:** 15 November 2026  
**Sumber paket:** `FRTS_Week_09-12_Production_Package_v0.2.zip`  
**Status:** **PARTIAL — REVISED DRAFT / OWNER REVIEW**  
**Classroom validated:** No  
**Psychometrically calibrated:** No  
**Production-ready:** No

## 1. Ringkasan eksekutif

Seluruh tujuh file sumber di dalam ZIP dibaca, termasuk prompt audit. Audit mencakup 132 soal, 22 stimulus, 80 vocabulary cards, struktur Master Bank, Student Payload, Teacher Answer Payload, Teacher Answer Guide, dan README. Riset online wajib dari prompt serta sumber tambahan untuk distractor dan cross-text reading juga diperiksa.

**Temuan terpenting pada baseline v0.2:**
- W11S2-Q07 memiliki kunci yang salah: kunci awal menunjuk tindakan memindahkan semua kegiatan ke aula, padahal teks mendukung tindakan berbagi dan memeriksa informasi ruangan yang akurat.
- W10S2-Q11 memiliki dua opsi yang dapat dianggap benar karena distractor “Except if a guide is present” pada dasarnya merupakan parafrasa langsung dari `unless` dalam kalimat negatif.
- Sejumlah item Integrated Reading tidak mencantumkan semua stimulus yang diperlukan untuk mendukung jawaban; beberapa kutipan dan dua referensi stimulus W12 salah taut.
- Tujuan belajar Week 10 memuat teks yang salah salin dari Week 12.
- 264 dari 528 option rationales menggunakan pola generik yang tidak membedakan alasan spesifik tiap distractor.
- Posisi kunci tidak seimbang: A=41, B=40, C=26, D=25.
- Empat word_count stimulus W12 tidak cocok dengan jumlah kata aktual.
- Teacher Answer Guide menyebut 96 soal dan versi 0.1, padahal bank sudah berisi 132 soal.

**Hasil revisi:** kunci W11S2-Q07 dibetulkan; distractor ambigu W10S2-Q11 diganti; lima item lintas stimulus kini memiliki `additional_stimulus_ids`; referensi/evidence diperbaiki; tujuan Week 10 dibetulkan; semua 22 word_count dihitung ulang; rationales 528 opsi ditulis ulang agar mengacu pada opsi, bukti, dan jawaban; posisi kunci diseimbangkan menjadi 33 untuk setiap huruf; payload dan Teacher Guide dibangun ulang dari Master Bank v0.3.

## 2. Inventaris dan urutan otoritas

| File sumber | Fungsi audit |
|---|---|
| `00_FRTS_Master_Development_Plan_v1.3.1.md` | Standar program dan target kuantitas; disalin tanpa perubahan ke paket hasil |
| `01_FRTS_Batch_03_Weeks_09-12_Module_v0.2.md` | Acuan materi, tujuan, dan batas kompetensi; direvisi menjadi v0.3 |
| `02_FRTS_Batch_03_Interactive_Question_Bank_v0.2.json` | Sumber data utama; direvisi menjadi v0.3 |
| `03_FRTS_Batch_03_Student_Payload_v0.2.json` | Dibangun ulang dari bagian siswa Master Bank |
| `04_FRTS_Batch_03_Teacher_Answer_Payload_v0.2.json` | Dibangun ulang dari teacher_only Master Bank |
| `05_FRTS_Batch_03_Teacher_Answer_Guide_v0.2.md` | Dibangun ulang untuk 132 soal |
| `06_FRTS_Batch_03_Audit_Prompt_v0.2.md` | Instruksi audit; digunakan sebagai mandat pemeriksaan |
| `README.md` | Status dan inventaris paket; diperbarui |

Master Development Plan v1.3.1 dipertahankan apa adanya. Tidak ada ID soal yang dihapus, diganti, atau dinomori ulang.

## 3. Ringkasan severity

| Severity | Jumlah | Status |
|---|---:|---|
| CRITICAL | 0 | — |
| HIGH | 6 | 4 resolved; 2 open readiness gates |
| MEDIUM | 10 | 7 resolved; 3 open scope/verification items |
| LOW | 0 | — |

## 4. Findings register

| ID | Severity | Temuan baseline | Tindakan / status |
|---|---|---|---|
| FRTS-AUD-001 | HIGH | W11S2-Q07 kunci salah; opsi A tidak didukung, sedangkan opsi tentang berbagi dan memeriksa informasi akurat didukung teks | **RESOLVED** — kunci, pembahasan, bukti, dan rasional opsi diperbaiki |
| FRTS-AUD-002 | HIGH | W10S2-Q11 berpotensi memiliki dua jawaban karena “Except if a guide is present” setara dengan struktur `unless` dalam konteks tersebut | **RESOLVED** — distractor diganti; satu jawaban terbaik dipertahankan |
| FRTS-AUD-003 | HIGH | Item Integrated Reading tidak selalu menyatakan semua stimulus yang menjadi dasar jawaban; lima item memerlukan hubungan stimulus tambahan | **RESOLVED** — `additional_stimulus_ids` ditambahkan pada W11S1-Q04, W11S1-Q12, W11S2-Q03, W11S2-Q12, W12S1-Q06 |
| FRTS-AUD-004 | HIGH | W12S2-Q26 dan Q29 merujuk stimulus yang salah; beberapa bukti lain tidak cocok dengan stimulus tertaut | **RESOLVED** — referensi dan kutipan diperbaiki; 0 kutipan gagal pada pemeriksaan pascarevisi |
| FRTS-AUD-005 | HIGH | Tujuan belajar Week 10 diawali salinan tujuan Week 12 | **RESOLVED** — tujuan Week 10 ditulis ulang sesuai micro-grammar for reading |
| FRTS-AUD-006 | HIGH | Teacher-only payload belum diuji dalam endpoint aplikasi dan role-based authorization | **OPEN** — harus diuji pada backend; payload file saja bukan kontrol akses |
| FRTS-AUD-007 | HIGH | Tidak ada pilot siswa atau analisis item empiris untuk validasi tingkat kesulitan dan fungsi distractor | **OPEN** — perlu pilot kelas 7–9 dan analisis item |
| FRTS-AUD-008 | MEDIUM | 264/528 rationale baseline terlalu generik dan tidak menjelaskan alasan spesifik distractor | **RESOLVED** — 528 rationale dibangun ulang dengan alasan yang merujuk opsi, bukti, dan jawaban |
| FRTS-AUD-009 | MEDIUM | Distribusi kunci baseline A=41, B=40, C=26, D=25 dapat menjadi petunjuk posisi | **RESOLVED** — 33 A, 33 B, 33 C, 33 D |
| FRTS-AUD-010 | MEDIUM | Word_count W12S1-T2, W12S1-T4, W12S2-T2, W12S2-T5 tidak akurat | **RESOLVED** — seluruh 22 word_count dihitung ulang dengan tokenisasi whitespace |
| FRTS-AUD-011 | MEDIUM | W11S1-T1 mengulang kalimat; beberapa frasa W11 terasa meta/kurang alami | **RESOLVED** — pengulangan dihapus dan redaksi stimulus disunting |
| FRTS-AUD-012 | MEDIUM | Lima `vocabulary_targets` item tidak sesuai dengan kartu target pada sesi terkait | **RESOLVED** — tag yang tidak relevan dihapus |
| FRTS-AUD-013 | MEDIUM | Teacher Guide menyebut 96 soal/v0.1 dan `design_rules` Master Bank menyebut 96 soal | **RESOLVED** — Guide dan metadata dibangun ulang untuk 132 soal/v0.3 |
| FRTS-AUD-014 | MEDIUM | Label RECYCLED untuk seluruh 48 kartu tidak dapat diverifikasi secara historis tanpa Master Bank Batch 2 | **OPEN** — ZIP ini tidak menyertakan file bank Batch 2; kontinuitas internal W9–W12 diperiksa, tetapi asal historis 48 kata tetap perlu dicocokkan dengan Batch 2 |
| FRTS-AUD-015 | MEDIUM | W9–W11 hanya 12 soal/sesi dalam paket ini, sedangkan Master Plan menetapkan 25 soal/sesi untuk W1–W11 | **OPEN SCOPE GAP** — jumlah 12 dipertahankan sesuai prompt paket; jangan mengklaim target produksi penuh W9–W11 terpenuhi |
| FRTS-AUD-016 | MEDIUM | Master Plan meminta lima soal penguatan untuk setiap major explanation/lesson section; modul saat ini menyediakan pemeriksaan mandiri lima soal per minggu | **OPEN SCOPE GAP** — perlu perluasan pada siklus revisi modul berikutnya; soal penguatan tidak boleh dihitung sebagai online bank |

## 5. Audit modul dan batas kompetensi

- **W9 — Distractor Analysis:** item dan pembahasan diarahkan pada keyword match, wrong target, partial truth, contradiction, irrelevant detail, dan unsupported claim. Rationale membedakan informasi yang memang muncul tetapi tidak menjawab pertanyaan dari informasi yang tidak didukung teks.
- **W10 — Micro-Grammar for Reading:** connector, cause/effect, contrast, sequence, condition, negation, permission, obligation, prohibition, no obligation, dan possibility dipertahankan sebagai petunjuk makna bacaan. W10S2-Q11 dikoreksi agar `unless` tidak memiliki dua parafrasa yang sama-sama sah. W10S2-Q12 kini menggunakan kalimat `therefore` yang benar-benar terdapat pada stimulus.
- **W11 — Integrated Reading:** item yang menghubungkan artikel, jadwal, atau dua pesan sekarang mencatat stimulus tambahan. Bukti harus diperiksa pada seluruh stimulus yang ditautkan, bukan hanya teks pertama.
- **W12 — Mixed Reading Practice & Pacing:** tetap fase latihan campuran dan refleksi; tidak diperluas menjadi simulasi ujian penuh atau bab strategi baru.
- Label Easy/Developing/Medium tetap estimasi internal, bukan ekuivalensi CEFR. Tidak ada klaim bahwa FRTS adalah program resmi TKA Bahasa Inggris SMP.

## 6. Audit 22 stimulus

| Stimulus | Genre | Estimasi level | Word count revisi | Item terkait |
|---|---|---|---:|---:|
| W9S1-T1 | Notice / functional text | Easy–Developing | 71 | 5 |
| W9S1-T2 | Informational article | Developing–Medium | 129 | 7 |
| W9S2-T1 | Announcement | Easy–Developing | 61 | 4 |
| W9S2-T2 | Informational article | Developing–Medium | 128 | 8 |
| W10S1-T1 | School notice / informational | Easy–Developing | 76 | 8 |
| W10S1-T2 | Informational report | Developing–Medium | 103 | 4 |
| W10S2-T1 | Notice / functional text | Easy–Developing | 79 | 7 |
| W10S2-T2 | Short report | Developing–Medium | 96 | 5 |
| W11S1-T1 | Informational article | Developing–Medium | 123 | 5 |
| W11S1-T2 | Programme / functional text | Easy–Developing | 128 | 9 |
| W11S2-T1 | Paired messages | Developing–Medium | 90 | 6 |
| W11S2-T2 | Informational report | Medium | 101 | 8 |
| W12S1-T1 | Informational article | Developing–Medium | 107 | 5 |
| W12S1-T2 | Schedule / notice | Easy–Developing | 107 | 8 |
| W12S1-T3 | Informational report | Developing–Medium | 109 | 5 |
| W12S1-T4 | Announcement / schedule | Easy–Developing | 91 | 5 |
| W12S1-T5 | Paired informational notes | Medium | 127 | 8 |
| W12S2-T1 | Review / informational text | Developing–Medium | 110 | 4 |
| W12S2-T2 | Instructional notice | Easy–Developing | 81 | 8 |
| W12S2-T3 | Informational report / comparison | Developing–Medium | 116 | 4 |
| W12S2-T4 | Recount with reflective comment | Medium | 113 | 5 |
| W12S2-T5 | Instructional notice with short results table | Medium | 128 | 9 |

### Koreksi stimulus utama

- W9S1-T2 ditambahkan kalimat eksplisit yang mendukung penggunaan kata *eliminate* pada item W9S1-Q11; bukti tidak lagi meminjam kalimat dari sesi lain.
- W11S1-T1: kalimat tentang rute yang berulang dihapus; kalimat pengganti mempertahankan koherensi informasi.
- W11S1-T2 dan W11S2-T2: beberapa redaksi meta diperhalus tanpa menghapus kosakata target yang memang sedang diajarkan.
- W12S1-T2: konteks *allocate* dan *monitor* diperjelas agar dua item kosakata merujuk pada frasa yang benar-benar ada.
- Word count dihitung ulang untuk semua 22 stimulus. Semua 22 cocok dengan `len(text.split())`.

Semua bacaan tetap merupakan stimulus orisinal FRTS. Referensi eksternal digunakan sebagai konteks tema/desain, bukan sebagai klaim bahwa teks merupakan salinan resmi Cambridge atau British Council.

## 7. Audit 132 soal dan item-level register

Semua ID baseline dipertahankan. Kunci setiap item diperiksa terhadap opsi dan stimulus; lima item lintas stimulus mencantumkan stimulus tambahan secara eksplisit. Tabel berikut merekam ID, role, tingkat kesulitan, tautan stimulus, dan kunci final.

| Question ID | Role | Difficulty | Stimulus evidence set | Key |
|---|---|---|---|---|
| W9S1-Q01 | reading_comprehension | easy | W9S1-T1 | B |
| W9S1-Q02 | reading_comprehension | easy | W9S1-T1 | D |
| W9S1-Q03 | reading_comprehension | developing | W9S1-T1 | D |
| W9S1-Q04 | reading_comprehension | developing | W9S1-T2 | C |
| W9S1-Q05 | reading_comprehension | developing | W9S1-T2 | A |
| W9S1-Q06 | reading_comprehension | medium | W9S1-T1 | B |
| W9S1-Q07 | reading_comprehension | medium | W9S1-T2 | B |
| W9S1-Q08 | vocabulary | easy | W9S1-T2 | C |
| W9S1-Q09 | vocabulary | easy | W9S1-T2 | A |
| W9S1-Q10 | vocabulary | developing | W9S1-T2 | C |
| W9S1-Q11 | vocabulary | developing | W9S1-T2 | A |
| W9S1-Q12 | strategy_transfer | medium | W9S1-T1 | D |
| W9S2-Q01 | reading_comprehension | easy | W9S2-T1 | D |
| W9S2-Q02 | reading_comprehension | easy | W9S2-T1 | A |
| W9S2-Q03 | reading_comprehension | developing | W9S2-T1 | A |
| W9S2-Q04 | reading_comprehension | developing | W9S2-T2 | D |
| W9S2-Q05 | reading_comprehension | developing | W9S2-T2 | A |
| W9S2-Q06 | reading_comprehension | medium | W9S2-T1 | B |
| W9S2-Q07 | reading_comprehension | medium | W9S2-T2 | C |
| W9S2-Q08 | vocabulary | easy | W9S2-T2 | C |
| W9S2-Q09 | vocabulary | developing | W9S2-T2 | B |
| W9S2-Q10 | vocabulary | developing | W9S2-T2 | D |
| W9S2-Q11 | vocabulary | medium | W9S2-T2 | C |
| W9S2-Q12 | strategy_transfer | medium | W9S2-T2 | B |
| W10S1-Q01 | reading_comprehension | easy | W10S1-T1 | D |
| W10S1-Q02 | reading_comprehension | developing | W10S1-T1 | B |
| W10S1-Q03 | reading_comprehension | developing | W10S1-T1 | B |
| W10S1-Q04 | reading_comprehension | medium | W10S1-T1 | C |
| W10S1-Q05 | reading_comprehension | medium | W10S1-T2 | C |
| W10S1-Q06 | reading_comprehension | medium | W10S1-T2 | A |
| W10S1-Q07 | reading_comprehension | medium | W10S1-T1 | C |
| W10S1-Q08 | vocabulary | easy | W10S1-T1 | D |
| W10S1-Q09 | vocabulary | easy | W10S1-T1 | D |
| W10S1-Q10 | vocabulary | developing | W10S1-T1 | A |
| W10S1-Q11 | vocabulary | developing | W10S1-T2 | A |
| W10S1-Q12 | strategy_transfer | medium | W10S1-T2 | B |
| W10S2-Q01 | reading_comprehension | easy | W10S2-T1 | A |
| W10S2-Q02 | reading_comprehension | developing | W10S2-T1 | D |
| W10S2-Q03 | reading_comprehension | developing | W10S2-T1 | C |
| W10S2-Q04 | reading_comprehension | developing | W10S2-T2 | D |
| W10S2-Q05 | reading_comprehension | medium | W10S2-T2 | A |
| W10S2-Q06 | reading_comprehension | medium | W10S2-T2 | B |
| W10S2-Q07 | reading_comprehension | medium | W10S2-T1 | A |
| W10S2-Q08 | vocabulary | easy | W10S2-T2 | B |
| W10S2-Q09 | vocabulary | easy | W10S2-T2 | C |
| W10S2-Q10 | vocabulary | developing | W10S2-T1 | D |
| W10S2-Q11 | vocabulary | medium | W10S2-T1 | C |
| W10S2-Q12 | strategy_transfer | medium | W10S2-T1 | B |
| W11S1-Q01 | reading_comprehension | easy | W11S1-T1 | A |
| W11S1-Q02 | reading_comprehension | easy | W11S1-T2 | C |
| W11S1-Q03 | reading_comprehension | developing | W11S1-T2 | B |
| W11S1-Q04 | reading_comprehension | developing | W11S1-T1, W11S1-T2 | D |
| W11S1-Q05 | reading_comprehension | medium | W11S1-T1 | D |
| W11S1-Q06 | reading_comprehension | medium | W11S1-T2 | A |
| W11S1-Q07 | reading_comprehension | medium | W11S1-T2 | A |
| W11S1-Q08 | vocabulary | developing | W11S1-T1 | C |
| W11S1-Q09 | vocabulary | developing | W11S1-T2 | B |
| W11S1-Q10 | vocabulary | developing | W11S1-T2 | D |
| W11S1-Q11 | vocabulary | medium | W11S1-T2 | C |
| W11S1-Q12 | strategy_transfer | medium | W11S1-T1, W11S1-T2 | B |
| W11S2-Q01 | reading_comprehension | easy | W11S2-T1 | A |
| W11S2-Q02 | reading_comprehension | developing | W11S2-T1 | D |
| W11S2-Q03 | reading_comprehension | developing | W11S2-T2, W11S2-T1 | B |
| W11S2-Q04 | reading_comprehension | developing | W11S2-T2 | C |
| W11S2-Q05 | reading_comprehension | medium | W11S2-T1 | C |
| W11S2-Q06 | reading_comprehension | medium | W11S2-T1 | D |
| W11S2-Q07 | reading_comprehension | medium | W11S2-T2 | B |
| W11S2-Q08 | vocabulary | easy | W11S2-T2 | A |
| W11S2-Q09 | vocabulary | developing | W11S2-T2 | D |
| W11S2-Q10 | vocabulary | medium | W11S2-T2 | B |
| W11S2-Q11 | vocabulary | medium | W11S2-T2 | C |
| W11S2-Q12 | strategy_transfer | medium | W11S2-T1, W11S2-T2 | A |
| W12S1-Q01 | reading_comprehension | easy | W12S1-T2 | D |
| W12S1-Q02 | reading_comprehension | developing | W12S1-T2 | C |
| W12S1-Q03 | reading_comprehension | developing | W12S1-T1 | D |
| W12S1-Q04 | reading_comprehension | medium | W12S1-T1 | C |
| W12S1-Q05 | reading_comprehension | medium | W12S1-T1 | A |
| W12S1-Q06 | reading_comprehension | medium | W12S1-T1, W12S1-T2 | A |
| W12S1-Q07 | reading_comprehension | medium | W12S1-T2 | B |
| W12S1-Q08 | vocabulary | easy | W12S1-T2 | B |
| W12S1-Q09 | vocabulary | developing | W12S1-T2 | D |
| W12S1-Q10 | vocabulary | medium | W12S1-T2 | C |
| W12S1-Q11 | vocabulary | developing | W12S1-T2 | B |
| W12S1-Q12 | strategy_transfer | medium | W12S1-T1 | D |
| W12S1-Q13 | reading_comprehension | medium | W12S1-T3 | C |
| W12S1-Q14 | reading_comprehension | developing | W12S1-T3 | A |
| W12S1-Q15 | reading_comprehension | medium | W12S1-T3 | A |
| W12S1-Q16 | vocabulary | easy | W12S1-T3 | B |
| W12S1-Q17 | reading_comprehension | easy | W12S1-T4 | D |
| W12S1-Q18 | reading_comprehension | developing | W12S1-T4 | D |
| W12S1-Q19 | reading_comprehension | medium | W12S1-T4 | C |
| W12S1-Q20 | strategy_transfer | developing | W12S1-T4 | A |
| W12S1-Q21 | reading_comprehension | medium | W12S1-T5 | B |
| W12S1-Q22 | reading_comprehension | medium | W12S1-T5 | B |
| W12S1-Q23 | vocabulary | developing | W12S1-T5 | C |
| W12S1-Q24 | vocabulary | easy | W12S1-T4 | C |
| W12S1-Q25 | vocabulary | developing | W12S1-T5 | B |
| W12S1-Q26 | vocabulary | medium | W12S1-T5 | A |
| W12S1-Q27 | reading_comprehension | medium | W12S1-T3 | A |
| W12S1-Q28 | reading_comprehension | developing | W12S1-T5 | B |
| W12S1-Q29 | reading_comprehension | medium | W12S1-T5 | A |
| W12S1-Q30 | strategy_transfer | medium | W12S1-T5 | D |
| W12S2-Q01 | reading_comprehension | easy | W12S2-T1 | C |
| W12S2-Q02 | reading_comprehension | developing | W12S2-T1 | A |
| W12S2-Q03 | reading_comprehension | developing | W12S2-T2 | A |
| W12S2-Q04 | reading_comprehension | medium | W12S2-T2 | D |
| W12S2-Q05 | reading_comprehension | medium | W12S2-T1 | B |
| W12S2-Q06 | reading_comprehension | medium | W12S2-T1 | C |
| W12S2-Q07 | reading_comprehension | medium | W12S2-T2 | D |
| W12S2-Q08 | vocabulary | medium | W12S2-T2 | B |
| W12S2-Q09 | vocabulary | developing | W12S2-T2 | A |
| W12S2-Q10 | vocabulary | developing | W12S2-T2 | D |
| W12S2-Q11 | vocabulary | medium | W12S2-T2 | C |
| W12S2-Q12 | strategy_transfer | medium | W12S2-T2 | C |
| W12S2-Q13 | reading_comprehension | medium | W12S2-T3 | B |
| W12S2-Q14 | reading_comprehension | developing | W12S2-T3 | A |
| W12S2-Q15 | reading_comprehension | medium | W12S2-T3 | D |
| W12S2-Q16 | vocabulary | easy | W12S2-T3 | B |
| W12S2-Q17 | reading_comprehension | easy | W12S2-T4 | B |
| W12S2-Q18 | vocabulary | developing | W12S2-T4 | C |
| W12S2-Q19 | strategy_transfer | medium | W12S2-T4 | B |
| W12S2-Q20 | reading_comprehension | medium | W12S2-T5 | D |
| W12S2-Q21 | reading_comprehension | developing | W12S2-T5 | B |
| W12S2-Q22 | reading_comprehension | medium | W12S2-T5 | D |
| W12S2-Q23 | vocabulary | medium | W12S2-T4 | C |
| W12S2-Q24 | reading_comprehension | developing | W12S2-T5 | D |
| W12S2-Q25 | reading_comprehension | medium | W12S2-T4 | A |
| W12S2-Q26 | vocabulary | developing | W12S2-T5 | A |
| W12S2-Q27 | reading_comprehension | medium | W12S2-T5 | D |
| W12S2-Q28 | reading_comprehension | medium | W12S2-T5 | A |
| W12S2-Q29 | vocabulary | developing | W12S2-T5 | C |
| W12S2-Q30 | strategy_transfer | medium | W12S2-T5 | C |

### Item-level corrections with substantive impact

| Item | Koreksi |
|---|---|
| W10S1-Q04 | Stem diubah dari pertanyaan kemampuan “can do” menjadi kewajiban “must do” agar sesuai dengan bukti `must return` |
| W10S2-Q11 | Distractor yang menjadi parafrasa sah dari `unless` diganti; satu jawaban terbaik dipertahankan |
| W10S2-Q12 | Stem transfer memakai kalimat `therefore` yang benar-benar ada di W10S2-T1; stimulus reference diselaraskan |
| W11S1-Q04, W11S1-Q12 | Bukti artikel dan jadwal dicantumkan; jadwal ditautkan sebagai stimulus tambahan |
| W11S2-Q03, W11S2-Q12 | Bukti dari dua pesan dan laporan dipisahkan melalui primary/additional stimulus references |
| W11S2-Q07 | Kunci A yang salah diganti menjadi jawaban berbagi dan memeriksa informasi ruangan yang akurat |
| W11S2-Q08, W11S2-Q10 | Kutipan disesuaikan dengan redaksi aktual pada W11S2-T2 |
| W12S1-Q06 | Jadwal ditautkan sebagai stimulus tambahan untuk item yang menggabungkan artikel dan rute kunjungan |
| W12S1-Q08, W12S1-Q11 | Stem dan bukti kosakata `allocate`/`monitor` diselaraskan dengan W12S1-T2 |
| W12S1-Q27 | Bukti untuk item NOT mentioned diganti dengan tindakan yang benar-benar tertulis pada laporan |
| W12S2-Q07, Q10, Q19, Q26, Q29 | Bukti, wording, dan stimulus references diselaraskan; Q26 dan Q29 dipindahkan ke W12S2-T5 |
| W12S2-Q28 | Distractor NOT included diperbaiki; `correct_answer` diselaraskan dengan label opsi final |

### Rationale dan opsi

- Baseline memiliki 264 rationale generik dari 528 rationale opsi.
- Revisi menyediakan 528 rationale: 132 jawaban benar + 396 distractor. Setiap rationale menyebut opsi tertentu dan alasan berbasis bukti.
- Posisi jawaban diseimbangkan 33 untuk setiap huruf; per sesi W9–W11 masing-masing 3 A/B/C/D. Pada W12, distribusi per sesi 8/8/7/7 dan 7/7/8/8.
- Keseimbangan posisi tidak membuktikan kualitas psychometric. Distractor tetap memerlukan review guru dan pilot.

## 8. Audit kosakata kumulatif

- 8 sesi × 10 cards = **80 cards**.
- Setiap sesi memiliki tepat 4 NEW + 6 RECYCLED; `new_ratio = 0.40`.
- Total **32 kata NEW unik** pada W9–W12; daftar NEW per minggu cocok dengan tabel kosakata pada Module v0.3.
- Total 48 entri RECYCLED. Kata yang muncul kembali dalam sesi sebelumnya pada Batch 3 diperiksa untuk konsistensi; tetapi status historis seluruh kata yang seharusnya berasal dari W1–W8 belum dapat dipastikan tanpa Master Bank Batch 2.
- Seluruh card memiliki word/phrase, part of speech, arti Indonesia, contoh, related term/synonym, contrast/antonym atau tanda kosong yang sesuai.
- Lima vocabulary tags yang tidak sesuai dengan kartu sesi dihapus. Tag yang tersisa hanya merujuk target card pada sesi terkait.

### NEW vocabulary by week

- **Week 9:** contradict, distractor, eliminate, irrelevant, mislead, partially, plausible, unsupported
- **Week 10:** although, cause, connector, consequence, contrast, however, therefore, unless
- **Week 11:** coherent, combine, compare, consistent, evaluate, evidence-based, synthesize, verify
- **Week 12:** accuracy, allocate, duration, monitor, prioritize, progress, reflect, stamina

## 9. Payload, keamanan, dan konsistensi data

| Pemeriksaan | Hasil pascarevisi |
|---|---:|
| Master Bank questions | 132 |
| Unique question IDs | 132/132 |
| Student Payload questions | 132 |
| Teacher Answer Payload records | 132 |
| Master/Student/Teacher ID sets | Match 132/132 |
| Student forbidden teacher fields | 0 |
| Option count | 4 per item |
| Correct key/answer mismatch | 0 |
| Option rationale records | 528 |
| Evidence quote mismatch (linked stimulus set) | 0 |
| Invalid primary/additional stimulus refs | 0 |
| Invalid `source_basis` refs | 0 |
| Vocabulary card field omissions | 0 |
| Word-count mismatches | 0/22 |
| Duplicate question IDs | 0 |
| Duplicate JSON keys | 0 |
| Teacher Guide question IDs | 132 unique IDs |

**Keamanan:** Student Payload bebas `teacher_only`, `correct_value`, `correct_answer`, `answer_key`, `explanation`, `textual_evidence`, dan `option_rationales`. Teacher Answer Payload diberi label `TEACHER_ONLY`, tetapi file-level label bukan access control. Backend wajib memeriksa autentikasi dan role sebelum mengirim jawaban. Endpoint aplikasi tidak tersedia dalam paket ini, sehingga pengujian server-side belum dilakukan.

## 10. Riset dan referensi

### 11 sumber wajib dari prompt

| Sumber | Penggunaan audit | Akses yang berhasil |
|---|---|---|
| IES/WWC (2022), *Providing Reading Interventions for Students in Grades 4–9* | Pengetahuan kata/dunia, pertanyaan, gist, pemantauan pemahaman | Panduan dan bagian rekomendasi relevan dibuka |
| EEF (2018), *Improving Literacy in Secondary Schools* | Literasi lintas mata pelajaran, vocabulary, comprehension | Halaman ringkasan/overview; bukan seluruh laporan |
| Cambridge English, B1 Preliminary format | Variasi format dan jenis teks | Halaman format ujian dibuka; tidak digunakan untuk mengklaim kesetaraan level FRTS |
| NAEP Reading Assessment Framework | Locate/recall, integrate/interpret, critique/evaluate | Halaman framework dibuka |
| British Council, *Modal Verbs* | Modalitas kemungkinan/kepastian/izin/kewajiban | Halaman grammar dibuka |
| British Council, *Modals: Permission and Obligation* | Must not vs don't have to; obligation/permission | Halaman grammar dibuka |
| British Council, *Questions and Negatives* | Negation dan pengaruh `not` pada makna | Halaman grammar dibuka |
| British Council LearnEnglish Teens, *Conjunctions* | Cause/effect, contrast, choice, addition | Halaman grammar dibuka |
| Jhangiani/KPU, *Guidelines for Writing Effective Distractors* | Plausibility, eksklusivitas, panjang opsi, wording | PDF satu halaman dibaca |
| Kim & Webb (2022), *The Effects of Spaced Practice on Second Language Learning* | Spaced practice untuk kosakata | Abstrak publisher; full text tidak tersedia |
| Nakata et al. (2021), *Effects of Distributed Retrieval Practice Over a Semester* | Cumulative retrieval/vocabulary testing | Abstrak dan bagian metode publisher; full text tidak sepenuhnya tersedia |

### Referensi tambahan

- **OECD, PISA 2018 Reading Framework:** konteks cross-text integration; halaman penuh timeout, sehingga hanya ringkasan pencarian yang dapat diperiksa.
- **Gierl et al. (2017):** tinjauan pengembangan dan analisis distractor; metadata/abstrak tersedia, full text tidak berhasil dibuka.
- **Raina, Liusie & Gales (2023):** kerangka kualitas distractor melalui incorrectness, plausibility, dan diversity; PDF prosiding dibaca penuh.

### Implikasi riset untuk revisi

- Rekomendasi IES/WWC dan EEF mendukung pembelajaran eksplisit kosakata, pertanyaan, gist, serta pemantauan pemahaman; ini digunakan sebagai konteks desain, bukan bukti bahwa urutan FRTS sudah tervalidasi.
- NAEP membedakan pencarian detail dari integrasi/interpretasi dan evaluasi; pembedaan ini digunakan untuk mengaudit W11 dan W12.
- Kim & Webb dan Nakata et al. memberi dasar umum untuk spaced/retrieval practice. Sampel Nakata et al. adalah mahasiswa universitas Jepang, sehingga transfer langsung ke siswa SMP Indonesia tidak boleh diasumsikan.
- Raina et al. menyoroti incorrectness, plausibility, dan diversity distractor; prinsip ini digunakan untuk memperbaiki distractor yang ambigu atau terlalu lemah.

## 11. Distribusi per sesi

| Sesi | Soal | Reading | Vocabulary | Strategy transfer | Easy | Developing | Medium | A | B | C | D |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| W9-ONLINE-01 | 12 | 7 | 4 | 1 | 4 | 5 | 3 | 3 | 3 | 3 | 3 |
| W9-ONLINE-02 | 12 | 7 | 4 | 1 | 3 | 5 | 4 | 3 | 3 | 3 | 3 |
| W10-ONLINE-01 | 12 | 7 | 4 | 1 | 3 | 4 | 5 | 3 | 3 | 3 | 3 |
| W10-ONLINE-02 | 12 | 7 | 4 | 1 | 3 | 4 | 5 | 3 | 3 | 3 | 3 |
| W11-ONLINE-01 | 12 | 7 | 4 | 1 | 2 | 5 | 5 | 3 | 3 | 3 | 3 |
| W11-ONLINE-02 | 12 | 7 | 4 | 1 | 2 | 4 | 6 | 3 | 3 | 3 | 3 |
| W12-ONLINE-01 | 30 | 18 | 9 | 3 | 5 | 10 | 15 | 8 | 8 | 7 | 7 |
| W12-ONLINE-02 | 30 | 18 | 9 | 3 | 3 | 10 | 17 | 7 | 7 | 8 | 8 |

## 12. Hal yang belum boleh diklaim

1. Belum classroom validated: belum ada pilot siswa, response-time data, distractor analysis empiris, item facility/discrimination, atau feedback guru.
2. Belum psychometrically calibrated: Easy/Developing/Medium tetap estimasi internal.
3. Belum production-ready: API integration, database schema, authentication, authorization, and endpoint security belum diuji.
4. Belum tuntas validasi historis seluruh 48 RECYCLED terhadap Batch 2 karena bank sumber Batch 2 tidak disertakan dalam ZIP yang diaudit.
5. W9–W11 dalam paket ini hanya 12 soal/sesi dan belum memenuhi target 25 soal/sesi dalam Master Plan; jumlah dipertahankan sesuai prompt.
6. Modul belum memenuhi secara eksplisit lima soal penguatan untuk setiap major explanation/lesson section; yang tersedia adalah lima pemeriksaan mandiri per minggu.
7. Jangan menyebut FRTS sebagai program resmi TKA SMP atau menyatakan semua stimulus setara CEFR B1.

## 13. Keputusan akhir

**Structural QA: PASS.** Master, Student, Teacher, dan Guide sinkron; tidak ada kebocoran jawaban pada Student Payload; semua kunci dan evidence references lulus pemeriksaan pascarevisi.

**Academic/production status: PARTIAL — REVISED DRAFT / OWNER REVIEW.** Dua readiness gate HIGH tetap terbuka: pengujian server-side teacher authorization dan pilot siswa. Scope gap kuantitas W9–W11, verifikasi historis RECYCLED, dan reinforcement questions juga harus ditangani pada siklus berikutnya.

## 14. Revision history

| Versi | Tanggal | Perubahan |
|---|---|---|
| 0.2 | 15 November 2026 | Baseline package |
| 0.3 | 15 November 2026 | Audit seluruh 132 item/22 stimulus; koreksi key, ambiguity, evidence, stimulus links, vocabulary tags, word counts, rationale, answer-position balance; rebuild student/teacher payloads and guide |

## 15. Referensi dan URL

1. IES/WWC (2022): https://ies.ed.gov/ncee/wwc/PracticeGuide/29
2. EEF (2018): https://educationendowmentfoundation.org.uk/education-evidence/guidance-reports/Literacy-ks3-ks4
3. Cambridge English: https://www.cambridgeenglish.org/exams-and-tests/qualifications/preliminary/format/
4. NAEP: https://www.nationsreportcard.gov/reading/about/framework/
5. British Council Modal Verbs: https://learnenglish.britishcouncil.org/free-resources/grammar/english-grammar-reference/modal-verbs
6. British Council Modals Permission/Obligation: https://learnenglish.britishcouncil.org/free-resources/grammar/b1-b2/modals-permission-obligation
7. British Council Questions and Negatives: https://learnenglish.britishcouncil.org/free-resources/grammar/english-grammar-reference/questions-negatives
8. British Council Conjunctions: https://learnenglishteens.britishcouncil.org/grammar/a1-a2-grammar/conjunctions-or-so-because-although
9. Jhangiani/KPU: https://www.kpu.ca/sites/default/files/Teaching%20and%20Learning/Guidelines-for-writing-effective-distractors-for-multiple-choice-questions.pdf
10. Kim & Webb (2022): https://doi.org/10.1111/lang.12479
11. Nakata et al. (2021): https://doi.org/10.1002/tesq.596
12. OECD PISA 2018 Reading Framework: https://www.oecd.org/en/publications/pisa-2018-assessment-and-analytical-framework_b25efab8-en/full-report/component-3.html
13. Gierl et al. (2017): https://doi.org/10.3102/0034654317726529
14. Raina et al. (2023): https://aclanthology.org/2023.eval4nlp-1.2/