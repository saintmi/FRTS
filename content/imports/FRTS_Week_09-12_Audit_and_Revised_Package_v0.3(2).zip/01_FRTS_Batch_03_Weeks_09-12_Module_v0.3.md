# FRTS — BATCH 3 INTEGRATED LEARNING DOCUMENT
## Weeks 9–12 | Student Modules + Teacher Guides + Vocabulary + Assessment Alignment

**Document ID:** FRTS-BATCH-03  
**Version:** 0.3 — Audit-corrected revision  
**Status:** PARTIAL — revised draft for owner review; belum divalidasi melalui pilot siswa  
**Program:** English Reading Preparation for SMP Grades 7–9  
**Cakupan:** Distractor analysis, micro-grammar for reading, integrated reading, dan awal mixed-practice phase  
**Format:** 1 pertemuan tatap muka 60 menit per minggu + 2 sesi latihan online per minggu  
**Standar waktu tatap muka:** penjelasan/pemodelan guru maksimal 30 menit; praktik, umpan balik, dan refleksi minimal 30 menit.

---

# 1. HUBUNGAN DENGAN BATCH SEBELUMNYA

Batch 3 melanjutkan keterampilan yang telah dibangun pada:

- **Batch 1 (W1–W4):** reading foundation, Question-First Reading, scanning, hubungan kosakata, dan paraphrase.
- **Batch 2 (W5–W8):** gist/main idea, context clues, reference tracking, inference, dan textual evidence.

Batch 3 tidak mengulang seluruh teori dari awal. Siswa menggunakan keterampilan tersebut dalam situasi membaca yang lebih kompleks, terutama ketika pilihan jawaban tampak mirip, petunjuk gramatikal mengubah makna, atau informasi harus digabungkan.

## Pembagian fokus

| Minggu | Fokus | Posisi dalam program |
|---:|---|---|
| 9 | Distractor Analysis | Menuntaskan strategi menjawab dan mengevaluasi pilihan |
| 10 | Micro-Grammar for Reading | Membaca petunjuk tata bahasa yang mengubah hubungan/makna |
| 11 | Integrated Reading | Menggabungkan seluruh strategi W1–W10 |
| 12 | Mixed Reading Practice & Pacing | Awal fase latihan campuran W12–W19 |

**Catatan W12:** Minggu 12 merupakan transisi dari pembelajaran strategi ke latihan campuran. Ini belum dimaksudkan sebagai simulasi ujian penuh. Siswa mulai menggabungkan berbagai jenis teks dan pertanyaan, kemudian mengelola waktu secara wajar.

---

# PART A — MODUL SISWA

# WEEK 9 — DISTRACTOR ANALYSIS: MEMERIKSA PILIHAN JAWABAN

## 1. Tujuan belajar

Setelah mempelajari minggu ini, siswa diharapkan mampu:
1. Memahami bahwa pilihan jawaban yang tampak masuk akal belum tentu benar.
2. Mengenali pilihan yang menggunakan kata serupa tetapi tidak menjawab pertanyaan.
3. Membedakan pilihan yang salah target, bertentangan, tidak relevan, hanya sebagian benar, atau tidak didukung bukti.
4. Memeriksa makna lengkap pilihan sebelum menjawab.
5. Menjelaskan alasan menolak pilihan dengan menggunakan bukti teks.

## 2. Apa itu distractor?

**Distractor (pilihan pengecoh)** adalah pilihan jawaban yang dirancang agar tampak mungkin, tetapi tidak memenuhi tuntutan pertanyaan atau tidak didukung oleh bacaan.

Pilihan pengecoh yang baik tidak selalu terlihat salah pada pandangan pertama. Karena itu, siswa harus memeriksa pertanyaan, target informasi, dan isi lengkap pilihan.

Contoh:

Notice:
> The gardening demonstration starts at 9:15 a.m. The poster display remains open until 11:30 a.m.

Question:
> What time does the gardening demonstration start?

Pilihan:
- 9:15 a.m.
- 11:30 a.m.
- 8:00 a.m.
- 12:00 p.m.

Dua waktu pertama sama-sama ada dalam teks. Namun, hanya 9:15 a.m. yang menjawab waktu mulai demonstrasi. Waktu 11:30 a.m. adalah waktu penutupan display. Inilah contoh pilihan yang menggunakan informasi benar tetapi salah target.

## 3. Lima jenis jebakan pilihan jawaban

### A. Keyword match — kata yang sama, makna tidak cocok

Opsi mengulang kata dari bacaan, tetapi hubungan maknanya berbeda.

Cara memeriksa:
- Jangan berhenti pada kata yang sama.
- Baca kalimat sebelum dan sesudahnya.
- Pastikan opsi menjawab pertanyaan yang tepat.

### B. Wrong target — salah jenis informasi

Pertanyaan menanyakan tempat, tetapi opsi memberikan waktu. Pertanyaan menanyakan waktu mulai, tetapi opsi memberikan batas pendaftaran.

Cara memeriksa:
1. Baca kata tanya.
2. Ubah pertanyaan menjadi target.
3. Cocokkan opsi dengan target tersebut.

### C. Partially correct — hanya sebagian benar

Pilihan dapat memberikan satu informasi yang benar tetapi mengubah bagian lainnya.

Contoh:
- Teks: acara berlangsung pada 12 Mei pukul 9:00.
- Opsi: acara berlangsung pada 12 Mei pukul 10:00.

Tanggal benar, tetapi waktu salah. Karena seluruh pernyataan harus benar, opsi tersebut tidak dapat dipilih.

### D. Contradicted — bertentangan dengan bacaan

Opsi menyatakan sesuatu yang justru dibantah oleh teks.

Perhatikan penanda:
- not
- never
- instead
- but
- however
- only

Jangan melewatkan kata negatif. Satu kata seperti **not** dapat membalik makna kalimat.

### E. Irrelevant or unsupported — tidak relevan atau tidak didukung

- **Irrelevant (tidak relevan):** informasi mungkin benar, tetapi tidak menjawab pertanyaan.
- **Unsupported (tidak didukung):** bacaan tidak memberikan bukti yang cukup untuk menyatakan pilihan tersebut benar.

Informasi yang tidak disebutkan tidak otomatis salah dalam kehidupan nyata. Namun, informasi itu tidak boleh dipilih sebagai jawaban yang didukung teks.

## 4. Rutinitas memeriksa pilihan

Gunakan urutan ini:

1. Baca pertanyaan dan temukan targetnya.
2. Temukan bukti pada bacaan.
3. Baca seluruh isi setiap opsi, bukan hanya kata kuncinya.
4. Periksa apakah opsi menjawab target.
5. Periksa apakah ada bagian yang bertentangan atau hanya sebagian benar.
6. Tolak pilihan yang tidak didukung.
7. Pilih opsi yang paling tepat dan paling lengkap berdasarkan bukti.

## 5. Contoh pemodelan

Text:
> The clean-up activity will take place along the east path. The boat station is only the meeting landmark.

Question:
> Where will the clean-up activity take place?

Opsi “at the boat station” tampak mungkin karena nama tempat itu disebut. Namun, teks menyatakan bahwa boat station hanya menjadi penanda pertemuan. Lokasi kegiatan adalah east path.

**Ingat:** kata yang muncul di bacaan belum tentu menjadi jawaban. Hubungan maknanya harus benar.

## 6. Kosakata baru Week 9

| Kata | Kelas kata | Arti Bahasa Indonesia | Padanan/relasi makna |
|---|---|---|---|
| distractor | noun | pilihan jawaban pengecoh | plausible wrong option |
| plausible | adjective | tampak masuk akal | reasonable, believable |
| contradict | verb | bertentangan dengan | conflict with |
| eliminate | verb | menghapus/mencoret dari pilihan | remove, rule out |
| irrelevant | adjective | tidak berkaitan dengan pertanyaan | unrelated |
| partially | adverb | sebagian, tidak seluruhnya | partly |
| mislead | verb | menyesatkan | give a false impression |
| unsupported | adjective | tidak didukung bukti | not backed up |

Sinonim dan kata yang berhubungan tetap harus diperiksa berdasarkan konteks. Tidak semua kata dapat saling menggantikan dalam setiap kalimat.

## 7. Pemeriksaan mandiri Week 9

1. Mengapa kata yang sama dalam bacaan dan opsi belum tentu membuktikan jawaban benar?
2. Apa perbedaan pilihan partially correct dan unsupported?
3. Jika informasi benar tetapi tidak menjawab pertanyaan, bagaimana sebaiknya pilihan itu dinilai?
4. Apa yang harus dilakukan ketika opsi bertentangan dengan kalimat yang memuat kata not?
5. Mengapa seluruh bagian opsi harus diperiksa, bukan hanya kata kuncinya?

---

# WEEK 10 — MICRO-GRAMMAR FOR READING

## 1. Tujuan belajar

Minggu 10 berfokus pada penggunaan petunjuk tata bahasa sederhana untuk memahami hubungan makna dalam bacaan. Grammar bukan tujuan utama; siswa menggunakan bentuk bahasa sebagai petunjuk untuk membaca secara lebih akurat.

Siswa diharapkan mampu:
1. Mengenali kata penghubung yang menunjukkan hubungan gagasan.
2. Memahami petunjuk sebab-akibat, kontras, urutan, dan syarat.
3. Memperhatikan negasi agar tidak membalik makna.
4. Membedakan izin, kewajiban, larangan, dan kemungkinan melalui kata modal.
5. Menggunakan petunjuk tata bahasa untuk memahami bacaan, bukan menghafal aturan tanpa konteks.

## 2. Apa itu micro-grammar?

**Micro-grammar (petunjuk tata bahasa dalam bagian kecil teks)** adalah perhatian terhadap bentuk bahasa tertentu yang sangat memengaruhi makna sebuah kalimat atau hubungan antarkalimat.

Pada FRTS, grammar bukan tujuan utama minggu ini. Siswa tidak diminta mempelajari seluruh aturan tata bahasa. Siswa belajar memperhatikan kata atau bentuk yang dapat mengubah:
- hubungan sebab dan akibat;
- hubungan kontras;
- urutan kejadian;
- kewajiban atau izin;
- kemungkinan atau tingkat kepastian;
- makna positif dan negatif.

## 3. Connector — kata penghubung

**Connector (kata penghubung)** menghubungkan bagian kalimat atau gagasan dan menunjukkan hubungan makna.

### A. Cause and effect — sebab dan akibat

| Kata | Makna | Petunjuk |
|---|---|---|
| because | karena | memperkenalkan alasan |
| so | sehingga/jadi | memperkenalkan hasil |
| therefore | oleh karena itu | memperkenalkan akibat/kesimpulan |
| as a result | sebagai akibatnya | memperkenalkan hasil |

Contoh:
> The bus was late because the road was flooded.

Alasan keterlambatan adalah jalan yang banjir.

> The road was flooded; therefore, the bus was late.

Kondisi jalan menjadi sebab dan keterlambatan menjadi akibat.

### B. Contrast — kontras

| Kata | Makna | Petunjuk |
|---|---|---|
| but | tetapi | menunjukkan perbedaan |
| although | meskipun | memperkenalkan keadaan yang berlawanan dengan harapan |
| however | namun | menunjukkan kontras dengan gagasan sebelumnya |
| whereas | sedangkan | membandingkan dua keadaan atau pilihan |

Contoh:
> The room was small, but it was comfortable.

Ukuran ruangan kecil, tetapi kenyamanannya baik. Dua gagasan memiliki hubungan kontras.

> Some students read stories, whereas others prepared projects.

Kata whereas membandingkan pilihan dua kelompok.

### C. Sequence — urutan

| Kata/frasa | Makna |
|---|---|
| first | pertama |
| next | berikutnya |
| after that | setelah itu |
| finally | akhirnya/terakhir |
| before | sebelum |
| after | setelah |

Kata tersebut membantu pembaca menentukan urutan kejadian. Jangan menukar urutan hanya karena dua kegiatan disebut dalam paragraf yang sama.

### D. Condition — syarat

**Unless (kecuali jika)** memiliki makna yang dekat dengan *if ... not* (jika tidak).

Contoh:
> Visitors may not enter the storage area unless a teacher is present.

Artinya, pengunjung tidak boleh masuk ke ruang penyimpanan jika tidak ada guru.

## 4. Negation — penanda negatif

Kata negatif dapat mengubah arti pernyataan.

Perhatikan:
- not
- no
- never
- cannot/can't
- do not/don't
- must not/mustn't

Contoh:
> The library is open on Sunday.

> The library is not open on Sunday.

Kedua kalimat memiliki makna berlawanan karena adanya not.

Pada soal **NOT mentioned** atau **EXCEPT**, siswa harus memeriksa kata negatif pada pertanyaan dan pilihan dengan teliti.

## 5. Modal verbs — kata kerja modal

Kata modal memberi petunjuk tentang kewajiban, izin, larangan, atau kemungkinan.

| Bentuk | Makna umum dalam konteks bacaan |
|---|---|
| must / have to | wajib atau harus |
| must not / mustn't | dilarang |
| don't have to | tidak wajib; boleh dilakukan, tetapi tidak harus |
| can / may | dapat atau diizinkan, tergantung konteks |
| might / may / could | mungkin; belum pasti |
| should | sebaiknya atau disarankan |

Contoh:
> Students must return the books within seven days.

Siswa wajib mengembalikan buku dalam tujuh hari.

> Students don't have to donate food to join the activity.

Menyumbang makanan bukan kewajiban untuk mengikuti kegiatan.

> The new schedule may help some students.

Jadwal baru mungkin membantu beberapa siswa. Kalimat ini tidak menyatakan bahwa hasilnya pasti.

**Peringatan:** *must not* berbeda dari *don't have to*. Must not berarti dilarang, sedangkan don't have to berarti tidak wajib.

## 6. Cara membaca petunjuk micro-grammar

1. Temukan kata penghubung, penanda negatif, atau modal.
2. Baca bagian sebelum dan sesudahnya.
3. Tentukan hubungan makna yang ditunjukkan.
4. Periksa apakah pilihan jawaban mempertahankan hubungan tersebut.
5. Jangan mengubah kemungkinan menjadi kepastian atau saran menjadi kewajiban.

## 7. Kosakata baru Week 10

| Kata | Kelas kata | Arti Bahasa Indonesia | Padanan/relasi makna |
|---|---|---|---|
| connector | noun | kata penghubung | linking word |
| contrast | noun | perbedaan/pertentangan | difference, opposition |
| cause | noun/verb | sebab/menyebabkan | reason, bring about |
| consequence | noun | akibat | result, outcome |
| although | conjunction | meskipun | even though |
| however | linking adverb | namun | nevertheless |
| therefore | linking adverb | oleh karena itu | as a result |
| unless | conjunction | kecuali jika | if not |

## 8. Pemeriksaan mandiri Week 10

1. Apa hubungan yang biasanya ditunjukkan oleh because?
2. Apa perbedaan makna but/however dengan therefore?
3. Bagaimana kata not dapat mengubah jawaban?
4. Apa perbedaan must not dan don't have to?
5. Mengapa may atau might tidak boleh langsung diartikan sebagai kepastian?

---

# WEEK 11 — INTEGRATED READING

## 1. Tujuan belajar

Siswa diharapkan mampu:
1. Menggabungkan beberapa strategi membaca yang telah dipelajari.
2. Membandingkan informasi dari dua bagian teks atau dua teks pendek.
3. Memeriksa kesesuaian informasi dan bukti.
4. Memahami hubungan antara gist, detail, referensi kata, inferensi, dan pilihan jawaban.
5. Menyusun kesimpulan yang tetap sesuai dengan informasi sumber.

## 2. Mengapa strategi perlu digabungkan?

Dalam bacaan yang lebih panjang, satu strategi saja sering tidak cukup.

Contohnya:
- Pertanyaan meminta gagasan utama, sehingga siswa perlu skimming.
- Pertanyaan meminta waktu kegiatan, sehingga siswa perlu scanning.
- Kata yang ditanyakan tidak dikenal, sehingga siswa menggunakan context clues.
- Pertanyaan menanyakan rujukan *this* atau *they*, sehingga siswa perlu reference tracking.
- Pertanyaan meminta kesimpulan, sehingga siswa perlu inference dan textual evidence.
- Ada dua teks dengan informasi berbeda, sehingga siswa perlu membandingkan dan memverifikasi.

## 3. Rangkaian Integrated Reading FRTS

Gunakan urutan berikut:

1. **Question-first:** baca pertanyaan lebih dahulu.
2. **Target:** tentukan informasi atau gagasan yang dicari.
3. **Locate:** temukan bagian teks yang relevan melalui skimming atau scanning.
4. **Understand:** gunakan context clues dan micro-grammar jika diperlukan.
5. **Connect:** periksa rujukan kata dan hubungan antarkalimat.
6. **Combine:** gabungkan informasi jika pertanyaan memerlukan lebih dari satu bagian atau lebih dari satu teks.
7. **Verify:** cocokkan kesimpulan dengan bukti.
8. **Evaluate:** periksa apakah pilihan jawaban mengandung distractor, informasi sebagian benar, atau klaim berlebihan.

Urutan ini merupakan rutinitas praktik FRTS, bukan aturan bahwa semua pertanyaan selalu membutuhkan delapan langkah secara penuh.

## 4. Membandingkan dua teks

Contoh:

Text A:
> The art exhibition will use the school hall from Tuesday to Thursday.

Text B:
> The reading corner will remain open, but group tables will be unavailable during the exhibition.

Informasi yang dapat digabungkan:
- Aula digunakan untuk pameran.
- Sudut baca tetap terbuka.
- Meja kelompok tidak tersedia.
- Kegiatan membaca tenang tetap dapat berlangsung.

Jangan menyimpulkan bahwa seluruh perpustakaan ditutup, karena teks hanya menyebut meja kelompok tidak tersedia.

## 5. Memeriksa konsistensi bukti

**Consistent (konsisten/selaras)** berarti informasi tidak saling bertentangan.

Jika dua teks menyebut jadwal yang sama, periksa:
- tanggal;
- jam;
- lokasi;
- nama kegiatan;
- aturan;
- perubahan yang diumumkan.

Jika satu teks memberikan informasi tambahan, jangan menganggapnya bertentangan sebelum memeriksa apakah informasi itu menjelaskan bagian yang belum dibahas.

## 6. Kosakata baru Week 11

| Kata | Kelas kata | Arti Bahasa Indonesia | Padanan/relasi makna |
|---|---|---|---|
| combine | verb | menggabungkan | join, put together |
| verify | verb | memeriksa untuk memastikan | check, confirm |
| consistent | adjective | selaras/tidak bertentangan | compatible, in agreement |
| evidence-based | adjective | berdasarkan bukti | supported by evidence |
| synthesize | verb | menyatukan berbagai informasi | integrate, bring together |
| coherent | adjective | runtut dan saling berhubungan | logical, connected |
| compare | verb | membandingkan | examine side by side |
| evaluate | verb | menilai berdasarkan bukti/kriteria | assess, judge |

## 7. Pemeriksaan mandiri Week 11

1. Mengapa dua teks perlu dibandingkan jika pertanyaan meminta informasi gabungan?
2. Apa yang harus dilakukan sebelum menyatakan dua informasi bertentangan?
3. Apa perbedaan combine dan synthesize dalam konteks membaca?
4. Mengapa kesimpulan harus sesuai dengan bukti dari teks?
5. Bagaimana cara menghindari penambahan informasi yang tidak disebutkan?

---

# WEEK 12 — MIXED READING PRACTICE AND PACING

## 1. Tujuan belajar

Siswa diharapkan mampu:
1. Menggunakan strategi W1–W11 pada berbagai jenis teks.
2. Memilih strategi berdasarkan pertanyaan dan bentuk stimulus.
3. Mengelola waktu latihan secara wajar.
4. Menandai soal yang perlu diperiksa kembali.
5. Memeriksa jawaban dan merefleksikan hasil latihan.

## 2. Apa itu mixed practice?

**Mixed practice (latihan campuran)** adalah latihan yang menggabungkan beberapa materi atau keterampilan dalam satu rangkaian.

Siswa dapat menemukan:
- artikel informasi;
- descriptive, recount, dan narrative;
- notice dan announcement;
- jadwal dan tabel;
- pesan atau email;
- pertanyaan detail;
- gagasan utama;
- makna kosakata;
- referensi kata;
- inferensi dan bukti;
- pilihan jawaban yang mengandung distractor.

Tujuannya adalah membantu siswa memilih strategi yang tepat tanpa diberi tahu terlebih dahulu strategi apa yang harus digunakan.

## 3. Memilih strategi berdasarkan pertanyaan

| Pertanyaan | Strategi yang dapat digunakan |
|---|---|
| What is the text mainly about? | Skimming dan gist |
| What time does the event begin? | Scanning |
| What does the word mean? | Context clues |
| What does “they” refer to? | Reference tracking |
| What can be concluded? | Inference dan textual evidence |
| Which option is NOT supported? | Pemeriksaan seluruh opsi |
| How are the two texts related? | Integrated reading |

Satu pertanyaan dapat membutuhkan lebih dari satu strategi.

## 4. Mengelola waktu latihan

Tidak semua soal membutuhkan waktu yang sama. Gunakan langkah berikut:

1. Baca seluruh pertanyaan dengan teliti.
2. Tentukan target informasi.
3. Kerjakan soal yang dapat dijawab dengan bukti jelas.
4. Jika satu soal terlalu menyita waktu, tandai dan lanjutkan.
5. Kembali ke soal yang ditandai jika waktu masih tersedia.
6. Sisihkan waktu untuk memeriksa soal NOT/EXCEPT, angka, tanggal, kontras, dan kemungkinan.

Jangan terburu-buru hanya untuk menyelesaikan semua soal. Ketepatan jawaban tetap penting.

## 5. Setelah latihan selesai

Lakukan refleksi:
- Soal apa yang paling mudah?
- Soal apa yang membutuhkan waktu paling lama?
- Apakah jawaban didasarkan pada bukti atau tebakan?
- Apakah ada kosakata yang masih tertukar?
- Strategi apa yang perlu dilatih kembali?

**Progress (kemajuan)** lebih baik dinilai dari pola hasil beberapa latihan, bukan dari satu skor saja.

## 6. Kosakata baru Week 12

| Kata | Kelas kata | Arti Bahasa Indonesia | Padanan/relasi makna |
|---|---|---|---|
| allocate | verb | membagi atau menetapkan bagian | assign, distribute |
| prioritize | verb | mendahulukan yang penting | rank, give priority to |
| duration | noun | lama waktu berlangsung | length of time |
| monitor | verb | memantau | track, observe |
| accuracy | noun | ketepatan | correctness, precision |
| stamina | noun | daya tahan | endurance |
| reflect | verb | meninjau atau merenungkan | think over, review |
| progress | noun/verb | kemajuan/berkembang | improvement, development |

## 6A. Standar latihan online Week 12

Minggu 12 memiliki **60 soal online**, dibagi menjadi dua sesi masing-masing 30 soal. Jumlah ini lebih besar daripada minggu fondasi karena fokus pembelajaran telah bergeser dari penjelasan teknik menuju penerapan dan penguatan.

Komposisi setiap sesi 30 soal:
- 18 soal pemahaman bacaan (*reading comprehension*).
- 9 soal kosakata (*vocabulary*), termasuk makna kontekstual dan pengulangan kumulatif.
- 3 soal transfer strategi (*strategy transfer*).

Distribusi kesulitan yang ditetapkan sebagai target desain:
- Online 01: 5 mudah, 10 berkembang, 15 menengah.
- Online 02: 3 mudah, 10 berkembang, 17 menengah.

Setiap sesi tetap memiliki 10 target vocabulary cards: 4 NEW dan 6 RECYCLED. Kata baru diperkenalkan melalui bacaan dan konteks soal, bukan melalui bab teori atau strategi membaca baru.

## 7. Pemeriksaan mandiri Week 12

1. Apa yang dimaksud mixed practice?
2. Mengapa strategi perlu dipilih berdasarkan pertanyaan?
3. Apa yang dapat dilakukan jika satu soal membutuhkan waktu terlalu lama?
4. Mengapa accuracy tidak boleh dikorbankan hanya demi kecepatan?
5. Informasi apa yang perlu dicatat setelah menyelesaikan latihan?

---

# PART B — PANDUAN GURU

## Prinsip umum

- Pertemuan tepat 60 menit.
- Penjelasan dan pemodelan maksimal 30 menit.
- Minimal 30 menit untuk aktivitas siswa, pembahasan, umpan balik, dan refleksi.
- Modul siswa menjadi sumber belajar mandiri; guru tidak perlu membacakan seluruh isi.
- Sediakan contoh baru ketika memodelkan strategi. Hindari menjadikan kunci latihan online sebagai satu-satunya contoh.

### WEEK 9 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall Question-First, evidence, dan inference dari W2, W7, W8 |
| 4–10 | Jelaskan distractor dan lima jenis jebakan |
| 10–17 | Think-aloud: kata yang sama tetapi salah target |
| 17–23 | Bandingkan partially correct, contradicted, irrelevant, unsupported |
| 23–27 | Modelkan eliminasi pilihan berdasarkan bukti |
| 27–30 | Quick check: siswa menjelaskan alasan satu opsi salah |
| 30–40 | Siswa mengelompokkan empat opsi ke jenis jebakan |
| 40–49 | Pasangan mengerjakan passage-based item dan menandai bukti |
| 49–56 | Umpan balik; guru meminta alasan spesifik untuk setiap opsi |
| 56–60 | Exit ticket dan pengantar sesi online |

**Kesalahan umum:** menganggap kata yang sama pasti jawaban; menolak opsi hanya karena tidak tertulis persis; mengabaikan sebagian informasi yang salah.

**Indikator:** siswa dapat menunjukkan target pertanyaan, bukti, dan alasan spesifik untuk menolak distraktor.

### WEEK 10 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall: hubungan gagasan dan modalitas dalam W8 |
| 4–10 | Perkenalkan micro-grammar sebagai petunjuk makna |
| 10–17 | Modelkan because/so/therefore dan hubungan sebab-akibat |
| 17–22 | Modelkan but/although/however dan kontras |
| 22–26 | Bandingkan must not, don't have to, may/might |
| 26–30 | Quick check: siswa menjelaskan perubahan makna akibat satu kata |
| 30–40 | Siswa menandai connector, negation, dan modal dalam teks |
| 40–49 | Pasangan memilih jawaban berdasarkan hubungan makna |
| 49–56 | Diskusi kasus ambigu; guru mengingatkan konteks |
| 56–60 | Exit ticket |

**Kesalahan umum:** menyamakan must not dengan don't have to; membaca may sebagai kepastian; menganggap therefore dan however memiliki fungsi yang sama.

**Indikator:** siswa dapat menjelaskan hubungan makna yang ditandai kata penghubung/modal tanpa harus menguraikan seluruh tata bahasa kalimat.

### WEEK 11 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall strategi W1–W10 |
| 4–10 | Jelaskan kapan satu strategi tidak cukup |
| 10–17 | Modelkan question → target → lokasi bukti |
| 17–23 | Modelkan penggabungan informasi dari dua teks |
| 23–27 | Modelkan pemeriksaan konsistensi dan over-inference |
| 27–30 | Quick check: siswa menyebut sumber bukti untuk satu kesimpulan |
| 30–40 | Pasangan mengerjakan dua teks pendek |
| 40–49 | Siswa mengisi tabel informasi yang sama, berbeda, dan tambahan |
| 49–56 | Umpan balik dan pembahasan distraktor lintas teks |
| 56–60 | Exit ticket |

**Kesalahan umum:** menggunakan satu teks saja padahal soal lintas teks; menganggap tambahan informasi sebagai kontradiksi; menyimpulkan lebih jauh dari bukti.

**Indikator:** siswa dapat menggabungkan dua detail relevan dan menunjukkan bukti sumbernya.

### WEEK 12 — Teacher Guide (60 menit)

Dua sesi online minggu ini berisi total 60 soal (30 soal per sesi). Pertemuan offline tidak digunakan untuk mengajarkan teknik baru; guru membahas cara memilih strategi, contoh kesalahan, dan pengelolaan waktu.


| Menit | Kegiatan |
|---:|---|
| 0–4 | Jelaskan bahwa mulai minggu ini latihan menjadi campuran |
| 4–10 | Tampilkan variasi teks dan tipe pertanyaan |
| 10–17 | Modelkan pemilihan strategi dari kata tanya dan target |
| 17–23 | Modelkan cara menandai soal yang membutuhkan waktu lebih lama |
| 23–27 | Modelkan pemeriksaan akhir: NOT/EXCEPT, angka, waktu, modal |
| 27–30 | Quick check dan instruksi latihan |
| 30–42 | Siswa mengerjakan set campuran singkat |
| 42–50 | Siswa membandingkan jawaban dengan bukti |
| 50–56 | Siswa menganalisis satu kesalahan atau tebakan |
| 56–60 | Refleksi strategi dan target latihan berikutnya |

**Kesalahan umum:** menerapkan scanning pada pertanyaan gist; terlalu lama pada satu soal; mengejar kecepatan dengan mengabaikan bukti.

**Indikator:** siswa dapat memilih strategi sesuai jenis pertanyaan, memeriksa bukti, dan menjelaskan kapan perlu kembali ke soal.

---

# PART C — VOCABULARY RECYCLE REGISTER

Setiap sesi online memiliki tepat 10 target vocabulary cards: 4 NEW dan 6 RECYCLED. Rasio kosakata baru dihitung berdasarkan target cards, bukan semua kata yang muncul dalam bacaan.

| Sesi | 4 NEW | 6 RECYCLED |
|---|---|---|
| W9 Online 01 | distractor, plausible, contradict, eliminate | imply, likely, evidence, specific, reason, detail |
| W9 Online 02 | irrelevant, partially, mislead, unsupported | distractor, plausible, contradict, eliminate, purpose, sequence |
| W10 Online 01 | connector, contrast, cause, consequence | purpose, sequence, detail, reason, relevant, available |
| W10 Online 02 | although, however, therefore, unless | connector, contrast, cause, consequence, likely, indicate |
| W11 Online 01 | combine, verify, consistent, evidence-based | overview, summary, relevant, purpose, detail, likely |
| W11 Online 02 | synthesize, coherent, compare, evaluate | combine, verify, consistent, evidence-based, main idea, record |
| W12 Online 01 | allocate, prioritize, duration, monitor | synthesize, coherent, compare, evaluate, evidence, specific |
| W12 Online 02 | accuracy, stamina, reflect, progress | allocate, prioritize, duration, monitor, verify, evidence |

### Aturan pengulangan

- Kata NEW pada sesi sebelumnya menjadi RECYCLED pada sesi berikutnya jika digunakan kembali sebagai target.
- Contoh kalimat untuk kata RECYCLED harus berbeda dari contoh saat pertama diperkenalkan.
- Makna, kelas kata, dan padanan harus diperiksa sesuai konteks.
- Jangan memaksakan antonim jika tidak ada pasangan berlawanan yang tepat.
- Kosakata baru tidak boleh menjadi satu-satunya penentu jawaban jika siswa belum mendapat konteks yang memadai.

---

# PART D — ASSESSMENT ALIGNMENT DAN BLUEPRINT

## 1. Komposisi sesi online dalam paket ini

- Minggu 9–11: 12 soal per sesi (7 reading comprehension, 4 vocabulary, 1 strategy transfer).
- Minggu 12: 30 soal per sesi (18 reading comprehension, 9 vocabulary, 3 strategy transfer), sehingga total Minggu 12 adalah 60 soal.
- Setiap sesi: 10 target vocabulary cards, 4 NEW + 6 RECYCLED.
- Setiap soal pilihan ganda memiliki 4 opsi dan satu jawaban terbaik.

## 2. Peta kompetensi

| Minggu | Kompetensi | Kinerja yang diukur | Bukti |
|---:|---|---|---|
| 9 | Distractor analysis | Menolak opsi yang salah target, bertentangan, tidak relevan, sebagian benar, atau tidak didukung | Perbandingan opsi dan kalimat bukti |
| 10 | Micro-grammar | Menafsirkan connector, negation, condition, dan modalitas | Kata penanda dan hubungan antarbagian |
| 11 | Integrated reading | Menggabungkan detail dan memeriksa konsistensi lintas teks | Bukti dari lebih dari satu bagian/teks |
| 12 | Mixed practice | Memilih strategi, memeriksa bukti, dan mengelola waktu | Proses pemilihan strategi dan refleksi |

## 3. Komposisi kesulitan

| Sesi | Easy | Developing | Medium | Total |
|---|---:|---:|---:|---:|
| W9 Online 01 | 4 | 5 | 3 | 12 |
| W9 Online 02 | 3 | 5 | 4 | 12 |
| W10 Online 01 | 3 | 4 | 5 | 12 |
| W10 Online 02 | 3 | 4 | 5 | 12 |
| W11 Online 01 | 2 | 5 | 5 | 12 |
| W11 Online 02 | 2 | 4 | 6 | 12 |
| W12 Online 01 | 5 | 10 | 15 | 30 |
| W12 Online 02 | 3 | 10 | 17 | 30 |
| **Total** | **25** | **47** | **60** | **132** |

Label easy, developing, dan medium adalah estimasi desain internal FRTS. Label tersebut belum dikalibrasi melalui data respons siswa dan bukan sertifikasi CEFR.

## 4. Variasi stimulus

Total stimulus dalam bank soal: 22. Sesi W9–W11 masing-masing memiliki dua stimulus; setiap sesi W12 memiliki lima stimulus setelah perluasan menjadi 30 soal. Jenis bacaan mencakup:
- notice dan announcement;
- informational article/report;
- programme dan schedule;
- paired messages;
- review/instructional notice.

Topik mencakup sekolah, komunitas, kebun, perpustakaan, pameran, kunjungan belajar, dan sumber belajar. Nama tokoh, jadwal, angka, dan skenario khusus adalah fiktif; fakta umum yang digunakan sebagai konteks mengikuti daftar sumber pada Part E.

---

# PART E — REFERENSI DAN CATATAN DESAIN

Tanggal akses: 15 November 2026.

1. **Institute of Education Sciences / What Works Clearinghouse (2022).** *Providing Reading Interventions for Students in Grades 4–9.*  
   https://ies.ed.gov/ncee/wwc/PracticeGuide/29  
   Penggunaan: strategi pemahaman, pertanyaan, pemodelan eksplisit, gist, dan pemantauan pemahaman.

2. **Education Endowment Foundation (2018).** *Improving Literacy in Secondary Schools.*  
   https://educationendowmentfoundation.org.uk/education-evidence/guidance-reports/Literacy-ks3-ks4  
   Penggunaan: literasi sekolah menengah, pengajaran kosakata, teks kompleks, pemodelan dan latihan bertahap.

3. **Cambridge English.** *B1 Preliminary for Schools — Exam Format.*  
   https://www.cambridgeenglish.org/exams-and-tests/qualifications/preliminary/format/  
   Penggunaan: inspirasi variasi teks dan format latihan membaca. FRTS bukan ujian Cambridge.

4. **National Assessment of Educational Progress (NAEP).** *Reading Assessment Framework.*  
   https://www.nationsreportcard.gov/reading/about/framework/  
   Penggunaan: membedakan locate/recall, integrate/interpret, dan critique/evaluate; variasi teks literary dan informational. Bukan blueprint resmi Indonesia.

5. **British Council LearnEnglish.** *Modal Verbs.*  
   https://learnenglish.britishcouncil.org/free-resources/grammar/english-grammar-reference/modal-verbs  
   Penggunaan: makna kemungkinan/kepastian, izin, kemampuan, dan kewajiban.

6. **British Council LearnEnglish.** *Modals: Permission and Obligation.*  
   https://learnenglish.britishcouncil.org/free-resources/grammar/b1-b2/modals-permission-obligation  
   Penggunaan: perbedaan permission, prohibition, obligation, dan no obligation.

7. **British Council LearnEnglish.** *Questions and Negatives.*  
   https://learnenglish.britishcouncil.org/free-resources/grammar/english-grammar-reference/questions-negatives  
   Penggunaan: bentuk negatif dan fungsi not dalam kalimat.

8. **British Council LearnEnglish Teens.** *Conjunctions: and, or, but, so, because and although.*  
   https://learnenglishteens.britishcouncil.org/grammar/a1-a2-grammar/conjunctions-or-so-because-although  
   Penggunaan: hubungan penambahan, alternatif, sebab, hasil, dan kontras.

9. **Rajiv Jhangiani, Kwantlen Polytechnic University (n.d.; accessed 15 November 2026).** *Guidelines for Writing Effective Distractors for Multiple-Choice Questions.*  
   https://www.kpu.ca/sites/default/files/Teaching%20and%20Learning/Guidelines-for-writing-effective-distractors-for-multiple-choice-questions.pdf  
   Penggunaan: distractor masuk akal, panjang opsi relatif seimbang, tidak tumpang tindih, dan konsisten secara tata bahasa.

10. **Kim & Webb (2022).** *The Effects of Spaced Practice on Second Language Learning: A Meta-Analysis.*  
   https://doi.org/10.1111/lang.12479  
   Penggunaan: dasar umum pengulangan kosakata secara berjarak.

11. **Nakata, Tada, McLean, & Kim (2021).** *Effects of Distributed Retrieval Practice Over a Semester: Cumulative Tests as a Way to Facilitate Second Language Vocabulary Learning.*  
    https://doi.org/10.1002/tesq.596  
    Penggunaan: dasar kuis kosakata kumulatif. Penelitian dilakukan pada mahasiswa Jepang, sehingga penerapannya pada siswa SMP Indonesia perlu diuji.

12. **OECD.** *PISA 2018 Reading Framework.*  
    https://www.oecd.org/en/publications/pisa-2018-assessment-and-analytical-framework_b25efab8-en/full-report/component-3.html  
    Penggunaan: konteks integrasi dan evaluasi informasi lintas teks. Halaman penuh mengalami timeout; hanya ringkasan hasil pencarian yang dapat diperiksa.

13. **Gierl, M. J., Bulut, O., Guo, Q., & Zhang, X. (2017).** *Developing, Analyzing, and Using Distractors for Multiple-Choice Tests in Education: A Comprehensive Review.*  
    https://doi.org/10.3102/0034654317726529  
    Penggunaan: tinjauan pengembangan dan analisis distractor. Metadata/abstrak dapat diperiksa; teks lengkap tidak berhasil dibuka.

14. **Raina, V., Liusie, A., & Gales, M. (2023).** *Assessing Distractors in Multiple-Choice Tests.* Proceedings of the 4th Workshop on Evaluation and Comparison of NLP Systems, 12–22.  
    https://aclanthology.org/2023.eval4nlp-1.2/  
    Penggunaan: kualitas distractor dilihat dari incorrectness, plausibility, dan diversity. PDF prosiding dibaca penuh; metode otomatis tidak menggantikan review guru.

### Batas klaim

- Referensi mendukung prinsip pengajaran/asesmen membaca, tetapi tidak membuktikan bahwa urutan W1–W19 FRTS adalah satu-satunya urutan yang paling efektif.
- Cambridge B1 digunakan sebagai inspirasi variasi stimulus, bukan klaim bahwa semua teks FRTS adalah B1.
- Label kesulitan harus diperiksa melalui review guru dan pilot siswa.
- Micro-grammar berfokus pada petunjuk makna dalam bacaan; bukan silabus grammar lengkap.

---

# PART F — ISSUE LOG DAN QA v0.3

| ID | Prioritas | Isu / temuan | Status setelah revisi |
|---|---|---|---|
| B3-ISS-01 | HIGH | Tingkat kesulitan bacaan belum dikalibrasi pada siswa kelas 7–9 | OPEN — pilot siswa diperlukan |
| B3-ISS-02 | HIGH | Kualitas distractor memerlukan penilaian guru, terutama opsi yang hanya sebagian benar atau terlalu mudah dieliminasi | REVISED — distractor/rationale diperbaiki pada item yang ditemukan bermasalah; review guru tetap wajib |
| B3-ISS-03 | MEDIUM | Micro-grammar harus tetap menjadi petunjuk membaca, bukan ujian grammar luas | CONTROLLED — cakupan dipertahankan; review guru tetap diperlukan |
| B3-ISS-04 | HIGH | Soal integrasi lintas teks harus memakai bukti dari seluruh teks yang diperlukan | REVISED — stimulus reference dan bukti lintas teks diperiksa; perlu review guru independen |
| B3-ISS-05 | MEDIUM | W12 adalah transisi mixed practice, bukan simulasi ujian penuh | PASS — batas klaim dipertahankan |
| B3-ISS-06 | MEDIUM | Vocabulary register harus 10 kartu/sesi, 4 NEW + 6 RECYCLED | PASS secara kuantitas; verifikasi historis seluruh RECYCLED dari Batch 2 belum dapat diselesaikan karena bank Batch 2 tidak disertakan dalam ZIP ini |
| B3-ISS-07 | HIGH | Teacher-only payload memerlukan pengamanan server-side dalam aplikasi | OPEN — endpoint dan role check aplikasi belum diuji |
| B3-ISS-08 | MEDIUM | Stimulus memerlukan copy-edit, konsistensi panjang, dan kecukupan bukti | REVISED — pengulangan kalimat di W11S1-T1 dihapus; word_count seluruh 22 stimulus dihitung ulang |
| B3-ISS-09 | MEDIUM | W9–W11 dalam paket ini hanya 12 soal/sesi, sedangkan Master Development Plan menargetkan 25 soal/sesi pada Weeks 1–11 | OPEN SCOPE GAP — jumlah dipertahankan sesuai prompt paket; jangan klaim W9–W11 memenuhi target produksi penuh |
| B3-ISS-10 | MEDIUM | Master Development Plan meminta lima soal penguatan untuk setiap penjelasan/lesson section; modul ini menyediakan pemeriksaan mandiri lima soal per minggu | OPEN SCOPE GAP — perlu penambahan soal penguatan per bagian pada siklus modul berikutnya |
| B3-ISS-11 | HIGH | Bank belum diuji pada siswa dan belum memiliki analisis item empiris | OPEN — status tetap PARTIAL/DRAFT |

### QA struktural dan semantik v0.3

- 8 sesi dan 132 soal: tersedia.
- W9–W11: 12 soal/sesi; role 7 reading comprehension + 4 vocabulary + 1 strategy transfer.
- W12: 30 soal/sesi; role 18 reading comprehension + 9 vocabulary + 3 strategy transfer.
- 22 stimulus: seluruh referensi stimulus terhubung ke item yang valid.
- 10 target vocabulary cards/sesi: 4 NEW + 6 RECYCLED; `new_ratio = 0.40`.
- Difficulty distribution: cocok dengan target yang ditentukan dalam prompt.
- Answer-key positions: 33 A, 33 B, 33 C, 33 D setelah pengacakan ulang opsi.
- Student Payload: dibangun ulang tanpa teacher fields.
- Teacher Payload dan Teacher Answer Guide: dibangun ulang dari Master Bank.
- JSON: parse dan duplicate-key check lulus.
- ID Master/Student/Teacher: cocok 132/132.
- Word count: dihitung ulang dari teks stimulus.
- Teacher rationale: setiap item memiliki empat rationale berbahasa Indonesia; rationale generik yang tidak membedakan opsi diperbaiki.
- Validasi historis RECYCLED terhadap Batch 2: belum tuntas karena file Master Bank Batch 2 tidak termasuk paket sumber yang tersedia untuk audit ini.
- Pilot siswa, psychometric calibration, API/security integration: belum dilakukan.

**Status akhir: PARTIAL — REVISED DRAFT / OWNER REVIEW. NOT CLASSROOM VALIDATED; NOT PRODUCTION-READY.**

Catatan cakupan: jumlah 12 soal per sesi pada W9–W11 merupakan versi ringkas dalam paket ini; belum memenuhi target program 25 soal per sesi. Week 12 berisi 60 soal sesuai target fase latihan (30 + 30), dan bukan simulasi ujian penuh.

# PART G — REVISION HISTORY

| Versi | Tanggal | Perubahan |
|---|---|---|
| 0.1 | 15 November 2026 | Initial integrated production draft W9–W12. |
| 0.2 | 15 November 2026 | Penambahan Week 12 menjadi 60 soal online (30+30); 18 reading, 9 vocabulary, 3 strategy transfer per sesi; W12 tetap fase mixed practice tanpa strategi membaca baru. |
| 0.3 | 15 November 2026 | Koreksi salah salin tujuan Week 10; audit dan pembaruan daftar referensi/akses; penguatan issue log, cakupan kuantitas, dan status owner review. Modul diselaraskan dengan Master Question Bank v0.3. |
