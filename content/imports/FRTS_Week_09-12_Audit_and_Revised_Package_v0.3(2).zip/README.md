# FRTS Batch 3 — Weeks 9–12 | Audit and Revised Package v0.3

**Status:** PARTIAL — Revised Draft / Owner Review  
**Not classroom validated. Not psychometrically calibrated. Not production-ready.**

## Package contents

1. `FRTS_Master_Development_Plan_v1.3.1.md` — unchanged control document.
2. `01_FRTS_Batch_03_Weeks_09-12_Module_v0.3.md` — corrected module.
3. `02_FRTS_Batch_03_Interactive_Question_Bank_v0.3.json` — canonical revised bank.
4. `03_FRTS_Batch_03_Student_Payload_v0.3.json` — learner-safe payload rebuilt from Master Bank.
5. `04_FRTS_Batch_03_Teacher_Answer_Payload_v0.3.json` — teacher-only answers rebuilt from Master Bank.
6. `05_FRTS_Batch_03_Teacher_Answer_Guide_v0.3.md` — 132 answer explanations and rationales.
7. `06_FRTS_Batch_03_Audit_Report_v0.3.md` — findings, research, corrections, and post-revision QA.

## Final structural counts

- 8 sessions, 132 questions, 22 stimuli.
- W9–W11: 12 questions per session; 7 reading comprehension + 4 vocabulary + 1 strategy transfer.
- W12: 30 questions per session; 18 reading comprehension + 9 vocabulary + 3 strategy transfer.
- 80 vocabulary cards: 10 per session, exactly 4 NEW + 6 RECYCLED.
- 32 unique NEW vocabulary terms.
- Answer-key positions: 33 A, 33 B, 33 C, 33 D.
- Student/Teacher/Master IDs match 132/132.
- Student payload has no teacher answer/explanation/evidence/rationale fields.
- 528 option rationales are present.
- All 22 stimulus word counts recalculated.

## Important open items

1. Teacher Answer Payload must be served only through authenticated server-side teacher authorization; application endpoints were not part of this audit.
2. Student pilot and empirical item analysis remain necessary.
3. Historical verification of all 48 RECYCLED terms requires the Batch 2 Master Bank, which was not included in the ZIP audited here.
4. W9–W11 remain 12 questions per session in this compact package, below the Master Plan's 25-question target.
5. The module needs five reinforcement questions for each major explanation/lesson section; current self-checks are five per week.

## Authority and data flow

Master Development Plan v1.3.1 remains unchanged. Module v0.3 defines taught content and boundaries. Master Question Bank v0.3 is the single source of truth. Student Payload and Teacher Payload are rebuilt from it; Teacher Answer Guide is also generated from the same master data.

Do not change question IDs or counts without owner approval.
