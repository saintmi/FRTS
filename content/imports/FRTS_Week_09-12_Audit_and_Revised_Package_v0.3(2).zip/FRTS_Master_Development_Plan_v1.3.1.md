# FRTS English Exam Preparation
## Master Development Plan — Revision 1.3.1

**Document ID:** FRTS-MDP-001  
**Version:** 1.3.1  
**Status:** Working baseline with bilingual standard and practice-phase quantitative targets updated  
**Program duration:** 19 weeks  
**Delivery rhythm:** 1 offline meeting + 2 online interactive sessions per week  
**Content owner:** ChatGPT in the curriculum/module conversation  
**Application owner:** Separate ChatGPT Project / other LLM

---

# 1. Purpose

This plan controls the design, production, validation, and handoff of FRTS learning content. The learning content is produced here. Application architecture and implementation are owned by a separate LLM/project and must be based on mature, documented content rather than assumptions.

FRTS develops English reading comprehension and text-analysis skills for SMP students through explicit reading strategies, contextual vocabulary, paraphrase recognition, reference tracking, inference, evidence checking, distractor elimination, and supporting micro-grammar.

This is a general school-exam and long-term academic reading preparation program. It must not be described as an official TKA English SMP blueprint unless a relevant official specification is confirmed.

# 2. Agreed Program Rules

- [x] One common learning path for all students.
- [x] No placement pre-test and no level-based grouping.
- [x] All students follow the same weekly sequence and target completion date.
- [x] One offline teaching/coaching meeting each week.
- [x] Two online interactive exercise sessions each week.
- [x] Offline introduces and demonstrates techniques and discusses difficult questions.
- [x] Online exercises reinforce only material already introduced in the module/offline meeting.
- [x] Vocabulary is taught in context: Indonesian meaning, example, useful synonyms/antonyms, word families, and paraphrase.
- [x] Grammar is limited to micro-grammar that supports reading analysis.
- [x] Weeks 12–19 focus on mixed practice, simulation, review, and error analysis.
- [x] Content is produced here; the separate application LLM owns application design and implementation.


## 2A. Mandatory Bilingual Standard for Every Student Module

**This is a program-wide content standard for Weeks 1–19. It applies to every new module and every revision of an existing module. A student module must not be written entirely in English.** The target learners must be able to study independently without English-language explanations becoming an unnecessary barrier.

### Language allocation

| Module component | Required language treatment |
|---|---|
| Learning objectives and study directions | Bahasa Indonesia; retain key English terms in parentheses where useful |
| Concept explanations and strategy instructions | Bahasa Indonesia as the primary explanatory language |
| English technical terms | Show the English term, then explain its meaning in Bahasa Indonesia at first use |
| Reading passages, dialogue, notices, examples, and model sentences | English, with selective Indonesian glosses only when needed for learning |
| Worked examples and text analysis | Explain in Bahasa Indonesia; quote the relevant English words/sentences as evidence |
| Vocabulary banks | English headword + Indonesian meaning + contextual example; useful synonym/antonym/word family where appropriate |
| Questions and answer choices | English when testing English reading comprehension; instructions may be in Bahasa Indonesia |
| Answer keys and explanations | Bahasa Indonesia, supported by exact English textual evidence and explanation of distractors where relevant |
| Recap, checklist, and independent-study guidance | Bahasa Indonesia, with English labels retained when they are part of a named strategy |

### Bilingual writing rules

1. Explain the *how* and *why* in clear, age-appropriate Bahasa Indonesia; use English for the language being learned or assessed.
2. Do not translate every sentence of every passage. Teach students to infer meaning from context and return to the text for evidence.
3. At first use, explain technical terms such as *topic, main idea, purpose, inference, reference, scanning,* and *skimming* in Indonesian. Thereafter, use the English term consistently with occasional reminders.
4. When presenting a model sentence, give its Indonesian meaning if that meaning is necessary to understand the lesson. Do not make word-for-word translation the default reading method.
5. Keep question stems and options in English when the learning objective is to read and interpret English questions. Explain unfamiliar task words in Indonesian before independent practice.
6. Avoid unnecessarily complex Indonesian. Use direct explanations, short steps, worked examples, and explicit reasoning.
7. Do not assume that a student understands an English grammar label merely because it appears in the module; explain the function in Indonesian.
8. Every worked answer must identify the textual evidence and explain in Indonesian why it supports the answer. For multiple choice, explain why plausible distractors are wrong when the item requires that analysis.
9. English exposure must remain substantial: passages, model sentences, key vocabulary, and assessed reading tasks remain in English. Bilingual support is a scaffold, not a replacement for English reading practice.
10. Apply this standard consistently to student modules. Teacher guides may use professional Indonesian with English examples; online question banks should keep the assessed stimulus and questions in English, with Indonesian feedback/explanations as appropriate.

### Mandatory bilingual QA gate

A module cannot be marked READY/VALIDATED unless:
- [ ] Explanations and independent-study instructions are primarily in Bahasa Indonesia.
- [ ] Key English terminology is explained in Bahasa Indonesia at first use.
- [ ] English passages and assessed reading tasks remain in English.
- [ ] Worked examples connect English evidence to Indonesian reasoning.
- [ ] Answer explanations are understandable to an SMP learner studying independently.
- [ ] No long instructional section is left entirely in English without a clear pedagogical reason.

# 3. Mandatory Production Packaging

**Every week is produced as one coordinated production package containing two separate student-facing/teaching artifacts.** Both documents are authored in the same production cycle so that they remain aligned.

## Document A — Student Learning Module

Purpose: teach and explain the weekly material.

Required contents:
1. Weekly title, learning outcomes, and connection to previous learning.
2. Student-friendly explanations in Indonesian, with English examples.
3. Step-by-step strategy or method.
4. Worked examples with reasoning.
5. Common mistakes and reminders.
6. Vocabulary coverage relevant to the week.
7. **Exactly five short reinforcement questions for each major explanation/lesson section**, with answers and brief explanations.
8. Weekly summary and quick checklist.

The five reinforcement questions are for checking understanding of the explanation. They are not the main online exercise bank and must not be counted toward the planned online question totals.

## Document B — Online Interactive Exercise Blueprint and Question Set

Purpose: provide the two main weekly online practice sessions.

Required contents:
1. Week, session, module links, learning outcomes, skill tags, and question counts.
2. Passage(s) with stable passage IDs.
3. Session 1 questions and Session 2 questions.
4. Answer options and correct answers.
5. Explanation of the correct answer.
6. Textual evidence or linguistic evidence.
7. Explanation of distractors.
8. Vocabulary tags where relevant.
9. Content metadata and validation checklist.

The online question set must be distinct from the module's five-per-explanation reinforcement questions. It may revisit the same learning outcome but should use different items, passages, and reasoning contexts.

## Offline teaching guide

The offline guide is a separate teacher-facing artifact, produced alongside the weekly package or as part of the same production batch. It contains a teaching sequence, demonstration, guided practice, discussion prompts, difficult questions, and links to the exact module sections and online sessions.

## Same-cycle rule

For each week, produce:
- [ ] Student Module.
- [ ] Offline Teaching Guide.
- [ ] Vocabulary list/bank entries.
- [ ] Online Session 1 blueprint and questions.
- [ ] Online Session 2 blueprint and questions.
- [ ] Answer key and explanations.
- [ ] Cross-document alignment check.

Do not complete the module in isolation and postpone the online question design to a later, disconnected phase. The module and online exercises are created together, but remain separate documents.

# 4. Program Structure

| Phase | Weeks | Focus |
|---|---:|---|
| Foundation & Reading Techniques | 1–11 | Teach essential reading and analysis techniques |
| Simulation & Mastery | 12–19 | Mixed practice, timed work, simulations, and error analysis |

Weekly rhythm:
- Offline: technique explanation, modeling, guided practice, difficult-question discussion.
- Online Session 1: focused practice of the current week's technique.
- Online Session 2: application through passages and mixed questions using current and previously taught techniques.

## 4A. Practice-Only Phase Standard — Weeks 12–19

**Mulai Minggu 12, siswa tidak menerima bab teori atau strategi membaca utama yang baru.** Semua strategi inti telah diperkenalkan pada Minggu 1–11. Minggu 12–19 digunakan untuk menerapkan, mengulang, menggabungkan, dan mengukur penggunaan strategi tersebut melalui latihan soal.

Ketentuan operasional:
- Offline meeting: review soal yang sulit, pembahasan kesalahan kelas, pemodelan ulang strategi yang sudah dipelajari, dan refleksi; bukan pengajaran teknik baru.
- Online sessions: lebih banyak soal dan stimulus campuran, dengan tingkat kesulitan bertahap.
- Vocabulary: pengayaan kosakata tetap berjalan melalui bacaan dan konteks soal. Setiap sesi online memiliki 10 target vocabulary cards dengan minimal 4 NEW (40%) dan sisanya RECYCLED. Ini merupakan pengayaan kosakata kontekstual, bukan penambahan bab teori/strategi membaca.
- Semua kosakata lama tetap muncul kembali secara kumulatif. Sinonim, antonim, word family, dan parafrasa hanya diuji sesuai materi yang telah diajarkan.
- Gunakan hasil latihan untuk menentukan pembahasan remedial tingkat kelas; jangan membuat jalur kurikulum atau pengelompokan kemampuan baru.

### Quantitative practice target

| Periode | Online Session 1 | Online Session 2 | Total per minggu |
|---|---:|---:|---:|
| Weeks 1–11 | 25 | 25 | 50 |
| Weeks 12–15 | 30 | 30 | 60 |
| Weeks 16–19 | 25 | 40 | 65 |

**Week 12 is the transition into the practice-heavy phase and therefore starts at 60 questions (30 + 30), not 50 or 55.** Weeks 13–15 retain 60 questions per week. Weeks 16–19 retain 65 questions per week, including a 40-question full simulation in Session 2.

### Revised online question total

- Weeks 1–11: 11 × 50 = 550 questions.
- Weeks 12–15: 4 × 60 = 240 questions.
- Weeks 16–19: 4 × 65 = 260 questions.
- **Revised total: 1,050 online questions across 19 weeks.**

The module's reinforcement questions are additional and are not counted in these online totals.

# 5. Weekly Curriculum Summary

| Week | Main topic | Core vocabulary/relations | Offline focus | Online Session 1 | Online Session 2 |
|---:|---|---|---|---|---|
| 1 | Reading foundation and text types | people, places, activities, time, information; useful basic synonym/antonym pairs | Text preview, text type, topic, purpose, gist/detail | 25 questions: text type, topic, purpose, explicit information, contextual vocabulary | 25 questions: short passages, skimming, scanning, important information |
| 2 | Question-first reading | ask, answer, explain, mention, reason, purpose; reason/cause, answer/response | Understand what each question asks | 25 questions: question intent and classification | 25 questions: question-to-evidence |
| 3 | Keyword recognition and scanning | date, schedule, price, amount, location; cost/price, purchase/buy | Anchor words and explicit details | 25 scanning drills | 25 functional-text questions |
| 4 | Synonyms, antonyms, paraphrase | improve, reduce, increase, protect, choose; contextual synonym/antonym | Meaning matching, paraphrase, word families | 25 vocabulary relationship questions | 25 paraphrase-in-passage questions |
| 5 | Skimming and main idea | topic, main, overall, purpose, focus; main/primary | Topic, main idea, paragraph gist | 25 topic/main idea/title questions | 25 paragraph mapping questions |
| 6 | Context clues | although, however, because, therefore, including; contrast/cause connectors | Definition, example, synonym, contrast, cause/effect clues | 25 clue-type questions | 25 meaning-in-passage questions |
| 7 | Reference tracking | refer, previous, following, subject, object | Pronouns, demonstratives, antecedents | 25 reference identification | 25 reference-in-reading |
| 8 | Inference and evidence | suggest, imply, indicate, likely, evidence, conclude | Explicit vs implicit, evidence-supported inference | 25 basic inference questions | 25 evidence-based inference questions |
| 9 | Distractor elimination | correct, incorrect, except, relevant, supported, incomplete | Half-correct, irrelevant, broad/narrow, not mentioned | 25 option-analysis questions | 25 distractor challenge questions |
| 10 | Micro-grammar for reading | action, event, usually, previously, result, condition | Sentence roles, basic tenses, conjunctions, passive, relative clauses | 25 grammar-for-meaning questions | 25 grammar-in-reading questions |
| 11 | Integrated reading techniques | compare, contrast, report, narrate, persuade, instruct | FAST and SMART CHECK integration | 25 integrated-skill questions | 25 mixed reading questions |
| 12 | Simulation by text type | review vocabulary from varied passages | Compare text types and choose strategies; no new major reading technique | 30 text-type practice | 30 mixed-text questions |
| 13 | Simulation by question type | according to, refer to, imply, purpose, except | Choose strategies by question type; practice and review only | 30 question-type drills | 30 question-combination questions |
| 14 | Mixed reading and paraphrase | develop, affect, influence, benefit, achieve, maintain | Apply previously taught paraphrase and contextual meaning; no new reading technique | 30 paraphrase-intensive questions | 30 mixed reading questions |
| 15 | Timed reading and accuracy | priority, manage, complete, review, verify, accurate | Time management and strategic rereading using W1–W11 techniques | 30 timed skill drills | 30 timed mixed questions |
| 16 | Full Simulation 1 | 10–15 selected words from passages/errors | Review difficult questions and error patterns | 25 targeted practice | 40-question full simulation |
| 17 | Full Simulation 2 and advanced analysis | attitude, perspective, intention, consequence, evidence | Paragraph relationships, purpose, attitude | 25 advanced analysis | 40-question full simulation |
| 18 | Full Simulation 3 and consistency | 10–15 selected words from passages/errors | Recurring errors and independent strategy use | 25 consistency practice | 40-question full simulation |
| 19 | Final simulation and consolidation | cumulative vocabulary review | Final strategy review and independent reading | 25 final review questions | 40-question final simulation |

# 6. Weekly Quantitative Targets

| Weeks | Module reinforcement | Online Session 1 | Online Session 2 | Online total |
|---|---|---:|---:|---:|
| 1–11 | 5 questions per major explanation section | 25 | 25 | 50/week |
| 12–15 | 5 questions per review/explanation section where applicable | 30 | 30 | 60/week |
| 16–19 | 5 questions per review/explanation section where applicable | 25 | 40 | 65/week |

Online production total:
- Weeks 1–11: 550 questions.
- Weeks 12–15: 240 questions.
- Weeks 16–19: 260 questions.
- **Total online target: 1,050 questions.**

Module reinforcement questions are additional and are not included in the 1,050 online questions.

# 7. Week 1 Production Benchmark

Week 1 is the first complete production package and the quality benchmark for later weeks.

Required artifacts:
- `FRTS_W01_Student_Module.md`
- `FRTS_W01_Offline_Teaching_Guide.md`
- `FRTS_W01_Online_Exercises.md`
- `FRTS_W01_Vocabulary_Bank.csv` or a vocabulary section in the module until the bank is consolidated
- `FRTS_W01_Content_QA.md`

Week 1 module explanations should cover:
1. What reading comprehension means and why word-for-word translation is not always needed.
2. Text types and how to identify them using purpose, structure, and language features. At minimum: descriptive, recount, narrative, procedure, report, explanation, and short functional texts (announcement, notice, invitation, advertisement, schedule, message/email/letter).
3. Contrastive genre analysis: descriptive vs report; recount vs narrative; procedure vs explanation; announcement vs notice. Do not teach simplistic single-feature rules (for example, exact time expression always means recount).
4. Topic, main idea, and purpose.
5. Skimming for general understanding.
6. Scanning for specific information.

Each of these five explanation sections has five reinforcement questions with answers and brief explanations.

The separate online exercise document contains:
- Session 1: 25 questions.
- Session 2: 25 questions.
- Different passages/items from the module reinforcement set.
- Answer key, explanation, textual evidence, and distractor analysis.

# 8. Content Identifiers and Application Handoff

Suggested stable identifiers:
- Week: `W01` … `W19`
- Module: `MOD-W01`
- Offline guide: `OFF-W01`
- Online exercise: `EX-W01-S1`, `EX-W01-S2`
- Passage: `PASS-W01-001`
- Question: `Q-W01-S1-001`
- Vocabulary: `VOC-000001`
- Learning outcome: `LO-W01-01`

The application LLM owns:
- application architecture and implementation;
- user/account flows;
- content ingestion and storage;
- exercise rendering and navigation;
- scoring and progress reporting;
- security, deployment, and operations.

The content owner owns:
- curriculum and learning outcomes;
- student module;
- offline guide;
- vocabulary and passage banks;
- exercise blueprints;
- questions, keys, explanations, and evidence;
- content QA, versioning, and change log.

The application LLM must not invent educational content or alter approved answer keys. It may propose a technical data model, but the model must preserve content IDs, week/session links, skill tags, passage links, correct answers, explanations, evidence, and content status.

# 9. Production Workflow

For each week, use this same-cycle workflow:

1. Confirm the weekly scope against the Master Curriculum Map.
2. Write the student explanations and worked examples.
3. Add five reinforcement questions per major explanation, with answers.
4. Prepare the vocabulary coverage.
5. Write the offline teaching guide aligned to the exact module sections.
6. Create Online Session 1 blueprint and questions.
7. Create Online Session 2 blueprint and questions.
8. Validate keys, explanations, evidence, distractors, age suitability, and taught-content alignment.
9. Cross-check all artifacts and assign versions/status.
10. Mark the weekly package complete only after all required artifacts pass QA.

# 10. Definition of Done

A weekly package is `VALIDATED` only when:

- [ ] Student module is complete and reviewed.
- [ ] Every major explanation section has exactly five reinforcement questions.
- [ ] Reinforcement questions have answers and brief explanations.
- [ ] Offline teaching guide links to module sections.
- [ ] Vocabulary coverage is documented and context-checked.
- [ ] Online Session 1 has the planned number of distinct questions.
- [ ] Online Session 2 has the planned number of distinct questions.
- [ ] Online questions are separate from module reinforcement questions.
- [ ] Every online question has a correct answer and explanation.
- [ ] Reading questions have textual evidence.
- [ ] Distractors have been checked for ambiguity.
- [ ] No online question requires an untaught technique.
- [ ] IDs, week/session links, version, and status are present.
- [ ] Cross-document alignment review is passed.

Statuses:
- `NOT STARTED`
- `DRAFT`
- `IN REVIEW`
- `REVISION REQUIRED`
- `VALIDATED`
- `PUBLISHED`

Do not mark an artifact `VALIDATED` or `PUBLISHED` without review evidence.

# 11. Progress Tracker

| Stage | Deliverable | Status |
|---|---|---|
| 0 | Working baseline | AGREED |
| 1 | Master Curriculum Map | DRAFT |
| 2 | Production templates | NOT STARTED |
| 3 | Week 1 student module | IN PROGRESS |
| 4 | Week 1 offline guide | IN PROGRESS |
| 5 | Week 1 online exercises (50 questions) | IN PROGRESS |
| 6 | Week 1 QA and benchmark approval | NOT STARTED |
| 7 | Weeks 2–11 packages | NOT STARTED |
| 8 | Weeks 12–19 simulation packages | NOT STARTED |
| 9 | Application handoff package | NOT STARTED |
| 10 | Full content QA and pilot readiness | NOT STARTED |

# 12. Immediate Next Action

Produce the complete Week 1 package in one coordinated production cycle:
1. Student Module with five explanation sections and five reinforcement questions per section.
2. Separate Online Exercises document with 25 Session 1 questions and 25 Session 2 questions.
3. Offline Teaching Guide.
4. Vocabulary coverage.
5. Cross-document QA checklist.

After Week 1 is reviewed and approved, freeze its templates and use them for Weeks 2–19.

---

**End of FRTS-MDP-001 Revision 1.2**


# Revision 1.3.1 — Change Log

**Date:** 15 November 2026

1. Formally establishes Weeks 12–19 as a practice-only/simulation phase: no new major reading techniques or theory chapters after Week 11.
2. Increases Weeks 12–15 from 55 to 60 online questions per week: 30 in each session. This makes Week 12 the first 60-question week.
3. Retains Weeks 16–19 at 65 questions per week: 25 targeted practice + 40-question full simulation.
4. Revises the overall online question target from 1,030 to 1,050: 550 (W1–11) + 240 (W12–15) + 260 (W16–19).
5. Clarifies that vocabulary enrichment continues during the practice phase through contextual passages: each session has 10 target vocabulary cards, at least 4 NEW (40%) and the remainder RECYCLED. This is not a new reading-technique/theory unit.
6. Preserves one shared learning path and the 60-minute offline meeting; teachers revisit existing strategies and class-level errors rather than introduce new techniques.

**This revision is based on the supplied FRTS_Master_Development_Plan_v1.3.md. The original v1.3 file is preserved unchanged.**
