# FRTS Batch 3 — Teacher Answer Guide
## Weeks 9–12 | 132 Questions | Version 0.3

**Status:** PARTIAL — revised draft for owner review; not classroom validated.

**Akses:** Dokumen ini berisi kunci dan pembahasan. Jangan unggah atau sajikan kepada siswa.

**Prinsip:** Stem dan opsi berbahasa Inggris; penjelasan guru berbahasa Indonesia. Setiap jawaban harus didukung oleh kutipan yang tepat dari stimulus terkait.

**Catatan lintas stimulus:** Jika item memiliki `additional_stimulus_ids`, gunakan stimulus utama dan seluruh stimulus tambahan sebagai satu set bukti.

## Ringkasan struktur

- 8 sesi; 132 soal.
- W9–W11: 12 soal/sesi (7 reading comprehension, 4 vocabulary, 1 strategy transfer).
- W12: 30 soal/sesi (18 reading comprehension, 9 vocabulary, 3 strategy transfer).
- Posisi kunci: 33 A, 33 B, 33 C, 33 D.
- Setiap sesi: 10 vocabulary cards (4 NEW + 6 RECYCLED).

# W9-ONLINE-01 — Distractor Analysis: Checking Options Against Evidence
**Week:** 9 · **Questions:** 12 · **Difficulty:** Easy 4 / Developing 5 / Medium 3

## Stimuli

### W9S1-T1 — Choosing the Best Notice (Notice / functional text; 71 words)

```text
GREEN CAMPUS DAY
Saturday, 21 November
Time: 8:00 a.m.–11:30 a.m.
Place: School Hall and Garden
Visitors may join a short recycling game, view student posters, and learn how to separate paper, plastic, and food waste. Please bring a reusable bottle. Registration is free. The gardening demonstration starts at 9:15 a.m. The poster display remains open until 11:30 a.m. Students who need help finding the hall can ask at the main gate.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W9S1-T2 — A Careful Reader Checks the Whole Message (Informational article; 129 words)

```text
When students answer questions about a notice, a familiar word can attract their attention even when it does not answer the question. For example, a notice may mention both the time a workshop begins and the time an exhibition closes. Choosing the first time you see can lead to an incorrect answer. A distractor is an answer choice designed to look possible but does not satisfy the question. A plausible option sounds reasonable at first, so readers need to check it against the full message. An option may contradict a stated fact, include only part of the information, or add a detail that the notice never gives. Readers eliminate an option only after checking the whole statement. A careful reader compares each option with the exact target before deciding.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **distractor** (noun; NEW) — pilihan jawaban pengecoh yang tampak mungkin tetapi tidak tepat. *Example:* A distractor may repeat a word from the passage. *Synonym/related:* plausible wrong option. *Contrast:* —.
- **plausible** (adjective; NEW) — masuk akal atau tampak mungkin. *Example:* A plausible choice still needs textual evidence. *Synonym/related:* reasonable, believable. *Contrast:* implausible.
- **contradict** (verb; NEW) — bertentangan dengan informasi atau pernyataan. *Example:* The final sentence may contradict the first claim. *Synonym/related:* conflict with, be inconsistent with. *Contrast:* agree with, support.
- **eliminate** (verb; NEW) — menghilangkan atau mencoret dari pilihan. *Example:* Readers eliminate options that do not answer the question. *Synonym/related:* remove, rule out. *Contrast:* keep, retain.
- **imply** (verb; RECYCLED) — menyiratkan; menyampaikan makna secara tidak langsung. *Example:* The final sentence may imply that the plan needs more time. *Synonym/related:* suggest, indicate indirectly. *Contrast:* state explicitly.
- **likely** (adjective/adverb; RECYCLED) — mungkin besar. *Example:* The result is likely to change. *Synonym/related:* probably, probable. *Contrast:* unlikely.
- **evidence** (noun; RECYCLED) — bukti. *Example:* The option needs evidence. *Synonym/related:* proof, support. *Contrast:* —.
- **specific** (adjective; RECYCLED) — khusus atau tertentu. *Example:* The question asks for a specific date. *Synonym/related:* particular, exact. *Contrast:* general.
- **reason** (noun; RECYCLED) — alasan. *Example:* Find the reason for the decision. *Synonym/related:* cause, explanation. *Contrast:* —.
- **detail** (noun; RECYCLED) — rincian. *Example:* One detail supports the main idea. *Synonym/related:* fact, specific point. *Contrast:* overview (contrast).

## Answer key and explanations

### W9S1-Q01 — explicit_detail (easy)
**Stimulus:** W9S1-T1

**Question:** Where will Green Campus Day take place?

- **A.** At the main gate only
- **B.** At the school hall and garden
- **C.** At the public library
- **D.** At the community centre

**Jawaban:** B. At the school hall and garden

**Pembahasan:** Label Place menyebut dua lokasi kegiatan. Opsi yang hanya menyebut gerbang atau lokasi lain tidak sesuai.

**Bukti teks:** “Place: School Hall and Garden”

**Alasan setiap opsi:**
- **A. At the main gate only** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At the main gate only”. Bukti yang menjawab pertanyaan adalah “Place: School Hall and Garden”, dan bukti itu mendukung “At the school hall and garden”, bukan opsi ini.
- **B. At the school hall and garden** — Benar. Label Place menyebut dua lokasi kegiatan. Opsi yang hanya menyebut gerbang atau lokasi lain tidak sesuai. Bukti teks: “Place: School Hall and Garden”
- **C. At the public library** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At the public library”. Bukti yang menjawab pertanyaan adalah “Place: School Hall and Garden”, dan bukti itu mendukung “At the school hall and garden”, bukan opsi ini.
- **D. At the community centre** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At the community centre”. Bukti yang menjawab pertanyaan adalah “Place: School Hall and Garden”, dan bukti itu mendukung “At the school hall and garden”, bukan opsi ini.

---

### W9S1-Q02 — explicit_detail (easy)
**Stimulus:** W9S1-T1

**Question:** What time does the gardening demonstration start?

- **A.** 8:00 a.m.
- **B.** 12:00 p.m.
- **C.** 11:30 a.m.
- **D.** 9:15 a.m.

**Jawaban:** D. 9:15 a.m.

**Pembahasan:** Teks secara khusus memberi waktu mulai demonstrasi kebun, yaitu 9:15 a.m. Jangan tertukar dengan waktu pembukaan atau penutupan acara.

**Bukti teks:** “The gardening demonstration starts at 9:15 a.m.”

**Alasan setiap opsi:**
- **A. 8:00 a.m.** — Tidak tepat. Detail “8:00 a.m.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “The gardening demonstration starts at 9:15 a.m.”, yang mendukung “9:15 a.m.”.
- **B. 12:00 p.m.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “12:00 p.m.”. Bukti yang menjawab pertanyaan adalah “The gardening demonstration starts at 9:15 a.m.”, dan bukti itu mendukung “9:15 a.m.”, bukan opsi ini.
- **C. 11:30 a.m.** — Tidak tepat. Detail “11:30 a.m.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “The gardening demonstration starts at 9:15 a.m.”, yang mendukung “9:15 a.m.”.
- **D. 9:15 a.m.** — Benar. Teks secara khusus memberi waktu mulai demonstrasi kebun, yaitu 9:15 a.m. Jangan tertukar dengan waktu pembukaan atau penutupan acara. Bukti teks: “The gardening demonstration starts at 9:15 a.m.”

---

### W9S1-Q03 — evidence_check (developing)
**Stimulus:** W9S1-T1

**Question:** Which statement is supported by the notice?

- **A.** The recycling game is held at the boat station.
- **B.** Visitors must pay to enter.
- **C.** The poster display ends before 9:00 a.m.
- **D.** Visitors are asked to bring a reusable bottle.

**Jawaban:** D. Visitors are asked to bring a reusable bottle.

**Pembahasan:** Pernyataan tentang botol yang dapat digunakan kembali dinyatakan langsung. Opsi lain bertentangan dengan informasi biaya dan jadwal atau menambahkan lokasi yang tidak disebut.

**Bukti teks:** “Please bring a reusable bottle. Registration is free.”

**Alasan setiap opsi:**
- **A. The recycling game is held at the boat station.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The recycling game is held at the boat station.”. Bukti yang menjawab pertanyaan adalah “Please bring a reusable bottle. Registration is free.”, dan bukti itu mendukung “Visitors are asked to bring a reusable bottle.”, bukan opsi ini.
- **B. Visitors must pay to enter.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Visitors must pay to enter.”. Bukti yang menjawab pertanyaan adalah “Please bring a reusable bottle. Registration is free.”, dan bukti itu mendukung “Visitors are asked to bring a reusable bottle.”, bukan opsi ini.
- **C. The poster display ends before 9:00 a.m.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The poster display ends before 9:00 a.m.”. Bukti yang menjawab pertanyaan adalah “Please bring a reusable bottle. Registration is free.”, dan bukti itu mendukung “Visitors are asked to bring a reusable bottle.”, bukan opsi ini.
- **D. Visitors are asked to bring a reusable bottle.** — Benar. Pernyataan tentang botol yang dapat digunakan kembali dinyatakan langsung. Opsi lain bertentangan dengan informasi biaya dan jadwal atau menambahkan lokasi yang tidak disebut. Bukti teks: “Please bring a reusable bottle. Registration is free.”

---

### W9S1-Q04 — reasoning_about_distractors (developing)
**Stimulus:** W9S1-T2

**Question:** According to the article, why can choosing the first time in a notice be a mistake?

- **A.** Readers should ignore times in notices.
- **B.** A notice always lists times in alphabetical order.
- **C.** A notice may include different times for different activities.
- **D.** The first time is never correct.

**Jawaban:** C. A notice may include different times for different activities.

**Pembahasan:** Satu teks dapat memuat beberapa waktu dengan fungsi berbeda. Siswa harus mencocokkan waktu dengan target pertanyaan.

**Bukti teks:** “a notice may mention both the time a workshop begins and the time an exhibition closes.”

**Alasan setiap opsi:**
- **A. Readers should ignore times in notices.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Readers should ignore times in notices.”. Bukti yang menjawab pertanyaan adalah “a notice may mention both the time a workshop begins and the time an exhibition closes.”, dan bukti itu mendukung “A notice may include different times for different activities.”, bukan opsi ini.
- **B. A notice always lists times in alphabetical order.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A notice always lists times in alphabetical order.”. Bukti yang menjawab pertanyaan adalah “a notice may mention both the time a workshop begins and the time an exhibition closes.”, dan bukti itu mendukung “A notice may include different times for different activities.”, bukan opsi ini.
- **C. A notice may include different times for different activities.** — Benar. Satu teks dapat memuat beberapa waktu dengan fungsi berbeda. Siswa harus mencocokkan waktu dengan target pertanyaan. Bukti teks: “a notice may mention both the time a workshop begins and the time an exhibition closes.”
- **D. The first time is never correct.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The first time is never correct.”. Bukti yang menjawab pertanyaan adalah “a notice may mention both the time a workshop begins and the time an exhibition closes.”, dan bukti itu mendukung “A notice may include different times for different activities.”, bukan opsi ini.

---

### W9S1-Q05 — term_explanation_in_context (developing)
**Stimulus:** W9S1-T2

**Question:** Which description best explains a distractor in the article?

- **A.** An answer that looks possible but does not meet the question
- **B.** A question that has no answer
- **C.** A sentence that repeats the title of a passage
- **D.** A detail that must always be correct

**Jawaban:** A. An answer that looks possible but does not meet the question

**Pembahasan:** Definisi bacaan menyatakan distractor tampak mungkin, tetapi tidak memenuhi tuntutan pertanyaan.

**Bukti teks:** “A distractor is an answer choice designed to look possible but does not satisfy the question.”

**Alasan setiap opsi:**
- **A. An answer that looks possible but does not meet the question** — Benar. Definisi bacaan menyatakan distractor tampak mungkin, tetapi tidak memenuhi tuntutan pertanyaan. Bukti teks: “A distractor is an answer choice designed to look possible but does not satisfy the question.”
- **B. A question that has no answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A question that has no answer”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An answer that looks possible but does not meet the question”, bukan opsi ini.
- **C. A sentence that repeats the title of a passage** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A sentence that repeats the title of a passage”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An answer that looks possible but does not meet the question”, bukan opsi ini.
- **D. A detail that must always be correct** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A detail that must always be correct”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An answer that looks possible but does not meet the question”, bukan opsi ini.

---

### W9S1-Q06 — contradiction_detection (medium)
**Stimulus:** W9S1-T1

**Question:** Which option contradicts the notice?

- **A.** Registration is free.
- **B.** The event takes place on Sunday, 22 November.
- **C.** The gardening demonstration starts at 9:15 a.m.
- **D.** The event runs until 11:30 a.m.

**Jawaban:** B. The event takes place on Sunday, 22 November.

**Pembahasan:** Opsi D menyebut hari dan tanggal yang berbeda dari notice. Tiga opsi lain sesuai dengan informasi teks.

**Bukti teks:** “Saturday, 21 November”

**Alasan setiap opsi:**
- **A. Registration is free.** — Tidak tepat. Detail “Registration is free.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Saturday, 21 November”, yang mendukung “The event takes place on Sunday, 22 November.”.
- **B. The event takes place on Sunday, 22 November.** — Benar. Opsi D menyebut hari dan tanggal yang berbeda dari notice. Tiga opsi lain sesuai dengan informasi teks. Bukti teks: “Saturday, 21 November”
- **C. The gardening demonstration starts at 9:15 a.m.** — Tidak tepat. Detail “The gardening demonstration starts at 9:15 a.m.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Saturday, 21 November”, yang mendukung “The event takes place on Sunday, 22 November.”.
- **D. The event runs until 11:30 a.m.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The event runs until 11:30 a.m.”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 November”, dan bukti itu mendukung “The event takes place on Sunday, 22 November.”, bukan opsi ini.

---

### W9S1-Q07 — strategy_application (medium)
**Stimulus:** W9S1-T2

**Question:** The article says a plausible option sounds reasonable at first. What should a reader do next?

- **A.** Choose the longest option
- **B.** Check it against the exact target and full message
- **C.** Choose it immediately
- **D.** Ignore the question

**Jawaban:** B. Check it against the exact target and full message

**Pembahasan:** Langkah berikutnya adalah memeriksa pilihan terhadap pertanyaan dan seluruh konteks, bukan mengandalkan kesan awal.

**Bukti teks:** “readers need to check it against the full message.”

**Alasan setiap opsi:**
- **A. Choose the longest option** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the longest option”. Bukti yang menjawab pertanyaan adalah “readers need to check it against the full message.”, dan bukti itu mendukung “Check it against the exact target and full message”, bukan opsi ini.
- **B. Check it against the exact target and full message** — Benar. Langkah berikutnya adalah memeriksa pilihan terhadap pertanyaan dan seluruh konteks, bukan mengandalkan kesan awal. Bukti teks: “readers need to check it against the full message.”
- **C. Choose it immediately** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose it immediately”. Bukti yang menjawab pertanyaan adalah “readers need to check it against the full message.”, dan bukti itu mendukung “Check it against the exact target and full message”, bukan opsi ini.
- **D. Ignore the question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore the question”. Bukti yang menjawab pertanyaan adalah “readers need to check it against the full message.”, dan bukti itu mendukung “Check it against the exact target and full message”, bukan opsi ini.

---

### W9S1-Q08 — vocabulary_meaning (easy)
**Stimulus:** W9S1-T2

**Question:** In the article, what does “distractor” mean?

- **A.** A clue that confirms every answer
- **B.** A heading that introduces a topic
- **C.** An option that looks possible but is not correct
- **D.** The main idea of a passage

**Jawaban:** C. An option that looks possible but is not correct

**Pembahasan:** Distractor adalah pilihan pengecoh yang tampak masuk akal tetapi tidak memenuhi pertanyaan.

**Bukti teks:** “A distractor is an answer choice designed to look possible but does not satisfy the question.”

**Alasan setiap opsi:**
- **A. A clue that confirms every answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A clue that confirms every answer”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An option that looks possible but is not correct”, bukan opsi ini.
- **B. A heading that introduces a topic** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A heading that introduces a topic”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An option that looks possible but is not correct”, bukan opsi ini.
- **C. An option that looks possible but is not correct** — Benar. Distractor adalah pilihan pengecoh yang tampak masuk akal tetapi tidak memenuhi pertanyaan. Bukti teks: “A distractor is an answer choice designed to look possible but does not satisfy the question.”
- **D. The main idea of a passage** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The main idea of a passage”. Bukti yang menjawab pertanyaan adalah “A distractor is an answer choice designed to look possible but does not satisfy the question.”, dan bukti itu mendukung “An option that looks possible but is not correct”, bukan opsi ini.

---

### W9S1-Q09 — contextual_synonym (easy)
**Stimulus:** W9S1-T2

**Question:** Which word is closest in meaning to “plausible” in this context?

- **A.** Believable
- **B.** Impossible
- **C.** Unrelated
- **D.** Contradictory

**Jawaban:** A. Believable

**Pembahasan:** Plausible berarti tampak masuk akal atau dapat dipercaya pada awalnya; bukan berarti pasti benar.

**Bukti teks:** “A plausible option sounds reasonable at first”

**Alasan setiap opsi:**
- **A. Believable** — Benar. Plausible berarti tampak masuk akal atau dapat dipercaya pada awalnya; bukan berarti pasti benar. Bukti teks: “A plausible option sounds reasonable at first”
- **B. Impossible** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Impossible”. Bukti yang menjawab pertanyaan adalah “A plausible option sounds reasonable at first”, dan bukti itu mendukung “Believable”, bukan opsi ini.
- **C. Unrelated** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Unrelated”. Bukti yang menjawab pertanyaan adalah “A plausible option sounds reasonable at first”, dan bukti itu mendukung “Believable”, bukan opsi ini.
- **D. Contradictory** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Contradictory”. Bukti yang menjawab pertanyaan adalah “A plausible option sounds reasonable at first”, dan bukti itu mendukung “Believable”, bukan opsi ini.

---

### W9S1-Q10 — vocabulary_meaning (developing)
**Stimulus:** W9S1-T2

**Question:** Choose the best meaning of “contradict” in the sentence: “The date in option D contradicts the notice.”

- **A.** To add a useful example
- **B.** To shorten the information
- **C.** To disagree with or oppose the information
- **D.** To repeat the same information

**Jawaban:** C. To disagree with or oppose the information

**Pembahasan:** Contradict berarti bertentangan dengan fakta yang dinyatakan.

**Bukti teks:** “An option may contradict a stated fact”

**Alasan setiap opsi:**
- **A. To add a useful example** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To add a useful example”. Bukti yang menjawab pertanyaan adalah “An option may contradict a stated fact”, dan bukti itu mendukung “To disagree with or oppose the information”, bukan opsi ini.
- **B. To shorten the information** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To shorten the information”. Bukti yang menjawab pertanyaan adalah “An option may contradict a stated fact”, dan bukti itu mendukung “To disagree with or oppose the information”, bukan opsi ini.
- **C. To disagree with or oppose the information** — Benar. Contradict berarti bertentangan dengan fakta yang dinyatakan. Bukti teks: “An option may contradict a stated fact”
- **D. To repeat the same information** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To repeat the same information”. Bukti yang menjawab pertanyaan adalah “An option may contradict a stated fact”, dan bukti itu mendukung “To disagree with or oppose the information”, bukan opsi ini.

---

### W9S1-Q11 — vocabulary_meaning (developing)
**Stimulus:** W9S1-T2

**Question:** In the sentence “Readers eliminate choices that do not answer the question,” what does “eliminate” mean?

- **A.** Remove from consideration
- **B.** Explain in detail
- **C.** Keep for later
- **D.** Copy into notes

**Jawaban:** A. Remove from consideration

**Pembahasan:** Eliminate berarti menghapus atau mencoret pilihan dari pertimbangan setelah diperiksa.

**Bukti teks:** “Readers eliminate an option only after checking the whole statement.”

**Alasan setiap opsi:**
- **A. Remove from consideration** — Benar. Eliminate berarti menghapus atau mencoret pilihan dari pertimbangan setelah diperiksa. Bukti teks: “Readers eliminate an option only after checking the whole statement.”
- **B. Explain in detail** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Explain in detail”. Bukti yang menjawab pertanyaan adalah “Readers eliminate an option only after checking the whole statement.”, dan bukti itu mendukung “Remove from consideration”, bukan opsi ini.
- **C. Keep for later** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Keep for later”. Bukti yang menjawab pertanyaan adalah “Readers eliminate an option only after checking the whole statement.”, dan bukti itu mendukung “Remove from consideration”, bukan opsi ini.
- **D. Copy into notes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copy into notes”. Bukti yang menjawab pertanyaan adalah “Readers eliminate an option only after checking the whole statement.”, dan bukti itu mendukung “Remove from consideration”, bukan opsi ini.

---

### W9S1-Q12 — target_matching (medium)
**Stimulus:** W9S1-T1

**Question:** A question asks for the closing time of an exhibition. Which action is the best first check?

- **A.** Choose the most familiar time
- **B.** Choose the first time printed in the notice
- **C.** Ignore the event details
- **D.** Find every time and match it to the word “closing” or “ends”

**Jawaban:** D. Find every time and match it to the word “closing” or “ends”

**Pembahasan:** Siswa perlu mencari waktu yang terkait dengan penutupan display, bukan waktu mulai acara atau demonstrasi.

**Bukti teks:** “The poster display remains open until 11:30 a.m.”

**Alasan setiap opsi:**
- **A. Choose the most familiar time** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the most familiar time”. Bukti yang menjawab pertanyaan adalah “The poster display remains open until 11:30 a.m.”, dan bukti itu mendukung “Find every time and match it to the word “closing” or “ends””, bukan opsi ini.
- **B. Choose the first time printed in the notice** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the first time printed in the notice”. Bukti yang menjawab pertanyaan adalah “The poster display remains open until 11:30 a.m.”, dan bukti itu mendukung “Find every time and match it to the word “closing” or “ends””, bukan opsi ini.
- **C. Ignore the event details** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore the event details”. Bukti yang menjawab pertanyaan adalah “The poster display remains open until 11:30 a.m.”, dan bukti itu mendukung “Find every time and match it to the word “closing” or “ends””, bukan opsi ini.
- **D. Find every time and match it to the word “closing” or “ends”** — Benar. Siswa perlu mencari waktu yang terkait dengan penutupan display, bukan waktu mulai acara atau demonstrasi. Bukti teks: “The poster display remains open until 11:30 a.m.”

---

# W9-ONLINE-02 — Distractor Traps: Partial, Irrelevant and Unsupported Choices
**Week:** 9 · **Questions:** 12 · **Difficulty:** Easy 3 / Developing 5 / Medium 4

## Stimuli

### W9S2-T1 — The River Clean-up Announcement (Announcement; 61 words)

```text
RIVER CARE MORNING
Date: Sunday, 6 December
Meeting point: Community Centre
Start: 7:30 a.m.
Finish: 10:00 a.m.
Participants should wear comfortable shoes and bring drinking water. The organisers will provide gloves and collection bags. Children must stay with their group leader. The activity will take place along the east path, not beside the boat station. Registration closes on Thursday, 3 December.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W9S2-T2 — Reading Beyond a Matching Word (Informational article; 128 words)

```text
A multiple-choice option can mislead readers by repeating a word from the passage. Imagine that a report says the river team collected plastic near the east path, while the boat station was used only as a meeting landmark. An option that says the clean-up happened at the boat station uses a familiar place name, but it is not supported by the report. Another option may be partially correct: it gives the correct date but the wrong starting time. Readers should eliminate choices only after checking the whole statement. A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked. The safest method is to match the question, the evidence, and the complete meaning of the option.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **irrelevant** (adjective; NEW) — tidak berkaitan dengan pertanyaan atau topik yang sedang dibahas. *Example:* A true detail can still be irrelevant to the question. *Synonym/related:* unrelated, not relevant. *Contrast:* relevant.
- **partially** (adverb; NEW) — sebagian; tidak secara lengkap. *Example:* The option is partially correct but misses the time. *Synonym/related:* in part, partly. *Contrast:* completely, fully.
- **mislead** (verb; NEW) — menyesatkan atau membuat orang memahami secara keliru. *Example:* A familiar keyword can mislead a careless reader. *Synonym/related:* confuse, give a false impression. *Contrast:* guide correctly, clarify.
- **unsupported** (adjective; NEW) — tidak didukung oleh bukti yang tersedia. *Example:* The passage gives no evidence for that unsupported claim. *Synonym/related:* unsubstantiated, not backed up. *Contrast:* supported, evidenced.
- **distractor** (noun; RECYCLED) — pilihan jawaban pengecoh yang tampak mungkin tetapi tidak tepat. *Example:* A distractor may repeat a word from the passage. *Synonym/related:* plausible wrong option. *Contrast:* —.
- **plausible** (adjective; RECYCLED) — masuk akal atau tampak mungkin. *Example:* A plausible choice still needs textual evidence. *Synonym/related:* reasonable, believable. *Contrast:* implausible.
- **contradict** (verb; RECYCLED) — bertentangan dengan informasi atau pernyataan. *Example:* The final sentence may contradict the first claim. *Synonym/related:* conflict with, be inconsistent with. *Contrast:* agree with, support.
- **eliminate** (verb; RECYCLED) — menghilangkan atau mencoret dari pilihan. *Example:* Readers eliminate options that do not answer the question. *Synonym/related:* remove, rule out. *Contrast:* keep, retain.
- **purpose** (noun; RECYCLED) — tujuan. *Example:* The purpose is to share information. *Synonym/related:* aim, intention. *Contrast:* —.
- **sequence** (noun; RECYCLED) — urutan. *Example:* The schedule follows a clear sequence. *Synonym/related:* order, series. *Contrast:* disorder (contextual).

## Answer key and explanations

### W9S2-Q01 — explicit_detail (easy)
**Stimulus:** W9S2-T1

**Question:** Where is the meeting point for River Care Morning?

- **A.** The school library
- **B.** The boat station
- **C.** The east path
- **D.** The community centre

**Jawaban:** D. The community centre

**Pembahasan:** Label meeting point menunjuk community centre.

**Bukti teks:** “Meeting point: Community Centre”

**Alasan setiap opsi:**
- **A. The school library** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The school library”. Bukti yang menjawab pertanyaan adalah “Meeting point: Community Centre”, dan bukti itu mendukung “The community centre”, bukan opsi ini.
- **B. The boat station** — Tidak tepat. Detail “The boat station” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Meeting point: Community Centre”, yang mendukung “The community centre”.
- **C. The east path** — Tidak tepat. Detail “The east path” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Meeting point: Community Centre”, yang mendukung “The community centre”.
- **D. The community centre** — Benar. Label meeting point menunjuk community centre. Bukti teks: “Meeting point: Community Centre”

---

### W9S2-Q02 — explicit_detail (easy)
**Stimulus:** W9S2-T1

**Question:** When does registration close?

- **A.** Thursday, 3 December
- **B.** 10:00 a.m.
- **C.** 7:30 a.m.
- **D.** Sunday, 6 December

**Jawaban:** A. Thursday, 3 December

**Pembahasan:** Tanggal penutupan pendaftaran adalah Kamis, 3 Desember; tanggal kegiatan adalah Minggu, 6 Desember.

**Bukti teks:** “Registration closes on Thursday, 3 December.”

**Alasan setiap opsi:**
- **A. Thursday, 3 December** — Benar. Tanggal penutupan pendaftaran adalah Kamis, 3 Desember; tanggal kegiatan adalah Minggu, 6 Desember. Bukti teks: “Registration closes on Thursday, 3 December.”
- **B. 10:00 a.m.** — Tidak tepat. Detail “10:00 a.m.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Registration closes on Thursday, 3 December.”, yang mendukung “Thursday, 3 December”.
- **C. 7:30 a.m.** — Tidak tepat. Detail “7:30 a.m.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Registration closes on Thursday, 3 December.”, yang mendukung “Thursday, 3 December”.
- **D. Sunday, 6 December** — Tidak tepat. Detail “Sunday, 6 December” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Registration closes on Thursday, 3 December.”, yang mendukung “Thursday, 3 December”.

---

### W9S2-Q03 — not_supported (developing)
**Stimulus:** W9S2-T1

**Question:** Which statement is NOT supported by the announcement?

- **A.** The clean-up will take place beside the boat station.
- **B.** Participants should bring drinking water.
- **C.** Gloves will be provided.
- **D.** Children must stay with their group leader.

**Jawaban:** A. The clean-up will take place beside the boat station.

**Pembahasan:** Pernyataan lokasi di dekat boat station secara eksplisit disangkal oleh teks.

**Bukti teks:** “The activity will take place along the east path, not beside the boat station.”

**Alasan setiap opsi:**
- **A. The clean-up will take place beside the boat station.** — Benar. Pernyataan lokasi di dekat boat station secara eksplisit disangkal oleh teks. Bukti teks: “The activity will take place along the east path, not beside the boat station.”
- **B. Participants should bring drinking water.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Participants should bring drinking water.”. Bukti yang menjawab pertanyaan adalah “The activity will take place along the east path, not beside the boat station.”, dan bukti itu mendukung “The clean-up will take place beside the boat station.”, bukan opsi ini.
- **C. Gloves will be provided.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Gloves will be provided.”. Bukti yang menjawab pertanyaan adalah “The activity will take place along the east path, not beside the boat station.”, dan bukti itu mendukung “The clean-up will take place beside the boat station.”, bukan opsi ini.
- **D. Children must stay with their group leader.** — Tidak tepat. Detail “Children must stay with their group leader.” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “The activity will take place along the east path, not beside the boat station.”, yang mendukung “The clean-up will take place beside the boat station.”.

---

### W9S2-Q04 — distractor_analysis (developing)
**Stimulus:** W9S2-T2

**Question:** Why can the option about the boat station mislead a reader?

- **A.** The notice gives no location information.
- **B.** The activity starts at the boat station.
- **C.** The boat station is the only meeting point.
- **D.** The boat station is mentioned, but only as a place the activity is not held.

**Jawaban:** D. The boat station is mentioned, but only as a place the activity is not held.

**Pembahasan:** Boat station disebut, tetapi bukan lokasi kegiatan; kesamaan kata dapat menyesatkan jika konteks diabaikan.

**Bukti teks:** “the boat station was used only as a meeting landmark” and “it is not supported by the report.”

**Alasan setiap opsi:**
- **A. The notice gives no location information.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The notice gives no location information.”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “it is not supported by the report.”, dan bukti itu mendukung “The boat station is mentioned, but only as a place the activity is not held.”, bukan opsi ini.
- **B. The activity starts at the boat station.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The activity starts at the boat station.”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “it is not supported by the report.”, dan bukti itu mendukung “The boat station is mentioned, but only as a place the activity is not held.”, bukan opsi ini.
- **C. The boat station is the only meeting point.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The boat station is the only meeting point.”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “it is not supported by the report.”, dan bukti itu mendukung “The boat station is mentioned, but only as a place the activity is not held.”, bukan opsi ini.
- **D. The boat station is mentioned, but only as a place the activity is not held.** — Benar. Boat station disebut, tetapi bukan lokasi kegiatan; kesamaan kata dapat menyesatkan jika konteks diabaikan. Bukti teks: “the boat station was used only as a meeting landmark” and “it is not supported by the report.”

---

### W9S2-Q05 — partial_correctness (developing)
**Stimulus:** W9S2-T2

**Question:** Which option is partially correct according to the article's example?

- **A.** It gives the correct date but the wrong starting time.
- **B.** It gives the wrong date and the correct place.
- **C.** It gives no date and no time.
- **D.** It gives the correct place and starting time.

**Jawaban:** A. It gives the correct date but the wrong starting time.

**Pembahasan:** Artikel secara langsung menjelaskan pilihan yang sebagian benar: tanggal cocok, tetapi waktu mulai salah.

**Bukti teks:** “it gives the correct date but the wrong starting time.”

**Alasan setiap opsi:**
- **A. It gives the correct date but the wrong starting time.** — Benar. Artikel secara langsung menjelaskan pilihan yang sebagian benar: tanggal cocok, tetapi waktu mulai salah. Bukti teks: “it gives the correct date but the wrong starting time.”
- **B. It gives the wrong date and the correct place.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It gives the wrong date and the correct place.”. Bukti yang menjawab pertanyaan adalah “it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “It gives the correct date but the wrong starting time.”, bukan opsi ini.
- **C. It gives no date and no time.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It gives no date and no time.”. Bukti yang menjawab pertanyaan adalah “it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “It gives the correct date but the wrong starting time.”, bukan opsi ini.
- **D. It gives the correct place and starting time.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It gives the correct place and starting time.”. Bukti yang menjawab pertanyaan adalah “it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “It gives the correct date but the wrong starting time.”, bukan opsi ini.

---

### W9S2-Q06 — relevance_to_question (medium)
**Stimulus:** W9S2-T1

**Question:** Which detail is irrelevant to the question “What should participants wear?”

- **A.** The participants' clothing
- **B.** The meeting point
- **C.** Comfortable shoes
- **D.** The instruction to wear comfortable shoes

**Jawaban:** B. The meeting point

**Pembahasan:** Meeting point adalah informasi benar, tetapi tidak menjawab pertanyaan tentang pakaian.

**Bukti teks:** “Participants should wear comfortable shoes and bring drinking water.”; “Meeting point: Community Centre”

**Alasan setiap opsi:**
- **A. The participants' clothing** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The participants' clothing”. Bukti yang menjawab pertanyaan adalah “Participants should wear comfortable shoes and bring drinking water.”; “Meeting point: Community Centre”, dan bukti itu mendukung “The meeting point”, bukan opsi ini.
- **B. The meeting point** — Benar. Meeting point adalah informasi benar, tetapi tidak menjawab pertanyaan tentang pakaian. Bukti teks: “Participants should wear comfortable shoes and bring drinking water.”; “Meeting point: Community Centre”
- **C. Comfortable shoes** — Tidak tepat. Detail “Comfortable shoes” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Participants should wear comfortable shoes and bring drinking water.”; “Meeting point: Community Centre”, yang mendukung “The meeting point”.
- **D. The instruction to wear comfortable shoes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The instruction to wear comfortable shoes”. Bukti yang menjawab pertanyaan adalah “Participants should wear comfortable shoes and bring drinking water.”; “Meeting point: Community Centre”, dan bukti itu mendukung “The meeting point”, bukan opsi ini.

---

### W9S2-Q07 — main_idea (medium)
**Stimulus:** W9S2-T2

**Question:** Which statement best expresses the article's advice?

- **A.** Every option mentioning the passage is correct.
- **B.** Readers should avoid reading the passage again.
- **C.** Readers should compare the complete option with the question and evidence.
- **D.** A matching word is enough to prove an option correct.

**Jawaban:** C. Readers should compare the complete option with the question and evidence.

**Pembahasan:** Gagasan utama artikel adalah mencocokkan pertanyaan, bukti, dan makna lengkap opsi.

**Bukti teks:** “The safest method is to match the question, the evidence, and the complete meaning of the option.”

**Alasan setiap opsi:**
- **A. Every option mentioning the passage is correct.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Every option mentioning the passage is correct.”. Bukti yang menjawab pertanyaan adalah “The safest method is to match the question, the evidence, and the complete meaning of the option.”, dan bukti itu mendukung “Readers should compare the complete option with the question and evidence.”, bukan opsi ini.
- **B. Readers should avoid reading the passage again.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Readers should avoid reading the passage again.”. Bukti yang menjawab pertanyaan adalah “The safest method is to match the question, the evidence, and the complete meaning of the option.”, dan bukti itu mendukung “Readers should compare the complete option with the question and evidence.”, bukan opsi ini.
- **C. Readers should compare the complete option with the question and evidence.** — Benar. Gagasan utama artikel adalah mencocokkan pertanyaan, bukti, dan makna lengkap opsi. Bukti teks: “The safest method is to match the question, the evidence, and the complete meaning of the option.”
- **D. A matching word is enough to prove an option correct.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A matching word is enough to prove an option correct.”. Bukti yang menjawab pertanyaan adalah “The safest method is to match the question, the evidence, and the complete meaning of the option.”, dan bukti itu mendukung “Readers should compare the complete option with the question and evidence.”, bukan opsi ini.

---

### W9S2-Q08 — vocabulary_meaning (easy)
**Stimulus:** W9S2-T2

**Question:** What does “irrelevant” mean in “A true detail can still be irrelevant to the question”?

- **A.** More important than the main idea
- **B.** Clearly supported by the passage
- **C.** Not connected to what is being asked
- **D.** Repeated several times

**Jawaban:** C. Not connected to what is being asked

**Pembahasan:** Irrelevant berarti tidak berkaitan dengan hal yang sedang ditanyakan.

**Bukti teks:** “A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked.”

**Alasan setiap opsi:**
- **A. More important than the main idea** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “More important than the main idea”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked.”, dan bukti itu mendukung “Not connected to what is being asked”, bukan opsi ini.
- **B. Clearly supported by the passage** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Clearly supported by the passage”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked.”, dan bukti itu mendukung “Not connected to what is being asked”, bukan opsi ini.
- **C. Not connected to what is being asked** — Benar. Irrelevant berarti tidak berkaitan dengan hal yang sedang ditanyakan. Bukti teks: “A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked.”
- **D. Repeated several times** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Repeated several times”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage, but it does not answer what was asked.”, dan bukti itu mendukung “Not connected to what is being asked”, bukan opsi ini.

---

### W9S2-Q09 — contextual_paraphrase (developing)
**Stimulus:** W9S2-T2

**Question:** Which phrase is closest in meaning to “partially correct”?

- **A.** Not mentioned at all
- **B.** Correct in some but not all details
- **C.** Correct in every detail
- **D.** Completely wrong

**Jawaban:** B. Correct in some but not all details

**Pembahasan:** Partially correct berarti benar pada sebagian informasi, tetapi tidak seluruhnya.

**Bukti teks:** “Another option may be partially correct: it gives the correct date but the wrong starting time.”

**Alasan setiap opsi:**
- **A. Not mentioned at all** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Not mentioned at all”. Bukti yang menjawab pertanyaan adalah “Another option may be partially correct: it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “Correct in some but not all details”, bukan opsi ini.
- **B. Correct in some but not all details** — Benar. Partially correct berarti benar pada sebagian informasi, tetapi tidak seluruhnya. Bukti teks: “Another option may be partially correct: it gives the correct date but the wrong starting time.”
- **C. Correct in every detail** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Correct in every detail”. Bukti yang menjawab pertanyaan adalah “Another option may be partially correct: it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “Correct in some but not all details”, bukan opsi ini.
- **D. Completely wrong** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Completely wrong”. Bukti yang menjawab pertanyaan adalah “Another option may be partially correct: it gives the correct date but the wrong starting time.”, dan bukti itu mendukung “Correct in some but not all details”, bukan opsi ini.

---

### W9S2-Q10 — vocabulary_meaning (developing)
**Stimulus:** W9S2-T2

**Question:** In the article, what does “mislead” mean?

- **A.** Help someone check a fact
- **B.** Remove an incorrect answer
- **C.** Provide a complete explanation
- **D.** Make someone understand something incorrectly

**Jawaban:** D. Make someone understand something incorrectly

**Pembahasan:** Mislead berarti menyesatkan atau membuat pembaca salah memahami informasi.

**Bukti teks:** “A multiple-choice option can mislead readers by repeating a word from the passage.”

**Alasan setiap opsi:**
- **A. Help someone check a fact** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Help someone check a fact”. Bukti yang menjawab pertanyaan adalah “A multiple-choice option can mislead readers by repeating a word from the passage.”, dan bukti itu mendukung “Make someone understand something incorrectly”, bukan opsi ini.
- **B. Remove an incorrect answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove an incorrect answer”. Bukti yang menjawab pertanyaan adalah “A multiple-choice option can mislead readers by repeating a word from the passage.”, dan bukti itu mendukung “Make someone understand something incorrectly”, bukan opsi ini.
- **C. Provide a complete explanation** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Provide a complete explanation”. Bukti yang menjawab pertanyaan adalah “A multiple-choice option can mislead readers by repeating a word from the passage.”, dan bukti itu mendukung “Make someone understand something incorrectly”, bukan opsi ini.
- **D. Make someone understand something incorrectly** — Benar. Mislead berarti menyesatkan atau membuat pembaca salah memahami informasi. Bukti teks: “A multiple-choice option can mislead readers by repeating a word from the passage.”

---

### W9S2-Q11 — vocabulary_meaning (medium)
**Stimulus:** W9S2-T2

**Question:** What is an “unsupported claim”?

- **A.** A claim repeated in the passage
- **B.** A claim supported by two details
- **C.** A claim that has no evidence in the available text
- **D.** A claim that restates the main idea

**Jawaban:** C. A claim that has no evidence in the available text

**Pembahasan:** Unsupported berarti tidak didukung bukti yang tersedia; jangan menambah informasi sendiri.

**Bukti teks:** “A choice that is irrelevant to the question may still be true in the passage” and “does not answer what was asked.”

**Alasan setiap opsi:**
- **A. A claim repeated in the passage** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A claim repeated in the passage”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage” and “does not answer what was asked.”, dan bukti itu mendukung “A claim that has no evidence in the available text”, bukan opsi ini.
- **B. A claim supported by two details** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A claim supported by two details”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage” and “does not answer what was asked.”, dan bukti itu mendukung “A claim that has no evidence in the available text”, bukan opsi ini.
- **C. A claim that has no evidence in the available text** — Benar. Unsupported berarti tidak didukung bukti yang tersedia; jangan menambah informasi sendiri. Bukti teks: “A choice that is irrelevant to the question may still be true in the passage” and “does not answer what was asked.”
- **D. A claim that restates the main idea** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A claim that restates the main idea”. Bukti yang menjawab pertanyaan adalah “A choice that is irrelevant to the question may still be true in the passage” and “does not answer what was asked.”, dan bukti itu mendukung “A claim that has no evidence in the available text”, bukan opsi ini.

---

### W9S2-Q12 — distractor_classification (medium)
**Stimulus:** W9S2-T2

**Question:** A choice repeats a place name from the text but says the activity happened there even though the text says it did not. What is the best reason to reject it?

- **A.** It mentions a place name
- **B.** It uses a familiar word but contradicts the text
- **C.** It is shorter than the other options
- **D.** It contains a capital letter

**Jawaban:** B. It uses a familiar word but contradicts the text

**Pembahasan:** Pilihan itu menggunakan kata yang familiar tetapi bertentangan dengan informasi dalam teks.

**Bukti teks:** “the boat station was used only as a meeting landmark” and “not supported by the report.”

**Alasan setiap opsi:**
- **A. It mentions a place name** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It mentions a place name”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “not supported by the report.”, dan bukti itu mendukung “It uses a familiar word but contradicts the text”, bukan opsi ini.
- **B. It uses a familiar word but contradicts the text** — Benar. Pilihan itu menggunakan kata yang familiar tetapi bertentangan dengan informasi dalam teks. Bukti teks: “the boat station was used only as a meeting landmark” and “not supported by the report.”
- **C. It is shorter than the other options** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It is shorter than the other options”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “not supported by the report.”, dan bukti itu mendukung “It uses a familiar word but contradicts the text”, bukan opsi ini.
- **D. It contains a capital letter** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “It contains a capital letter”. Bukti yang menjawab pertanyaan adalah “the boat station was used only as a meeting landmark” and “not supported by the report.”, dan bukti itu mendukung “It uses a familiar word but contradicts the text”, bukan opsi ini.

---

# W10-ONLINE-01 — Micro-Grammar for Reading: Connectors and Cause–Effect
**Week:** 10 · **Questions:** 12 · **Difficulty:** Easy 3 / Developing 4 / Medium 5

## Stimuli

### W10S1-T1 — A Library That Changed Its Opening Hours (School notice / informational; 76 words)

```text
LIBRARY UPDATE
The library will open at 7:30 a.m. from Monday to Thursday. On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display. The library will close at 3:00 p.m. on all school days. Students may borrow two books at a time, but they must return them within seven days. The quiet-study room is available after lunch; however, group discussions should take place in the project room.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W10S1-T2 — Why the Book Display Was Moved (Informational report; 103 words)

```text
The school library planned to place its new book display near the front door. However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables. The new position is less visible from the entrance, but students can look at the books without blocking the walkway. Because the display is now close to the tables, a small sign explains that students should return each book to the labelled shelf after reading. The change does not mean students have to borrow a book. They may read it in the library, although they must keep the area tidy.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **connector** (noun; NEW) — kata penghubung yang menunjukkan hubungan antargagasan. *Example:* Because is a connector that can introduce a reason. *Synonym/related:* linking word, conjunction. *Contrast:* —.
- **contrast** (noun; NEW) — perbedaan atau pertentangan antara dua hal. *Example:* However signals a contrast between two ideas. *Synonym/related:* difference, opposition. *Contrast:* similarity, agreement.
- **cause** (noun/verb; NEW) — sebab; menyebabkan. *Example:* Heavy rain was the cause of the delay. *Synonym/related:* reason, bring about. *Contrast:* effect (as paired relation).
- **consequence** (noun; NEW) — akibat atau hasil dari suatu tindakan/peristiwa. *Example:* The consequence was a later arrival. *Synonym/related:* result, outcome. *Contrast:* cause (as paired relation).
- **purpose** (noun; RECYCLED) — tujuan. *Example:* The purpose is to share information. *Synonym/related:* aim, intention. *Contrast:* —.
- **sequence** (noun; RECYCLED) — urutan. *Example:* The schedule follows a clear sequence. *Synonym/related:* order, series. *Contrast:* disorder (contextual).
- **detail** (noun; RECYCLED) — rincian. *Example:* One detail supports the main idea. *Synonym/related:* fact, specific point. *Contrast:* overview (contrast).
- **reason** (noun; RECYCLED) — alasan. *Example:* Find the reason for the decision. *Synonym/related:* cause, explanation. *Contrast:* —.
- **relevant** (adjective; RECYCLED) — berkaitan. *Example:* Choose relevant details. *Synonym/related:* related, applicable. *Contrast:* irrelevant.
- **available** (adjective; RECYCLED) — tersedia. *Example:* Room 6 is available after lunch. *Synonym/related:* ready, obtainable. *Contrast:* unavailable.

## Answer key and explanations

### W10S1-Q01 — explicit_detail (easy)
**Stimulus:** W10S1-T1

**Question:** On which day does the library open at 8:00 a.m.?

- **A.** Thursday
- **B.** Tuesday
- **C.** Monday
- **D.** Friday

**Jawaban:** D. Friday

**Pembahasan:** Hari Jumat memiliki jam buka berbeda dari Senin sampai Kamis.

**Bukti teks:** “On Friday, it will open at 8:00 a.m.”

**Alasan setiap opsi:**
- **A. Thursday** — Tidak tepat. Detail “Thursday” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m.”, yang mendukung “Friday”.
- **B. Tuesday** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Tuesday”. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m.”, dan bukti itu mendukung “Friday”, bukan opsi ini.
- **C. Monday** — Tidak tepat. Detail “Monday” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m.”, yang mendukung “Friday”.
- **D. Friday** — Benar. Hari Jumat memiliki jam buka berbeda dari Senin sampai Kamis. Bukti teks: “On Friday, it will open at 8:00 a.m.”

---

### W10S1-Q02 — cause_effect (developing)
**Stimulus:** W10S1-T1

**Question:** Why will the library open later on Friday?

- **A.** The library closes for the whole day.
- **B.** Staff need time to prepare the weekly book display.
- **C.** The quiet-study room is being repaired.
- **D.** Students asked for a longer lunch break.

**Jawaban:** B. Staff need time to prepare the weekly book display.

**Pembahasan:** Kata because memperkenalkan alasan perubahan jam buka.

**Bukti teks:** “because staff members need time to prepare the weekly book display.”

**Alasan setiap opsi:**
- **A. The library closes for the whole day.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library closes for the whole day.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “Staff need time to prepare the weekly book display.”, bukan opsi ini.
- **B. Staff need time to prepare the weekly book display.** — Benar. Kata because memperkenalkan alasan perubahan jam buka. Bukti teks: “because staff members need time to prepare the weekly book display.”
- **C. The quiet-study room is being repaired.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The quiet-study room is being repaired.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “Staff need time to prepare the weekly book display.”, bukan opsi ini.
- **D. Students asked for a longer lunch break.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students asked for a longer lunch break.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “Staff need time to prepare the weekly book display.”, bukan opsi ini.

---

### W10S1-Q03 — connector_meaning (developing)
**Stimulus:** W10S1-T1

**Question:** What does “however” signal in the sentence about group discussions?

- **A.** A time sequence
- **B.** A contrast between two pieces of information
- **C.** A list of examples
- **D.** A direct cause

**Jawaban:** B. A contrast between two pieces of information

**Pembahasan:** However menandai kontras: ruang tenang tersedia, tetapi diskusi kelompok harus di ruang proyek.

**Bukti teks:** “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”

**Alasan setiap opsi:**
- **A. A time sequence** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A time sequence”. Bukti yang menjawab pertanyaan adalah “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A contrast between two pieces of information”, bukan opsi ini.
- **B. A contrast between two pieces of information** — Benar. However menandai kontras: ruang tenang tersedia, tetapi diskusi kelompok harus di ruang proyek. Bukti teks: “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”
- **C. A list of examples** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A list of examples”. Bukti yang menjawab pertanyaan adalah “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A contrast between two pieces of information”, bukan opsi ini.
- **D. A direct cause** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A direct cause”. Bukti yang menjawab pertanyaan adalah “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A contrast between two pieces of information”, bukan opsi ini.

---

### W10S1-Q04 — modal_meaning (medium)
**Stimulus:** W10S1-T1

**Question:** What must students do with the books they borrow?

- **A.** Borrow them without returning
- **B.** Keep them for the whole term
- **C.** Return them within seven days
- **D.** Use them only in the project room

**Jawaban:** C. Return them within seven days

**Pembahasan:** Siswa wajib mengembalikan buku dalam tujuh hari. Kata must menunjukkan kewajiban, bukan sekadar kemampuan.

**Bukti teks:** “they must return them within seven days.”

**Alasan setiap opsi:**
- **A. Borrow them without returning** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Borrow them without returning”. Bukti yang menjawab pertanyaan adalah “they must return them within seven days.”, dan bukti itu mendukung “Return them within seven days”, bukan opsi ini.
- **B. Keep them for the whole term** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Keep them for the whole term”. Bukti yang menjawab pertanyaan adalah “they must return them within seven days.”, dan bukti itu mendukung “Return them within seven days”, bukan opsi ini.
- **C. Return them within seven days** — Benar. Siswa wajib mengembalikan buku dalam tujuh hari. Kata must menunjukkan kewajiban, bukan sekadar kemampuan. Bukti teks: “they must return them within seven days.”
- **D. Use them only in the project room** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use them only in the project room”. Bukti yang menjawab pertanyaan adalah “they must return them within seven days.”, dan bukti itu mendukung “Return them within seven days”, bukan opsi ini.

---

### W10S1-Q05 — cause_effect (medium)
**Stimulus:** W10S1-T2

**Question:** Why was the book display moved?

- **A.** The books were not suitable for students.
- **B.** The reading tables were closed permanently.
- **C.** The front area became crowded during the morning break.
- **D.** The librarian wanted to remove the display.

**Jawaban:** C. The front area became crowded during the morning break.

**Pembahasan:** Kepadatan area depan menjadi sebab pemindahan display; so memperkenalkan akibat.

**Bukti teks:** “the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”

**Alasan setiap opsi:**
- **A. The books were not suitable for students.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The books were not suitable for students.”. Bukti yang menjawab pertanyaan adalah “the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “The front area became crowded during the morning break.”, bukan opsi ini.
- **B. The reading tables were closed permanently.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The reading tables were closed permanently.”. Bukti yang menjawab pertanyaan adalah “the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “The front area became crowded during the morning break.”, bukan opsi ini.
- **C. The front area became crowded during the morning break.** — Benar. Kepadatan area depan menjadi sebab pemindahan display; so memperkenalkan akibat. Bukti teks: “the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”
- **D. The librarian wanted to remove the display.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The librarian wanted to remove the display.”. Bukti yang menjawab pertanyaan adalah “the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “The front area became crowded during the morning break.”, bukan opsi ini.

---

### W10S1-Q06 — modal_meaning (medium)
**Stimulus:** W10S1-T2

**Question:** What does “may read it in the library” mean in the final sentence?

- **A.** Students are allowed to read the book in the library.
- **B.** Students must buy the book.
- **C.** Students are required to borrow the book.
- **D.** Students are forbidden to read the book there.

**Jawaban:** A. Students are allowed to read the book in the library.

**Pembahasan:** May di sini menunjukkan izin atau kemungkinan yang diperbolehkan dalam konteks aturan perpustakaan.

**Bukti teks:** “They may read it in the library, although they must keep the area tidy.”

**Alasan setiap opsi:**
- **A. Students are allowed to read the book in the library.** — Benar. May di sini menunjukkan izin atau kemungkinan yang diperbolehkan dalam konteks aturan perpustakaan. Bukti teks: “They may read it in the library, although they must keep the area tidy.”
- **B. Students must buy the book.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students must buy the book.”. Bukti yang menjawab pertanyaan adalah “They may read it in the library, although they must keep the area tidy.”, dan bukti itu mendukung “Students are allowed to read the book in the library.”, bukan opsi ini.
- **C. Students are required to borrow the book.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students are required to borrow the book.”. Bukti yang menjawab pertanyaan adalah “They may read it in the library, although they must keep the area tidy.”, dan bukti itu mendukung “Students are allowed to read the book in the library.”, bukan opsi ini.
- **D. Students are forbidden to read the book there.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students are forbidden to read the book there.”. Bukti yang menjawab pertanyaan adalah “They may read it in the library, although they must keep the area tidy.”, dan bukti itu mendukung “Students are allowed to read the book in the library.”, bukan opsi ini.

---

### W10S1-Q07 — integrated_detail (medium)
**Stimulus:** W10S1-T1

**Question:** Which statement best summarizes the library's updated rules?

- **A.** Students must borrow a book whenever they visit.
- **B.** The library is open at the same time every day.
- **C.** Students can borrow books and must return them within seven days; group talks use the project room.
- **D.** All discussions must happen in the quiet-study room.

**Jawaban:** C. Students can borrow books and must return them within seven days; group talks use the project room.

**Pembahasan:** Pilihan B menggabungkan dua aturan penting: peminjaman dan lokasi diskusi.

**Bukti teks:** “Students may borrow two books at a time, but they must return them within seven days.”; “group discussions should take place in the project room.”

**Alasan setiap opsi:**
- **A. Students must borrow a book whenever they visit.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students must borrow a book whenever they visit.”. Bukti yang menjawab pertanyaan adalah “Students may borrow two books at a time, but they must return them within seven days.”; “group discussions should take place in the project room.”, dan bukti itu mendukung “Students can borrow books and must return them within seven days; group talks use the project room.”, bukan opsi ini.
- **B. The library is open at the same time every day.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library is open at the same time every day.”. Bukti yang menjawab pertanyaan adalah “Students may borrow two books at a time, but they must return them within seven days.”; “group discussions should take place in the project room.”, dan bukti itu mendukung “Students can borrow books and must return them within seven days; group talks use the project room.”, bukan opsi ini.
- **C. Students can borrow books and must return them within seven days; group talks use the project room.** — Benar. Pilihan B menggabungkan dua aturan penting: peminjaman dan lokasi diskusi. Bukti teks: “Students may borrow two books at a time, but they must return them within seven days.”; “group discussions should take place in the project room.”
- **D. All discussions must happen in the quiet-study room.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “All discussions must happen in the quiet-study room.”. Bukti yang menjawab pertanyaan adalah “Students may borrow two books at a time, but they must return them within seven days.”; “group discussions should take place in the project room.”, dan bukti itu mendukung “Students can borrow books and must return them within seven days; group talks use the project room.”, bukan opsi ini.

---

### W10S1-Q08 — vocabulary_meaning (easy)
**Stimulus:** W10S1-T1

**Question:** What is a “connector” in reading?

- **A.** A punctuation mark at the end of every sentence
- **B.** A word that names a person
- **C.** A list of unrelated facts
- **D.** A word or phrase that shows a relationship between ideas

**Jawaban:** D. A word or phrase that shows a relationship between ideas

**Pembahasan:** Connector adalah kata atau frasa yang menghubungkan gagasan dan menunjukkan hubungan makna.

**Bukti teks:** “On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display.”; “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”

**Alasan setiap opsi:**
- **A. A punctuation mark at the end of every sentence** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A punctuation mark at the end of every sentence”. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display.”; “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A word or phrase that shows a relationship between ideas”, bukan opsi ini.
- **B. A word that names a person** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A word that names a person”. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display.”; “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A word or phrase that shows a relationship between ideas”, bukan opsi ini.
- **C. A list of unrelated facts** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A list of unrelated facts”. Bukti yang menjawab pertanyaan adalah “On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display.”; “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”, dan bukti itu mendukung “A word or phrase that shows a relationship between ideas”, bukan opsi ini.
- **D. A word or phrase that shows a relationship between ideas** — Benar. Connector adalah kata atau frasa yang menghubungkan gagasan dan menunjukkan hubungan makna. Bukti teks: “On Friday, it will open at 8:00 a.m. because staff members need time to prepare the weekly book display.”; “The quiet-study room is available after lunch; however, group discussions should take place in the project room.”

---

### W10S1-Q09 — vocabulary_meaning (easy)
**Stimulus:** W10S1-T1

**Question:** Which word is closest in meaning to “contrast”?

- **A.** Similarity
- **B.** Permission
- **C.** Sequence
- **D.** Difference

**Jawaban:** D. Difference

**Pembahasan:** Contrast menunjukkan perbedaan atau pertentangan antara dua gagasan.

**Bukti teks:** “however”

**Alasan setiap opsi:**
- **A. Similarity** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Similarity”. Bukti yang menjawab pertanyaan adalah “however”, dan bukti itu mendukung “Difference”, bukan opsi ini.
- **B. Permission** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Permission”. Bukti yang menjawab pertanyaan adalah “however”, dan bukti itu mendukung “Difference”, bukan opsi ini.
- **C. Sequence** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Sequence”. Bukti yang menjawab pertanyaan adalah “however”, dan bukti itu mendukung “Difference”, bukan opsi ini.
- **D. Difference** — Benar. Contrast menunjukkan perbedaan atau pertentangan antara dua gagasan. Bukti teks: “however”

---

### W10S1-Q10 — vocabulary_in_context (developing)
**Stimulus:** W10S1-T1

**Question:** In the library notice, what is the cause of the Friday opening change?

- **A.** The weekly book display needs preparation.
- **B.** The library has no books.
- **C.** Students leave early on Fridays.
- **D.** The project room is unavailable.

**Jawaban:** A. The weekly book display needs preparation.

**Pembahasan:** Cause berarti sebab atau alasan yang menghasilkan suatu perubahan.

**Bukti teks:** “because staff members need time to prepare the weekly book display.”

**Alasan setiap opsi:**
- **A. The weekly book display needs preparation.** — Benar. Cause berarti sebab atau alasan yang menghasilkan suatu perubahan. Bukti teks: “because staff members need time to prepare the weekly book display.”
- **B. The library has no books.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library has no books.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “The weekly book display needs preparation.”, bukan opsi ini.
- **C. Students leave early on Fridays.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students leave early on Fridays.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “The weekly book display needs preparation.”, bukan opsi ini.
- **D. The project room is unavailable.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The project room is unavailable.”. Bukti yang menjawab pertanyaan adalah “because staff members need time to prepare the weekly book display.”, dan bukti itu mendukung “The weekly book display needs preparation.”, bukan opsi ini.

---

### W10S1-Q11 — vocabulary_meaning (developing)
**Stimulus:** W10S1-T2

**Question:** What does “consequence” mean?

- **A.** A result that follows an action or event
- **B.** A rule that must be followed
- **C.** A reason that happens before an event
- **D.** A word showing contrast

**Jawaban:** A. A result that follows an action or event

**Pembahasan:** Consequence adalah akibat atau hasil dari suatu sebab/tindakan.

**Bukti teks:** “so the librarian moved the display beside the reading tables.”

**Alasan setiap opsi:**
- **A. A result that follows an action or event** — Benar. Consequence adalah akibat atau hasil dari suatu sebab/tindakan. Bukti teks: “so the librarian moved the display beside the reading tables.”
- **B. A rule that must be followed** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A rule that must be followed”. Bukti yang menjawab pertanyaan adalah “so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result that follows an action or event”, bukan opsi ini.
- **C. A reason that happens before an event** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A reason that happens before an event”. Bukti yang menjawab pertanyaan adalah “so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result that follows an action or event”, bukan opsi ini.
- **D. A word showing contrast** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A word showing contrast”. Bukti yang menjawab pertanyaan adalah “so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result that follows an action or event”, bukan opsi ini.

---

### W10S1-Q12 — connector_application (medium)
**Stimulus:** W10S1-T2

**Question:** Read: “The walkway was crowded, so the display was moved.” Which relationship does “so” show?

- **A.** A contrast
- **B.** A result or consequence
- **C.** A condition
- **D.** A prohibition

**Jawaban:** B. A result or consequence

**Pembahasan:** So memperkenalkan hasil dari keadaan sebelumnya.

**Bukti teks:** “However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”

**Alasan setiap opsi:**
- **A. A contrast** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A contrast”. Bukti yang menjawab pertanyaan adalah “However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result or consequence”, bukan opsi ini.
- **B. A result or consequence** — Benar. So memperkenalkan hasil dari keadaan sebelumnya. Bukti teks: “However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”
- **C. A condition** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A condition”. Bukti yang menjawab pertanyaan adalah “However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result or consequence”, bukan opsi ini.
- **D. A prohibition** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A prohibition”. Bukti yang menjawab pertanyaan adalah “However, the area became crowded during the morning break, so the librarian moved the display beside the reading tables.”, dan bukti itu mendukung “A result or consequence”, bukan opsi ini.

---

# W10-ONLINE-02 — Micro-Grammar for Reading: Contrast, Conditions and Modality
**Week:** 10 · **Questions:** 12 · **Difficulty:** Easy 3 / Developing 4 / Medium 5

## Stimuli

### W10S2-T1 — Food Collection Rules (Notice / functional text; 79 words)

```text
COMMUNITY FOOD COLLECTION
Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon. Do not bring items that need refrigeration. Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution. Students can help label boxes, but they must ask the teacher before moving heavy containers. You do not have to donate food to join the sorting activity. Visitors may not enter the storage area unless a teacher is present.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W10S2-T2 — A Class Survey About Reading Time (Short report; 96 words)

```text
A class survey asked students how they used the library after school. Some students stayed to finish homework, whereas others read stories or prepared group projects. Although the library was quiet, a few students preferred to work at home. The survey did not show that one place was best for everyone. It suggested that students chose a location according to the task they needed to complete. A quiet table may help someone concentrate, but a group may need a room where discussion is allowed. The results therefore describe different needs rather than one perfect study method.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **although** (conjunction; NEW) — meskipun; memperkenalkan gagasan yang berlawanan dengan harapan. *Example:* Although the room was small, the event continued. *Synonym/related:* though, even though. *Contrast:* —.
- **however** (adverb / linking adverb; NEW) — namun; menunjukkan kontras. *Example:* The path was short; however, it was difficult. *Synonym/related:* nevertheless, still. *Contrast:* —.
- **therefore** (adverb / linking adverb; NEW) — oleh karena itu; menunjukkan hasil atau kesimpulan. *Example:* The bus was late; therefore, the group arrived late. *Synonym/related:* as a result, consequently. *Contrast:* —.
- **unless** (conjunction; NEW) — kecuali jika; menyatakan syarat negatif. *Example:* The group cannot enter unless a guide is present. *Synonym/related:* if not, except if. *Contrast:* —.
- **connector** (noun; RECYCLED) — kata penghubung yang menunjukkan hubungan antargagasan. *Example:* Because is a connector that can introduce a reason. *Synonym/related:* linking word, conjunction. *Contrast:* —.
- **contrast** (noun; RECYCLED) — perbedaan atau pertentangan antara dua hal. *Example:* However signals a contrast between two ideas. *Synonym/related:* difference, opposition. *Contrast:* similarity, agreement.
- **cause** (noun/verb; RECYCLED) — sebab; menyebabkan. *Example:* Heavy rain was the cause of the delay. *Synonym/related:* reason, bring about. *Contrast:* effect (as paired relation).
- **consequence** (noun; RECYCLED) — akibat atau hasil dari suatu tindakan/peristiwa. *Example:* The consequence was a later arrival. *Synonym/related:* result, outcome. *Contrast:* cause (as paired relation).
- **likely** (adjective/adverb; RECYCLED) — mungkin besar. *Example:* The result is likely to change. *Synonym/related:* probably, probable. *Contrast:* unlikely.
- **indicate** (verb; RECYCLED) — menunjukkan atau menandakan. *Example:* A heading can indicate the topic. *Synonym/related:* show, signal. *Contrast:* conceal.

## Answer key and explanations

### W10S2-Q01 — explicit_detail (easy)
**Stimulus:** W10S2-T1

**Question:** By when should food packages be brought to Room 3?

- **A.** Wednesday afternoon
- **B.** Tuesday morning
- **C.** Thursday evening
- **D.** Friday afternoon

**Jawaban:** A. Wednesday afternoon

**Pembahasan:** Batas pengumpulan adalah Rabu sore.

**Bukti teks:** “Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon.”

**Alasan setiap opsi:**
- **A. Wednesday afternoon** — Benar. Batas pengumpulan adalah Rabu sore. Bukti teks: “Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon.”
- **B. Tuesday morning** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Tuesday morning”. Bukti yang menjawab pertanyaan adalah “Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon.”, dan bukti itu mendukung “Wednesday afternoon”, bukan opsi ini.
- **C. Thursday evening** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Thursday evening”. Bukti yang menjawab pertanyaan adalah “Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon.”, dan bukti itu mendukung “Wednesday afternoon”, bukan opsi ini.
- **D. Friday afternoon** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Friday afternoon”. Bukti yang menjawab pertanyaan adalah “Please bring sealed, unopened food packages to Room 3 by Wednesday afternoon.”, dan bukti itu mendukung “Wednesday afternoon”, bukan opsi ini.

---

### W10S2-Q02 — connector_meaning (developing)
**Stimulus:** W10S2-T1

**Question:** What does “therefore” connect in the notice?

- **A.** A person and a place
- **B.** Two unrelated examples
- **C.** A question and an answer
- **D.** A reason and its result

**Jawaban:** D. A reason and its result

**Pembahasan:** Therefore memperkenalkan hasil dari jadwal penyortiran Kamis: paket yang terlambat mungkin tidak masuk distribusi pertama.

**Bukti teks:** “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”

**Alasan setiap opsi:**
- **A. A person and a place** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A person and a place”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A reason and its result”, bukan opsi ini.
- **B. Two unrelated examples** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Two unrelated examples”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A reason and its result”, bukan opsi ini.
- **C. A question and an answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A question and an answer”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A reason and its result”, bukan opsi ini.
- **D. A reason and its result** — Benar. Therefore memperkenalkan hasil dari jadwal penyortiran Kamis: paket yang terlambat mungkin tidak masuk distribusi pertama. Bukti teks: “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”

---

### W10S2-Q03 — negation_and_condition (developing)
**Stimulus:** W10S2-T1

**Question:** Which food package should NOT be brought?

- **A.** An unopened packet of rice
- **B.** A sealed box of cereal
- **C.** A chilled food item that needs refrigeration
- **D.** A sealed can of beans

**Jawaban:** C. A chilled food item that needs refrigeration

**Pembahasan:** Larangan berlaku pada makanan yang perlu disimpan dingin.

**Bukti teks:** “Do not bring items that need refrigeration.”

**Alasan setiap opsi:**
- **A. An unopened packet of rice** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “An unopened packet of rice”. Bukti yang menjawab pertanyaan adalah “Do not bring items that need refrigeration.”, dan bukti itu mendukung “A chilled food item that needs refrigeration”, bukan opsi ini.
- **B. A sealed box of cereal** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A sealed box of cereal”. Bukti yang menjawab pertanyaan adalah “Do not bring items that need refrigeration.”, dan bukti itu mendukung “A chilled food item that needs refrigeration”, bukan opsi ini.
- **C. A chilled food item that needs refrigeration** — Benar. Larangan berlaku pada makanan yang perlu disimpan dingin. Bukti teks: “Do not bring items that need refrigeration.”
- **D. A sealed can of beans** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A sealed can of beans”. Bukti yang menjawab pertanyaan adalah “Do not bring items that need refrigeration.”, dan bukti itu mendukung “A chilled food item that needs refrigeration”, bukan opsi ini.

---

### W10S2-Q04 — connector_meaning (developing)
**Stimulus:** W10S2-T2

**Question:** What does “whereas” show in the class survey?

- **A.** A cause of the survey
- **B.** A final result
- **C.** A time limit
- **D.** A contrast between two groups' choices

**Jawaban:** D. A contrast between two groups' choices

**Pembahasan:** Whereas memperlihatkan perbedaan pilihan dua kelompok siswa.

**Bukti teks:** “Some students stayed to finish homework, whereas others read stories or prepared group projects.”

**Alasan setiap opsi:**
- **A. A cause of the survey** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A cause of the survey”. Bukti yang menjawab pertanyaan adalah “Some students stayed to finish homework, whereas others read stories or prepared group projects.”, dan bukti itu mendukung “A contrast between two groups' choices”, bukan opsi ini.
- **B. A final result** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A final result”. Bukti yang menjawab pertanyaan adalah “Some students stayed to finish homework, whereas others read stories or prepared group projects.”, dan bukti itu mendukung “A contrast between two groups' choices”, bukan opsi ini.
- **C. A time limit** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A time limit”. Bukti yang menjawab pertanyaan adalah “Some students stayed to finish homework, whereas others read stories or prepared group projects.”, dan bukti itu mendukung “A contrast between two groups' choices”, bukan opsi ini.
- **D. A contrast between two groups' choices** — Benar. Whereas memperlihatkan perbedaan pilihan dua kelompok siswa. Bukti teks: “Some students stayed to finish homework, whereas others read stories or prepared group projects.”

---

### W10S2-Q05 — evidence_check (medium)
**Stimulus:** W10S2-T2

**Question:** Which statement is supported by the survey?

- **A.** Students chose locations according to the tasks they needed to complete.
- **B.** All students preferred group projects.
- **C.** The library was closed after school.
- **D.** The survey proved that studying at home is always better.

**Jawaban:** A. Students chose locations according to the tasks they needed to complete.

**Pembahasan:** Teks menyatakan pilihan lokasi berbeda sesuai tugas; tidak menetapkan satu tempat terbaik bagi semua siswa.

**Bukti teks:** “It suggested that students chose a location according to the task they needed to complete.”

**Alasan setiap opsi:**
- **A. Students chose locations according to the tasks they needed to complete.** — Benar. Teks menyatakan pilihan lokasi berbeda sesuai tugas; tidak menetapkan satu tempat terbaik bagi semua siswa. Bukti teks: “It suggested that students chose a location according to the task they needed to complete.”
- **B. All students preferred group projects.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “All students preferred group projects.”. Bukti yang menjawab pertanyaan adalah “It suggested that students chose a location according to the task they needed to complete.”, dan bukti itu mendukung “Students chose locations according to the tasks they needed to complete.”, bukan opsi ini.
- **C. The library was closed after school.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library was closed after school.”. Bukti yang menjawab pertanyaan adalah “It suggested that students chose a location according to the task they needed to complete.”, dan bukti itu mendukung “Students chose locations according to the tasks they needed to complete.”, bukan opsi ini.
- **D. The survey proved that studying at home is always better.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The survey proved that studying at home is always better.”. Bukti yang menjawab pertanyaan adalah “It suggested that students chose a location according to the task they needed to complete.”, dan bukti itu mendukung “Students chose locations according to the tasks they needed to complete.”, bukan opsi ini.

---

### W10S2-Q06 — connector_meaning (medium)
**Stimulus:** W10S2-T2

**Question:** What does “although” show in “Although the library was quiet, a few students preferred to work at home”?

- **A.** The two ideas happen in a fixed sequence.
- **B.** The second idea contrasts with the expectation created by the first.
- **C.** The second idea is the direct cause of the first.
- **D.** The second idea is a rule.

**Jawaban:** B. The second idea contrasts with the expectation created by the first.

**Pembahasan:** Although memperkenalkan kontras: meski perpustakaan tenang, beberapa siswa tetap memilih rumah.

**Bukti teks:** “Although the library was quiet, a few students preferred to work at home.”

**Alasan setiap opsi:**
- **A. The two ideas happen in a fixed sequence.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The two ideas happen in a fixed sequence.”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “The second idea contrasts with the expectation created by the first.”, bukan opsi ini.
- **B. The second idea contrasts with the expectation created by the first.** — Benar. Although memperkenalkan kontras: meski perpustakaan tenang, beberapa siswa tetap memilih rumah. Bukti teks: “Although the library was quiet, a few students preferred to work at home.”
- **C. The second idea is the direct cause of the first.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The second idea is the direct cause of the first.”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “The second idea contrasts with the expectation created by the first.”, bukan opsi ini.
- **D. The second idea is a rule.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The second idea is a rule.”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “The second idea contrasts with the expectation created by the first.”, bukan opsi ini.

---

### W10S2-Q07 — modality_negation (medium)
**Stimulus:** W10S2-T1

**Question:** Which interpretation of “You do not have to donate food” is correct?

- **A.** Donating food is optional, not compulsory.
- **B.** Donating food is forbidden.
- **C.** Only teachers may donate food.
- **D.** Everyone must donate food.

**Jawaban:** A. Donating food is optional, not compulsory.

**Pembahasan:** Do not have to menyatakan tidak ada kewajiban; kegiatan tetap dapat diikuti tanpa menyumbang makanan.

**Bukti teks:** “You do not have to donate food to join the sorting activity.”

**Alasan setiap opsi:**
- **A. Donating food is optional, not compulsory.** — Benar. Do not have to menyatakan tidak ada kewajiban; kegiatan tetap dapat diikuti tanpa menyumbang makanan. Bukti teks: “You do not have to donate food to join the sorting activity.”
- **B. Donating food is forbidden.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Donating food is forbidden.”. Bukti yang menjawab pertanyaan adalah “You do not have to donate food to join the sorting activity.”, dan bukti itu mendukung “Donating food is optional, not compulsory.”, bukan opsi ini.
- **C. Only teachers may donate food.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Only teachers may donate food.”. Bukti yang menjawab pertanyaan adalah “You do not have to donate food to join the sorting activity.”, dan bukti itu mendukung “Donating food is optional, not compulsory.”, bukan opsi ini.
- **D. Everyone must donate food.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Everyone must donate food.”. Bukti yang menjawab pertanyaan adalah “You do not have to donate food to join the sorting activity.”, dan bukti itu mendukung “Donating food is optional, not compulsory.”, bukan opsi ini.

---

### W10S2-Q08 — vocabulary_meaning (easy)
**Stimulus:** W10S2-T2

**Question:** Which phrase is closest in meaning to “although”?

- **A.** As a result
- **B.** Even though
- **C.** Because of
- **D.** Only if

**Jawaban:** B. Even though

**Pembahasan:** Although bermakna meskipun dan memperkenalkan kontras atau keadaan yang tidak menghalangi klausa utama.

**Bukti teks:** “Although the library was quiet, a few students preferred to work at home.”

**Alasan setiap opsi:**
- **A. As a result** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “As a result”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “Even though”, bukan opsi ini.
- **B. Even though** — Benar. Although bermakna meskipun dan memperkenalkan kontras atau keadaan yang tidak menghalangi klausa utama. Bukti teks: “Although the library was quiet, a few students preferred to work at home.”
- **C. Because of** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because of”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “Even though”, bukan opsi ini.
- **D. Only if** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Only if”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “Even though”, bukan opsi ini.

---

### W10S2-Q09 — vocabulary_meaning (easy)
**Stimulus:** W10S2-T2

**Question:** What is the closest meaning of “however” in a reading passage?

- **A.** For this reason
- **B.** In addition
- **C.** On the other hand
- **D.** At the same time

**Jawaban:** C. On the other hand

**Pembahasan:** However biasanya menunjukkan kontras atau perbedaan dengan gagasan sebelumnya.

**Bukti teks:** “Although the library was quiet, a few students preferred to work at home.”

**Alasan setiap opsi:**
- **A. For this reason** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “For this reason”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “On the other hand”, bukan opsi ini.
- **B. In addition** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “In addition”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “On the other hand”, bukan opsi ini.
- **C. On the other hand** — Benar. However biasanya menunjukkan kontras atau perbedaan dengan gagasan sebelumnya. Bukti teks: “Although the library was quiet, a few students preferred to work at home.”
- **D. At the same time** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At the same time”. Bukti yang menjawab pertanyaan adalah “Although the library was quiet, a few students preferred to work at home.”, dan bukti itu mendukung “On the other hand”, bukan opsi ini.

---

### W10S2-Q10 — contextual_synonym (developing)
**Stimulus:** W10S2-T1

**Question:** Which phrase can replace “therefore” without changing the result relationship?

- **A.** At first
- **B.** In contrast
- **C.** For example
- **D.** As a result

**Jawaban:** D. As a result

**Pembahasan:** As a result menyatakan akibat sebagaimana therefore.

**Bukti teks:** “therefore, late deliveries may not be included in the first distribution.”

**Alasan setiap opsi:**
- **A. At first** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At first”. Bukti yang menjawab pertanyaan adalah “therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “As a result”, bukan opsi ini.
- **B. In contrast** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “In contrast”. Bukti yang menjawab pertanyaan adalah “therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “As a result”, bukan opsi ini.
- **C. For example** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “For example”. Bukti yang menjawab pertanyaan adalah “therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “As a result”, bukan opsi ini.
- **D. As a result** — Benar. As a result menyatakan akibat sebagaimana therefore. Bukti teks: “therefore, late deliveries may not be included in the first distribution.”

---

### W10S2-Q11 — vocabulary_meaning (medium)
**Stimulus:** W10S2-T1

**Question:** In the sentence “You cannot enter unless a guide is present,” what does “unless” mean?

- **A.** Even though a guide is present
- **B.** Because a guide is present
- **C.** If a guide is not present
- **D.** Because a guide is present

**Jawaban:** C. If a guide is not present

**Pembahasan:** Unless berarti if not. Dalam kalimat ini, pengunjung tidak boleh masuk jika guru tidak hadir; kehadiran guru menjadi syarat pengecualian.

**Bukti teks:** “Visitors may not enter the storage area unless a teacher is present.”

**Alasan setiap opsi:**
- **A. Even though a guide is present** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Even though a guide is present”. Bukti yang menjawab pertanyaan adalah “Visitors may not enter the storage area unless a teacher is present.”, dan bukti itu mendukung “If a guide is not present”, bukan opsi ini.
- **B. Because a guide is present** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because a guide is present”. Bukti yang menjawab pertanyaan adalah “Visitors may not enter the storage area unless a teacher is present.”, dan bukti itu mendukung “If a guide is not present”, bukan opsi ini.
- **C. If a guide is not present** — Benar. Unless berarti if not. Dalam kalimat ini, pengunjung tidak boleh masuk jika guru tidak hadir; kehadiran guru menjadi syarat pengecualian. Bukti teks: “Visitors may not enter the storage area unless a teacher is present.”
- **D. Because a guide is present** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because a guide is present”. Bukti yang menjawab pertanyaan adalah “Visitors may not enter the storage area unless a teacher is present.”, dan bukti itu mendukung “If a guide is not present”, bukan opsi ini.

---

### W10S2-Q12 — connector_application (medium)
**Stimulus:** W10S2-T1

**Question:** In the sentence “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution,” what relationship does “therefore” show?

- **A.** A condition that must be met before an action
- **B.** A result that follows from the information before it
- **C.** A sequence that tells which event happens first
- **D.** A contrast between two different opinions

**Jawaban:** B. A result that follows from the information before it

**Pembahasan:** Therefore memperkenalkan hasil: karena paket disortir pada Kamis, pengiriman terlambat mungkin tidak masuk distribusi pertama.

**Bukti teks:** “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”

**Alasan setiap opsi:**
- **A. A condition that must be met before an action** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A condition that must be met before an action”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A result that follows from the information before it”, bukan opsi ini.
- **B. A result that follows from the information before it** — Benar. Therefore memperkenalkan hasil: karena paket disortir pada Kamis, pengiriman terlambat mungkin tidak masuk distribusi pertama. Bukti teks: “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”
- **C. A sequence that tells which event happens first** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A sequence that tells which event happens first”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A result that follows from the information before it”, bukan opsi ini.
- **D. A contrast between two different opinions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A contrast between two different opinions”. Bukti yang menjawab pertanyaan adalah “Volunteers will sort the packages on Thursday; therefore, late deliveries may not be included in the first distribution.”, dan bukti itu mendukung “A result that follows from the information before it”, bukan opsi ini.

---

# W11-ONLINE-01 — Integrated Reading: Combining Main Ideas, Details and Evidence
**Week:** 11 · **Questions:** 12 · **Difficulty:** Easy 2 / Developing 5 / Medium 5

## Stimuli

### W11S1-T1 — A Community Reading Festival (Informational article; 123 words)

```text
A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books. At the opening, visitors can explore a small book exhibition. Later, local volunteers lead short reading circles for children and families. A repair desk also shows visitors how to mend loose pages and covers instead of throwing books away. The organisers say that the festival is not only about collecting books; it is also about making reading social and keeping useful books in circulation. The programme includes quiet activities and group discussions, so visitors can choose a session that suits them. This arrangement helps visitors plan a route between the different areas. Visitors can ask volunteers for directions if they are unsure where to go.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W11S1-T2 — Festival Programme (Programme / functional text; 128 words)

```text
COMMUNITY READING FESTIVAL
9:00–9:30 — Welcome and book exhibition (Main Hall)
9:40–10:10 — Family reading circle (Room A)
10:20–10:50 — Book repair demonstration (Room B)
11:00–11:30 — Young readers' discussion (Room A)
The organisers designed the programme to combine quiet activities and group discussions. Volunteers verify the room signs before visitors arrive. The printed schedule must remain consistent with the signs at each room. Visitors should check the room signs in case a room assignment changes. The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses. Please arrive five minutes before a session. Visitors may attend more than one activity, but each room has limited seating. The repair demonstration uses sample books; visitors should not bring damaged personal books to the table.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **combine** (verb; NEW) — menggabungkan beberapa bagian menjadi satu. *Example:* Readers combine details from two paragraphs. *Synonym/related:* join, put together. *Contrast:* separate, divide.
- **verify** (verb; NEW) — memeriksa untuk memastikan kebenaran. *Example:* Please verify the room number before leaving. *Synonym/related:* check, confirm. *Contrast:* assume, guess.
- **consistent** (adjective; NEW) — selaras; tidak saling bertentangan. *Example:* The two notices give consistent information. *Synonym/related:* compatible, in agreement. *Contrast:* inconsistent, conflicting.
- **evidence-based** (adjective; NEW) — berdasarkan bukti, bukan sekadar dugaan. *Example:* The report gives an evidence-based explanation. *Synonym/related:* supported by evidence. *Contrast:* unsupported, speculative.
- **overview** (noun; RECYCLED) — gambaran umum. *Example:* The overview introduces the report. *Synonym/related:* general outline. *Contrast:* detail (contrast).
- **summary** (noun; RECYCLED) — ringkasan. *Example:* The summary gives the main points. *Synonym/related:* brief account. *Contrast:* full account.
- **relevant** (adjective; RECYCLED) — berkaitan. *Example:* Choose relevant details. *Synonym/related:* related, applicable. *Contrast:* irrelevant.
- **purpose** (noun; RECYCLED) — tujuan. *Example:* The purpose is to share information. *Synonym/related:* aim, intention. *Contrast:* —.
- **detail** (noun; RECYCLED) — rincian. *Example:* One detail supports the main idea. *Synonym/related:* fact, specific point. *Contrast:* overview (contrast).
- **likely** (adjective/adverb; RECYCLED) — mungkin besar. *Example:* The result is likely to change. *Synonym/related:* probably, probable. *Contrast:* unlikely.

## Answer key and explanations

### W11S1-Q01 — main_purpose (easy)
**Stimulus:** W11S1-T1

**Question:** What is the main purpose of the community reading festival?

- **A.** To help people enjoy books through several shared activities
- **B.** To replace quiet reading with group discussion
- **C.** To train volunteers to build a new library
- **D.** To sell every book in the town

**Jawaban:** A. To help people enjoy books through several shared activities

**Pembahasan:** Kalimat pembuka menyatakan tujuan bersama festival: membantu masyarakat menikmati dan mendiskusikan buku melalui beberapa kegiatan.

**Bukti teks:** “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”

**Alasan setiap opsi:**
- **A. To help people enjoy books through several shared activities** — Benar. Kalimat pembuka menyatakan tujuan bersama festival: membantu masyarakat menikmati dan mendiskusikan buku melalui beberapa kegiatan. Bukti teks: “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”
- **B. To replace quiet reading with group discussion** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To replace quiet reading with group discussion”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “To help people enjoy books through several shared activities”, bukan opsi ini.
- **C. To train volunteers to build a new library** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To train volunteers to build a new library”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “To help people enjoy books through several shared activities”, bukan opsi ini.
- **D. To sell every book in the town** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To sell every book in the town”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “To help people enjoy books through several shared activities”, bukan opsi ini.

---

### W11S1-Q02 — explicit_detail (easy)
**Stimulus:** W11S1-T2

**Question:** Where does the book repair demonstration take place?

- **A.** Visitor Centre
- **B.** Main Hall
- **C.** Room B
- **D.** Room A

**Jawaban:** C. Room B

**Pembahasan:** Jadwal secara langsung menempatkan demonstrasi perbaikan buku di Room B.

**Bukti teks:** “10:20–10:50 — Book repair demonstration (Room B)”

**Alasan setiap opsi:**
- **A. Visitor Centre** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Visitor Centre”. Bukti yang menjawab pertanyaan adalah “10:20–10:50 — Book repair demonstration (Room B)”, dan bukti itu mendukung “Room B”, bukan opsi ini.
- **B. Main Hall** — Tidak tepat. Detail “Main Hall” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “10:20–10:50 — Book repair demonstration (Room B)”, yang mendukung “Room B”.
- **C. Room B** — Benar. Jadwal secara langsung menempatkan demonstrasi perbaikan buku di Room B. Bukti teks: “10:20–10:50 — Book repair demonstration (Room B)”
- **D. Room A** — Tidak tepat. Detail “Room A” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “10:20–10:50 — Book repair demonstration (Room B)”, yang mendukung “Room B”.

---

### W11S1-Q03 — sequence (developing)
**Stimulus:** W11S1-T2

**Question:** What is the next scheduled activity after the family reading circle?

- **A.** The festival closing
- **B.** Book repair demonstration
- **C.** Young readers' discussion
- **D.** Welcome and book exhibition

**Jawaban:** B. Book repair demonstration

**Pembahasan:** Kegiatan setelah reading circle adalah demonstrasi perbaikan buku.

**Bukti teks:** “9:40–10:10 — Family reading circle”; “10:20–10:50 — Book repair demonstration”

**Alasan setiap opsi:**
- **A. The festival closing** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The festival closing”. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle”; “10:20–10:50 — Book repair demonstration”, dan bukti itu mendukung “Book repair demonstration”, bukan opsi ini.
- **B. Book repair demonstration** — Benar. Kegiatan setelah reading circle adalah demonstrasi perbaikan buku. Bukti teks: “9:40–10:10 — Family reading circle”; “10:20–10:50 — Book repair demonstration”
- **C. Young readers' discussion** — Tidak tepat. Detail “Young readers' discussion” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle”; “10:20–10:50 — Book repair demonstration”, yang mendukung “Book repair demonstration”.
- **D. Welcome and book exhibition** — Tidak tepat. Detail “Welcome and book exhibition” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle”; “10:20–10:50 — Book repair demonstration”, yang mendukung “Book repair demonstration”.

---

### W11S1-Q04 — cross_text_support (developing)
**Stimulus:** W11S1-T1, W11S1-T2

**Question:** Which detail in the programme shows that visitors can choose between different kinds of activities?

- **A.** Visitors must attend every activity.
- **B.** The book repair desk is closed all day.
- **C.** The festival has only one room.
- **D.** It lists a family reading circle and a young readers’ discussion.

**Jawaban:** D. It lists a family reading circle and a young readers’ discussion.

**Pembahasan:** Jadwal menampilkan family reading circle dan young readers’ discussion. Dua jenis kegiatan ini mendukung keterangan artikel bahwa pengunjung dapat memilih kegiatan yang sesuai.

**Bukti teks:** “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”

**Alasan setiap opsi:**
- **A. Visitors must attend every activity.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Visitors must attend every activity.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “It lists a family reading circle and a young readers’ discussion.”, bukan opsi ini.
- **B. The book repair desk is closed all day.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The book repair desk is closed all day.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “It lists a family reading circle and a young readers’ discussion.”, bukan opsi ini.
- **C. The festival has only one room.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The festival has only one room.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “It lists a family reading circle and a young readers’ discussion.”, bukan opsi ini.
- **D. It lists a family reading circle and a young readers’ discussion.** — Benar. Jadwal menampilkan family reading circle dan young readers’ discussion. Dua jenis kegiatan ini mendukung keterangan artikel bahwa pengunjung dapat memilih kegiatan yang sesuai. Bukti teks: “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”

---

### W11S1-Q05 — reference_tracking (medium)
**Stimulus:** W11S1-T1

**Question:** What does “This arrangement” refer to in the article?

- **A.** A rule that every visitor must buy a book
- **B.** A decision to close the exhibition
- **C.** A list of books that cannot be repaired
- **D.** A plan that connects several festival activities and lets visitors choose a session

**Jawaban:** D. A plan that connects several festival activities and lets visitors choose a session

**Pembahasan:** Dalam konteks artikel, arrangement merujuk pada penyusunan program dengan kegiatan yang berbeda sehingga pengunjung dapat memilih sesi yang cocok.

**Bukti teks:** “This arrangement helps visitors plan a route between the different areas.”

**Alasan setiap opsi:**
- **A. A rule that every visitor must buy a book** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A rule that every visitor must buy a book”. Bukti yang menjawab pertanyaan adalah “This arrangement helps visitors plan a route between the different areas.”, dan bukti itu mendukung “A plan that connects several festival activities and lets visitors choose a session”, bukan opsi ini.
- **B. A decision to close the exhibition** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A decision to close the exhibition”. Bukti yang menjawab pertanyaan adalah “This arrangement helps visitors plan a route between the different areas.”, dan bukti itu mendukung “A plan that connects several festival activities and lets visitors choose a session”, bukan opsi ini.
- **C. A list of books that cannot be repaired** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A list of books that cannot be repaired”. Bukti yang menjawab pertanyaan adalah “This arrangement helps visitors plan a route between the different areas.”, dan bukti itu mendukung “A plan that connects several festival activities and lets visitors choose a session”, bukan opsi ini.
- **D. A plan that connects several festival activities and lets visitors choose a session** — Benar. Dalam konteks artikel, arrangement merujuk pada penyusunan program dengan kegiatan yang berbeda sehingga pengunjung dapat memilih sesi yang cocok. Bukti teks: “This arrangement helps visitors plan a route between the different areas.”

---

### W11S1-Q06 — cross_text_application (medium)
**Stimulus:** W11S1-T2

**Question:** Which visitor should arrive before 9:40 a.m. to attend the family reading circle?

- **A.** A visitor attending the family reading circle
- **B.** A visitor going to the book exhibition only
- **C.** A visitor attending the repair demonstration
- **D.** A visitor attending the young readers' discussion

**Jawaban:** A. A visitor attending the family reading circle

**Pembahasan:** Sesi mulai 9:40, jadi pengunjung harus tiba lima menit sebelumnya, yaitu 9:35.

**Bukti teks:** “9:40–10:10 — Family reading circle (Room A)”; “Please arrive five minutes before a session.”

**Alasan setiap opsi:**
- **A. A visitor attending the family reading circle** — Benar. Sesi mulai 9:40, jadi pengunjung harus tiba lima menit sebelumnya, yaitu 9:35. Bukti teks: “9:40–10:10 — Family reading circle (Room A)”; “Please arrive five minutes before a session.”
- **B. A visitor going to the book exhibition only** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A visitor going to the book exhibition only”. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle (Room A)”; “Please arrive five minutes before a session.”, dan bukti itu mendukung “A visitor attending the family reading circle”, bukan opsi ini.
- **C. A visitor attending the repair demonstration** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A visitor attending the repair demonstration”. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle (Room A)”; “Please arrive five minutes before a session.”, dan bukti itu mendukung “A visitor attending the family reading circle”, bukan opsi ini.
- **D. A visitor attending the young readers' discussion** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A visitor attending the young readers' discussion”. Bukti yang menjawab pertanyaan adalah “9:40–10:10 — Family reading circle (Room A)”; “Please arrive five minutes before a session.”, dan bukti itu mendukung “A visitor attending the family reading circle”, bukan opsi ini.

---

### W11S1-Q07 — inference_with_evidence (medium)
**Stimulus:** W11S1-T2

**Question:** Why should visitors check the room signs even after reading the printed programme?

- **A.** The signs may help confirm the current room information.
- **B.** The signs replace the festival activities.
- **C.** All rooms are always changed.
- **D.** The programme never lists any rooms.

**Jawaban:** A. The signs may help confirm the current room information.

**Pembahasan:** Memeriksa tanda ruang membantu memastikan lokasi sebelum masuk, terutama karena jadwal beberapa kegiatan berlangsung di ruang berbeda.

**Bukti teks:** “Visitors should check the room signs in case a room assignment changes.”

**Alasan setiap opsi:**
- **A. The signs may help confirm the current room information.** — Benar. Memeriksa tanda ruang membantu memastikan lokasi sebelum masuk, terutama karena jadwal beberapa kegiatan berlangsung di ruang berbeda. Bukti teks: “Visitors should check the room signs in case a room assignment changes.”
- **B. The signs replace the festival activities.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The signs replace the festival activities.”. Bukti yang menjawab pertanyaan adalah “Visitors should check the room signs in case a room assignment changes.”, dan bukti itu mendukung “The signs may help confirm the current room information.”, bukan opsi ini.
- **C. All rooms are always changed.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “All rooms are always changed.”. Bukti yang menjawab pertanyaan adalah “Visitors should check the room signs in case a room assignment changes.”, dan bukti itu mendukung “The signs may help confirm the current room information.”, bukan opsi ini.
- **D. The programme never lists any rooms.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The programme never lists any rooms.”. Bukti yang menjawab pertanyaan adalah “Visitors should check the room signs in case a room assignment changes.”, dan bukti itu mendukung “The signs may help confirm the current room information.”, bukan opsi ini.

---

### W11S1-Q08 — vocabulary_meaning (developing)
**Stimulus:** W11S1-T1

**Question:** What does “combine” mean?

- **A.** Delay until later
- **B.** Remove completely
- **C.** Put together
- **D.** Keep separate

**Jawaban:** C. Put together

**Pembahasan:** Combine berarti menggabungkan beberapa bagian menjadi satu.

**Bukti teks:** “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”

**Alasan setiap opsi:**
- **A. Delay until later** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Delay until later”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “Put together”, bukan opsi ini.
- **B. Remove completely** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove completely”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “Put together”, bukan opsi ini.
- **C. Put together** — Benar. Combine berarti menggabungkan beberapa bagian menjadi satu. Bukti teks: “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”
- **D. Keep separate** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Keep separate”. Bukti yang menjawab pertanyaan adalah “A community reading festival connects several activities that support one shared goal: helping people enjoy and discuss books.”, dan bukti itu mendukung “Put together”, bukan opsi ini.

---

### W11S1-Q09 — vocabulary_meaning (developing)
**Stimulus:** W11S1-T2

**Question:** Which verb is closest in meaning to “verify”?

- **A.** Assume
- **B.** Confirm
- **C.** Divide
- **D.** Forget

**Jawaban:** B. Confirm

**Pembahasan:** Verify berarti memeriksa untuk memastikan kebenaran; confirm adalah padanan dekat dalam konteks ini.

**Bukti teks:** “Volunteers verify the room signs before visitors arrive.”

**Alasan setiap opsi:**
- **A. Assume** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Assume”. Bukti yang menjawab pertanyaan adalah “Volunteers verify the room signs before visitors arrive.”, dan bukti itu mendukung “Confirm”, bukan opsi ini.
- **B. Confirm** — Benar. Verify berarti memeriksa untuk memastikan kebenaran; confirm adalah padanan dekat dalam konteks ini. Bukti teks: “Volunteers verify the room signs before visitors arrive.”
- **C. Divide** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Divide”. Bukti yang menjawab pertanyaan adalah “Volunteers verify the room signs before visitors arrive.”, dan bukti itu mendukung “Confirm”, bukan opsi ini.
- **D. Forget** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Forget”. Bukti yang menjawab pertanyaan adalah “Volunteers verify the room signs before visitors arrive.”, dan bukti itu mendukung “Confirm”, bukan opsi ini.

---

### W11S1-Q10 — vocabulary_meaning (developing)
**Stimulus:** W11S1-T2

**Question:** If two schedules are “consistent,” what is true about them?

- **A.** They are written by the same person.
- **B.** They contain completely different times.
- **C.** They are difficult to read.
- **D.** They give information that agrees with each other.

**Jawaban:** D. They give information that agrees with each other.

**Pembahasan:** Consistent berarti selaras dan tidak saling bertentangan.

**Bukti teks:** “The printed schedule must remain consistent with the signs at each room.”

**Alasan setiap opsi:**
- **A. They are written by the same person.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They are written by the same person.”. Bukti yang menjawab pertanyaan adalah “The printed schedule must remain consistent with the signs at each room.”, dan bukti itu mendukung “They give information that agrees with each other.”, bukan opsi ini.
- **B. They contain completely different times.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They contain completely different times.”. Bukti yang menjawab pertanyaan adalah “The printed schedule must remain consistent with the signs at each room.”, dan bukti itu mendukung “They give information that agrees with each other.”, bukan opsi ini.
- **C. They are difficult to read.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They are difficult to read.”. Bukti yang menjawab pertanyaan adalah “The printed schedule must remain consistent with the signs at each room.”, dan bukti itu mendukung “They give information that agrees with each other.”, bukan opsi ini.
- **D. They give information that agrees with each other.** — Benar. Consistent berarti selaras dan tidak saling bertentangan. Bukti teks: “The printed schedule must remain consistent with the signs at each room.”

---

### W11S1-Q11 — vocabulary_meaning (medium)
**Stimulus:** W11S1-T2

**Question:** What does “evidence-based” mean in the passage?

- **A.** Designed to entertain visitors
- **B.** Based only on personal feelings
- **C.** Based on confirmed information rather than guesses
- **D.** Written before any details are checked

**Jawaban:** C. Based on confirmed information rather than guesses

**Pembahasan:** Evidence-based berarti berdasarkan bukti atau informasi yang sudah dikonfirmasi, bukan dugaan.

**Bukti teks:** “The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses.”

**Alasan setiap opsi:**
- **A. Designed to entertain visitors** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Designed to entertain visitors”. Bukti yang menjawab pertanyaan adalah “The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses.”, dan bukti itu mendukung “Based on confirmed information rather than guesses”, bukan opsi ini.
- **B. Based only on personal feelings** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Based only on personal feelings”. Bukti yang menjawab pertanyaan adalah “The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses.”, dan bukti itu mendukung “Based on confirmed information rather than guesses”, bukan opsi ini.
- **C. Based on confirmed information rather than guesses** — Benar. Evidence-based berarti berdasarkan bukti atau informasi yang sudah dikonfirmasi, bukan dugaan. Bukti teks: “The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses.”
- **D. Written before any details are checked** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Written before any details are checked”. Bukti yang menjawab pertanyaan adalah “The organisers describe the guide as evidence-based because it uses the confirmed programme rather than guesses.”, dan bukti itu mendukung “Based on confirmed information rather than guesses”, bukan opsi ini.

---

### W11S1-Q12 — integrated_strategy (medium)
**Stimulus:** W11S1-T1, W11S1-T2

**Question:** You must answer a question that connects the festival article with its schedule. What is the best strategy?

- **A.** Choose the option with the most familiar word.
- **B.** Read the question, locate the relevant activity in the schedule, then compare it with the article.
- **C.** Ignore one of the two texts.
- **D.** Use only the first sentence of the article.

**Jawaban:** B. Read the question, locate the relevant activity in the schedule, then compare it with the article.

**Pembahasan:** Pertanyaan lintas teks membutuhkan penggabungan informasi dari kedua sumber, bukan hanya mengambil satu frasa.

**Bukti teks:** “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”

**Alasan setiap opsi:**
- **A. Choose the option with the most familiar word.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the option with the most familiar word.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “Read the question, locate the relevant activity in the schedule, then compare it with the article.”, bukan opsi ini.
- **B. Read the question, locate the relevant activity in the schedule, then compare it with the article.** — Benar. Pertanyaan lintas teks membutuhkan penggabungan informasi dari kedua sumber, bukan hanya mengambil satu frasa. Bukti teks: “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”
- **C. Ignore one of the two texts.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore one of the two texts.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “Read the question, locate the relevant activity in the schedule, then compare it with the article.”, bukan opsi ini.
- **D. Use only the first sentence of the article.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use only the first sentence of the article.”. Bukti yang menjawab pertanyaan adalah “The programme includes quiet activities and group discussions, so visitors can choose a session that suits them.”; “9:40–10:10 — Family reading circle (Room A)”; “11:00–11:30 — Young readers' discussion (Room A)”, dan bukti itu mendukung “Read the question, locate the relevant activity in the schedule, then compare it with the article.”, bukan opsi ini.

---

# W11-ONLINE-02 — Integrated Reading: Comparing Texts and Verifying Meaning
**Week:** 11 · **Questions:** 12 · **Difficulty:** Easy 2 / Developing 4 / Medium 6

## Stimuli

### W11S2-T1 — Two Messages About a School Exhibition (Paired messages; 90 words)

```text
MESSAGE FROM THE ART CLUB
The exhibition will open on Tuesday at 1:00 p.m. in the school hall. The paintings will remain on display until Thursday afternoon. Please place your work on the labelled tables before Monday's final class.
MESSAGE FROM THE LIBRARY TEAM
The hall will be used for the art exhibition from Tuesday to Thursday. The library's regular reading corner will remain open, but the large group tables will be unavailable during that period. Students who need to work together may use Room 6 after asking the librarian.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W11S2-T2 — How the Teams Coordinated (Informational report; 101 words)

```text
The art club and library team compared their schedules before the exhibition began. They synthesized details from both messages into one coherent plan. They checked room labels to verify that the information was consistent. The teams then evaluated two options: close the whole library or move group study activities to Room 6. They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time. Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

## Vocabulary cards

- **synthesize** (verb; NEW) — menyatukan beberapa informasi menjadi pemahaman/ringkasan baru. *Example:* Students synthesize ideas from two short texts. *Synonym/related:* integrate, bring together. *Contrast:* separate, fragment.
- **coherent** (adjective; NEW) — runtut dan saling berhubungan secara masuk akal. *Example:* A coherent summary presents ideas in a clear order. *Synonym/related:* logical, connected. *Contrast:* confusing, disconnected.
- **compare** (verb; NEW) — membandingkan. *Example:* Compare the two accounts. *Synonym/related:* examine side by side. *Contrast:* —.
- **evaluate** (verb; NEW) — menilai berdasarkan kriteria atau bukti. *Example:* Readers evaluate whether an option is supported. *Synonym/related:* assess, judge. *Contrast:* accept uncritically.
- **combine** (verb; RECYCLED) — menggabungkan beberapa bagian menjadi satu. *Example:* Readers combine details from two paragraphs. *Synonym/related:* join, put together. *Contrast:* separate, divide.
- **verify** (verb; RECYCLED) — memeriksa untuk memastikan kebenaran. *Example:* Please verify the room number before leaving. *Synonym/related:* check, confirm. *Contrast:* assume, guess.
- **consistent** (adjective; RECYCLED) — selaras; tidak saling bertentangan. *Example:* The two notices give consistent information. *Synonym/related:* compatible, in agreement. *Contrast:* inconsistent, conflicting.
- **evidence-based** (adjective; RECYCLED) — berdasarkan bukti, bukan sekadar dugaan. *Example:* The report gives an evidence-based explanation. *Synonym/related:* supported by evidence. *Contrast:* unsupported, speculative.
- **main idea** (noun phrase; RECYCLED) — gagasan utama. *Example:* The main idea connects the paragraphs. *Synonym/related:* central point. *Contrast:* minor detail (contrast).
- **record** (verb/noun; RECYCLED) — mencatat; catatan. *Example:* The group records the results. *Synonym/related:* write down, note. *Contrast:* —.

## Answer key and explanations

### W11S2-Q01 — explicit_detail (easy)
**Stimulus:** W11S2-T1

**Question:** Which days will the art exhibition use the school hall?

- **A.** Tuesday to Thursday
- **B.** Wednesday to Friday
- **C.** Monday to Tuesday
- **D.** Friday to Sunday

**Jawaban:** A. Tuesday to Thursday

**Pembahasan:** Pesan tim perpustakaan menyatakan penggunaan aula dari Selasa sampai Kamis.

**Bukti teks:** “The hall will be used for the art exhibition from Tuesday to Thursday.”

**Alasan setiap opsi:**
- **A. Tuesday to Thursday** — Benar. Pesan tim perpustakaan menyatakan penggunaan aula dari Selasa sampai Kamis. Bukti teks: “The hall will be used for the art exhibition from Tuesday to Thursday.”
- **B. Wednesday to Friday** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Wednesday to Friday”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “Tuesday to Thursday”, bukan opsi ini.
- **C. Monday to Tuesday** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Monday to Tuesday”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “Tuesday to Thursday”, bukan opsi ini.
- **D. Friday to Sunday** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Friday to Sunday”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “Tuesday to Thursday”, bukan opsi ini.

---

### W11S2-Q02 — explicit_detail (developing)
**Stimulus:** W11S2-T1

**Question:** Where can students work together while the hall is being used?

- **A.** The reading corner
- **B.** The large group tables
- **C.** The school hall
- **D.** Room 6

**Jawaban:** D. Room 6

**Pembahasan:** Room 6 disediakan untuk kegiatan kelompok setelah siswa meminta izin kepada pustakawan.

**Bukti teks:** “Students who need to work together may use Room 6 after asking the librarian.”

**Alasan setiap opsi:**
- **A. The reading corner** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The reading corner”. Bukti yang menjawab pertanyaan adalah “Students who need to work together may use Room 6 after asking the librarian.”, dan bukti itu mendukung “Room 6”, bukan opsi ini.
- **B. The large group tables** — Tidak tepat. Detail “The large group tables” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Students who need to work together may use Room 6 after asking the librarian.”, yang mendukung “Room 6”.
- **C. The school hall** — Tidak tepat. Detail “The school hall” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Students who need to work together may use Room 6 after asking the librarian.”, yang mendukung “Room 6”.
- **D. Room 6** — Benar. Room 6 disediakan untuk kegiatan kelompok setelah siswa meminta izin kepada pustakawan. Bukti teks: “Students who need to work together may use Room 6 after asking the librarian.”

---

### W11S2-Q03 — cause_effect (developing)
**Stimulus:** W11S2-T2, W11S2-T1

**Question:** Why did the teams agree to move group study activities?

- **A.** The library closed for the whole week.
- **B.** The hall would be busy for three days.
- **C.** The reading corner was removed.
- **D.** The art club cancelled its exhibition.

**Jawaban:** B. The hall would be busy for three days.

**Pembahasan:** Aula digunakan untuk pameran selama tiga hari, sehingga kegiatan kelompok dipindahkan.

**Bukti teks:** “The hall will be used for the art exhibition from Tuesday to Thursday.”; “They agreed on the second option because the reading corner was in a separate part of the building.”

**Alasan setiap opsi:**
- **A. The library closed for the whole week.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library closed for the whole week.”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”; “They agreed on the second option because the reading corner was in a separate part of the building.”, dan bukti itu mendukung “The hall would be busy for three days.”, bukan opsi ini.
- **B. The hall would be busy for three days.** — Benar. Aula digunakan untuk pameran selama tiga hari, sehingga kegiatan kelompok dipindahkan. Bukti teks: “The hall will be used for the art exhibition from Tuesday to Thursday.”; “They agreed on the second option because the reading corner was in a separate part of the building.”
- **C. The reading corner was removed.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The reading corner was removed.”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”; “They agreed on the second option because the reading corner was in a separate part of the building.”, dan bukti itu mendukung “The hall would be busy for three days.”, bukan opsi ini.
- **D. The art club cancelled its exhibition.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The art club cancelled its exhibition.”. Bukti yang menjawab pertanyaan adalah “The hall will be used for the art exhibition from Tuesday to Thursday.”; “They agreed on the second option because the reading corner was in a separate part of the building.”, dan bukti itu mendukung “The hall would be busy for three days.”, bukan opsi ini.

---

### W11S2-Q04 — reference_tracking (developing)
**Stimulus:** W11S2-T2

**Question:** What does “This arrangement” refer to in the report?

- **A.** Removing all group tables permanently
- **B.** Closing the whole library
- **C.** Moving group study to Room 6 while keeping the reading corner open
- **D.** Cancelling the art exhibition

**Jawaban:** C. Moving group study to Room 6 while keeping the reading corner open

**Pembahasan:** This arrangement merujuk pada keputusan memindahkan belajar kelompok tetapi tetap membuka sudut baca.

**Bukti teks:** “They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time.”

**Alasan setiap opsi:**
- **A. Removing all group tables permanently** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Removing all group tables permanently”. Bukti yang menjawab pertanyaan adalah “They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time.”, dan bukti itu mendukung “Moving group study to Room 6 while keeping the reading corner open”, bukan opsi ini.
- **B. Closing the whole library** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Closing the whole library”. Bukti yang menjawab pertanyaan adalah “They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time.”, dan bukti itu mendukung “Moving group study to Room 6 while keeping the reading corner open”, bukan opsi ini.
- **C. Moving group study to Room 6 while keeping the reading corner open** — Benar. This arrangement merujuk pada keputusan memindahkan belajar kelompok tetapi tetap membuka sudut baca. Bukti teks: “They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time.”
- **D. Cancelling the art exhibition** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Cancelling the art exhibition”. Bukti yang menjawab pertanyaan adalah “They agreed on the second option because the reading corner was in a separate part of the building. This arrangement allowed the exhibition and quiet reading to continue at the same time.”, dan bukti itu mendukung “Moving group study to Room 6 while keeping the reading corner open”, bukan opsi ini.

---

### W11S2-Q05 — cross_text_comparison (medium)
**Stimulus:** W11S2-T1

**Question:** Which statement is supported by BOTH messages?

- **A.** The library will close completely during the exhibition.
- **B.** Room 6 will be used for the exhibition.
- **C.** The exhibition will be in the school hall from Tuesday to Thursday.
- **D.** The art works must be placed on Tuesday morning.

**Jawaban:** C. The exhibition will be in the school hall from Tuesday to Thursday.

**Pembahasan:** Kedua pesan sama-sama menyatakan pameran menggunakan aula, dengan pesan kedua memperjelas rentang hari.

**Bukti teks:** “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”

**Alasan setiap opsi:**
- **A. The library will close completely during the exhibition.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The library will close completely during the exhibition.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “The exhibition will be in the school hall from Tuesday to Thursday.”, bukan opsi ini.
- **B. Room 6 will be used for the exhibition.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Room 6 will be used for the exhibition.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “The exhibition will be in the school hall from Tuesday to Thursday.”, bukan opsi ini.
- **C. The exhibition will be in the school hall from Tuesday to Thursday.** — Benar. Kedua pesan sama-sama menyatakan pameran menggunakan aula, dengan pesan kedua memperjelas rentang hari. Bukti teks: “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”
- **D. The art works must be placed on Tuesday morning.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The art works must be placed on Tuesday morning.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”, dan bukti itu mendukung “The exhibition will be in the school hall from Tuesday to Thursday.”, bukan opsi ini.

---

### W11S2-Q06 — inference_with_evidence (medium)
**Stimulus:** W11S2-T1

**Question:** Which conclusion is most reasonable about the library during the exhibition?

- **A.** Students cannot enter the building.
- **B.** All books will be moved to the hall.
- **C.** Every library service will stop.
- **D.** Quiet reading can continue, but group work needs another room.

**Jawaban:** D. Quiet reading can continue, but group work needs another room.

**Pembahasan:** Teks menyatakan sudut baca tetap buka, sedangkan meja kelompok tidak tersedia; kesimpulan yang tepat adalah membaca tenang tetap bisa dilakukan tetapi kerja kelompok perlu tempat lain.

**Bukti teks:** “The library's regular reading corner will remain open, but the large group tables will be unavailable during that period.”

**Alasan setiap opsi:**
- **A. Students cannot enter the building.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students cannot enter the building.”. Bukti yang menjawab pertanyaan adalah “The library's regular reading corner will remain open, but the large group tables will be unavailable during that period.”, dan bukti itu mendukung “Quiet reading can continue, but group work needs another room.”, bukan opsi ini.
- **B. All books will be moved to the hall.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “All books will be moved to the hall.”. Bukti yang menjawab pertanyaan adalah “The library's regular reading corner will remain open, but the large group tables will be unavailable during that period.”, dan bukti itu mendukung “Quiet reading can continue, but group work needs another room.”, bukan opsi ini.
- **C. Every library service will stop.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Every library service will stop.”. Bukti yang menjawab pertanyaan adalah “The library's regular reading corner will remain open, but the large group tables will be unavailable during that period.”, dan bukti itu mendukung “Quiet reading can continue, but group work needs another room.”, bukan opsi ini.
- **D. Quiet reading can continue, but group work needs another room.** — Benar. Teks menyatakan sudut baca tetap buka, sedangkan meja kelompok tidak tersedia; kesimpulan yang tepat adalah membaca tenang tetap bisa dilakukan tetapi kerja kelompok perlu tempat lain. Bukti teks: “The library's regular reading corner will remain open, but the large group tables will be unavailable during that period.”

---

### W11S2-Q07 — evidence_check (medium)
**Stimulus:** W11S2-T2

**Question:** Which action helped the teams avoid making separate assumptions?

- **A.** They stopped communicating with each other.
- **B.** They shared and checked accurate room information.
- **C.** They moved every activity to the hall.
- **D.** They ignored the Monday check.

**Jawaban:** B. They shared and checked accurate room information.

**Pembahasan:** Teks menyebut tim mengecek kembali informasi ruangan dan berbagi detail akurat. Tindakan itu mencegah masing-masing kelompok membuat asumsi sendiri.

**Bukti teks:** “They checked room labels to verify that the information was consistent.”; “Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.”

**Alasan setiap opsi:**
- **A. They stopped communicating with each other.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They stopped communicating with each other.”. Bukti yang menjawab pertanyaan adalah “They checked room labels to verify that the information was consistent.”; “Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.”, dan bukti itu mendukung “They shared and checked accurate room information.”, bukan opsi ini.
- **B. They shared and checked accurate room information.** — Benar. Teks menyebut tim mengecek kembali informasi ruangan dan berbagi detail akurat. Tindakan itu mencegah masing-masing kelompok membuat asumsi sendiri. Bukti teks: “They checked room labels to verify that the information was consistent.”; “Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.”
- **C. They moved every activity to the hall.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They moved every activity to the hall.”. Bukti yang menjawab pertanyaan adalah “They checked room labels to verify that the information was consistent.”; “Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.”, dan bukti itu mendukung “They shared and checked accurate room information.”, bukan opsi ini.
- **D. They ignored the Monday check.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “They ignored the Monday check.”. Bukti yang menjawab pertanyaan adalah “They checked room labels to verify that the information was consistent.”; “Their plan worked because both groups shared accurate details instead of making separate assumptions about the building.”, dan bukti itu mendukung “They shared and checked accurate room information.”, bukan opsi ini.

---

### W11S2-Q08 — vocabulary_meaning (easy)
**Stimulus:** W11S2-T2

**Question:** What does “synthesize” mean in the report?

- **A.** Bring information from different sources together
- **B.** Copy one sentence without changes
- **C.** Separate ideas into unrelated parts
- **D.** Remove information that is important

**Jawaban:** A. Bring information from different sources together

**Pembahasan:** Synthesize berarti menyatukan informasi dari beberapa sumber menjadi pemahaman atau rencana yang utuh.

**Bukti teks:** “They synthesized details from both messages into one coherent plan.”

**Alasan setiap opsi:**
- **A. Bring information from different sources together** — Benar. Synthesize berarti menyatukan informasi dari beberapa sumber menjadi pemahaman atau rencana yang utuh. Bukti teks: “They synthesized details from both messages into one coherent plan.”
- **B. Copy one sentence without changes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copy one sentence without changes”. Bukti yang menjawab pertanyaan adalah “They synthesized details from both messages into one coherent plan.”, dan bukti itu mendukung “Bring information from different sources together”, bukan opsi ini.
- **C. Separate ideas into unrelated parts** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Separate ideas into unrelated parts”. Bukti yang menjawab pertanyaan adalah “They synthesized details from both messages into one coherent plan.”, dan bukti itu mendukung “Bring information from different sources together”, bukan opsi ini.
- **D. Remove information that is important** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove information that is important”. Bukti yang menjawab pertanyaan adalah “They synthesized details from both messages into one coherent plan.”, dan bukti itu mendukung “Bring information from different sources together”, bukan opsi ini.

---

### W11S2-Q09 — vocabulary_meaning (developing)
**Stimulus:** W11S2-T2

**Question:** Which word is closest in meaning to “coherent”?

- **A.** Unclear and disconnected
- **B.** Very short
- **C.** Unchanged
- **D.** Logical and well connected

**Jawaban:** D. Logical and well connected

**Pembahasan:** Coherent berarti runtut dan saling berhubungan secara masuk akal.

**Bukti teks:** “one coherent plan”

**Alasan setiap opsi:**
- **A. Unclear and disconnected** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Unclear and disconnected”. Bukti yang menjawab pertanyaan adalah “one coherent plan”, dan bukti itu mendukung “Logical and well connected”, bukan opsi ini.
- **B. Very short** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Very short”. Bukti yang menjawab pertanyaan adalah “one coherent plan”, dan bukti itu mendukung “Logical and well connected”, bukan opsi ini.
- **C. Unchanged** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Unchanged”. Bukti yang menjawab pertanyaan adalah “one coherent plan”, dan bukti itu mendukung “Logical and well connected”, bukan opsi ini.
- **D. Logical and well connected** — Benar. Coherent berarti runtut dan saling berhubungan secara masuk akal. Bukti teks: “one coherent plan”

---

### W11S2-Q10 — vocabulary_meaning (medium)
**Stimulus:** W11S2-T2

**Question:** What does “compare” mean?

- **A.** Copy a text exactly
- **B.** Look at similarities or differences
- **C.** Choose without checking
- **D.** Forget two pieces of information

**Jawaban:** B. Look at similarities or differences

**Pembahasan:** Compare berarti membandingkan dua atau lebih hal untuk melihat persamaan atau perbedaan.

**Bukti teks:** “The art club and library team compared their schedules before the exhibition began.”

**Alasan setiap opsi:**
- **A. Copy a text exactly** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copy a text exactly”. Bukti yang menjawab pertanyaan adalah “The art club and library team compared their schedules before the exhibition began.”, dan bukti itu mendukung “Look at similarities or differences”, bukan opsi ini.
- **B. Look at similarities or differences** — Benar. Compare berarti membandingkan dua atau lebih hal untuk melihat persamaan atau perbedaan. Bukti teks: “The art club and library team compared their schedules before the exhibition began.”
- **C. Choose without checking** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose without checking”. Bukti yang menjawab pertanyaan adalah “The art club and library team compared their schedules before the exhibition began.”, dan bukti itu mendukung “Look at similarities or differences”, bukan opsi ini.
- **D. Forget two pieces of information** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Forget two pieces of information”. Bukti yang menjawab pertanyaan adalah “The art club and library team compared their schedules before the exhibition began.”, dan bukti itu mendukung “Look at similarities or differences”, bukan opsi ini.

---

### W11S2-Q11 — vocabulary_meaning (medium)
**Stimulus:** W11S2-T2

**Question:** What does “evaluate” mean in reading?

- **A.** Move it to another place
- **B.** Translate every word
- **C.** Assess something using information or criteria
- **D.** Repeat it without thinking

**Jawaban:** C. Assess something using information or criteria

**Pembahasan:** Evaluate berarti menilai pilihan berdasarkan informasi atau kriteria.

**Bukti teks:** “The teams then evaluated two options: close the whole library or move group study activities to Room 6.”

**Alasan setiap opsi:**
- **A. Move it to another place** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Move it to another place”. Bukti yang menjawab pertanyaan adalah “The teams then evaluated two options: close the whole library or move group study activities to Room 6.”, dan bukti itu mendukung “Assess something using information or criteria”, bukan opsi ini.
- **B. Translate every word** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Translate every word”. Bukti yang menjawab pertanyaan adalah “The teams then evaluated two options: close the whole library or move group study activities to Room 6.”, dan bukti itu mendukung “Assess something using information or criteria”, bukan opsi ini.
- **C. Assess something using information or criteria** — Benar. Evaluate berarti menilai pilihan berdasarkan informasi atau kriteria. Bukti teks: “The teams then evaluated two options: close the whole library or move group study activities to Room 6.”
- **D. Repeat it without thinking** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Repeat it without thinking”. Bukti yang menjawab pertanyaan adalah “The teams then evaluated two options: close the whole library or move group study activities to Room 6.”, dan bukti itu mendukung “Assess something using information or criteria”, bukan opsi ini.

---

### W11S2-Q12 — integrated_strategy (medium)
**Stimulus:** W11S2-T1, W11S2-T2

**Question:** You have two messages with different details about the same event. What should you do before answering?

- **A.** Compare related information and verify which details agree.
- **B.** Ignore dates and places.
- **C.** Assume the first message is always correct.
- **D.** Use only the longest message.

**Jawaban:** A. Compare related information and verify which details agree.

**Pembahasan:** Membandingkan dan memverifikasi detail membantu menemukan informasi yang konsisten di antara dua teks.

**Bukti teks:** “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”; “The art club and library team compared their schedules before the exhibition began.”; “They checked room labels to verify that the information was consistent.”

**Alasan setiap opsi:**
- **A. Compare related information and verify which details agree.** — Benar. Membandingkan dan memverifikasi detail membantu menemukan informasi yang konsisten di antara dua teks. Bukti teks: “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”; “The art club and library team compared their schedules before the exhibition began.”; “They checked room labels to verify that the information was consistent.”
- **B. Ignore dates and places.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore dates and places.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”; “The art club and library team compared their schedules before the exhibition began.”; “They checked room labels to verify that the information was consistent.”, dan bukti itu mendukung “Compare related information and verify which details agree.”, bukan opsi ini.
- **C. Assume the first message is always correct.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Assume the first message is always correct.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”; “The art club and library team compared their schedules before the exhibition began.”; “They checked room labels to verify that the information was consistent.”, dan bukti itu mendukung “Compare related information and verify which details agree.”, bukan opsi ini.
- **D. Use only the longest message.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use only the longest message.”. Bukti yang menjawab pertanyaan adalah “The exhibition will open on Tuesday at 1:00 p.m. in the school hall.”; “The hall will be used for the art exhibition from Tuesday to Thursday.”; “The art club and library team compared their schedules before the exhibition began.”; “They checked room labels to verify that the information was consistent.”, dan bukti itu mendukung “Compare related information and verify which details agree.”, bukan opsi ini.

---

# W12-ONLINE-01 — Mixed Reading Practice: Choosing and Combining Strategies
**Week:** 12 · **Questions:** 30 · **Difficulty:** Easy 5 / Developing 10 / Medium 15

## Stimuli

### W12S1-T1 — A Wetland Learning Visit (Informational article; 107 words)

```text
A school visit to a wetland can include more than observing birds. Students may compare water plants, look for signs of small animals, and record how the ground feels in different areas. A guide may explain that wetlands can slow some water movement and provide habitat for living things. However, students should not assume that every wetland removes every pollutant or makes water safe to drink. The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre. To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W12S1-T2 — Wetland Visit Schedule (Schedule / notice; 107 words)

```text
WETLAND LEARNING VISIT
8:15 a.m. — Meet at school gate
9:00 a.m. — Arrive at visitor centre
9:20 a.m. — Observation deck
10:00 a.m. — Plant area
10:40 a.m. — Short break
11:00 a.m. — Visitor-centre discussion
11:30 a.m. — Depart for school
The total duration is three hours and fifteen minutes. Bring a notebook, drinking water, and a hat. Use the timetable to allocate enough time for each stop. Prioritize questions about times and places, but monitor the time available and any group instructions as well. The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W12S1-T3 — A Student-Led Energy Check (Informational report; 109 words)

```text
The science club carried out a simple energy check in three classrooms. At the start, members noted which lights and fans were on when rooms were empty. They monitored how often equipment was left running unnecessarily and recorded the room conditions. One classroom had wide windows and needed fewer lights in the morning. Another room used a fan even when the windows were open. In the final report, the club suggested checking room conditions before using electrical equipment. The report did not claim that one change would solve every energy problem. Instead, it showed how careful observation can help a school identify practical ways to reduce unnecessary energy use.
```

*Scenario note:* Nama, jumlah ruang, hasil pengamatan, dan rincian kegiatan merupakan skenario fiktif untuk latihan.

### W12S1-T4 — Community Wetland Open Day (Announcement / schedule; 91 words)

```text
COMMUNITY WETLAND OPEN DAY
Saturday, 21 June
8:30 a.m. — Welcome talk
9:00 a.m. — Guided walk
10:15 a.m. — Water observation
11:00 a.m. — Break
11:30 a.m. — Closing talk

The meeting point is the visitor entrance beside the information board. Registration closes on Wednesday, 18 June. The planned duration of the visit is three hours. Participants should bring a notebook, drinking water, and a hat. The guide may adjust the walking route if the path becomes slippery. Please stay with the group and follow safety instructions throughout the visit.
```

*Scenario note:* Tanggal, waktu, lokasi, aturan, dan kegiatan merupakan skenario fiktif.

### W12S1-T5 — Two Notes from the Wetland Visit (Paired informational notes; 127 words)

```text
STUDENT FIELD NOTE
Our group observed birds near the water and small plants along the boardwalk. We recorded the places where birds were most active. The guide asked us to prioritize safety instructions before collecting more observations. We also noted that the number of birds changed during the visit.

GUIDE'S NOTE
Wetlands can provide habitat for different living things and may slow the movement of water. However, conditions vary from one wetland to another. A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area. A coherent report connects observations with the limits of the evidence. After reading both notes, students can synthesize the information without making claims that go beyond what they observed.
```

*Scenario note:* Pengamatan kelompok, aktivitas, dan catatan pemandu merupakan skenario fiktif.

## Vocabulary cards

- **allocate** (verb; NEW) — membagi atau menetapkan bagian/sumber untuk tujuan tertentu. *Example:* Allocate enough time to each section. *Synonym/related:* assign, distribute. *Contrast:* withhold, gather.
- **prioritize** (verb; NEW) — mendahulukan hal yang paling penting. *Example:* Prioritize questions that need careful evidence checks. *Synonym/related:* rank, give priority to. *Contrast:* neglect, deprioritize.
- **duration** (noun; NEW) — lama waktu berlangsung. *Example:* The duration of the visit is three hours. *Synonym/related:* length of time, period. *Contrast:* —.
- **monitor** (verb; NEW) — memantau atau mengamati perkembangan. *Example:* Monitor your time while completing the practice. *Synonym/related:* track, observe. *Contrast:* ignore, overlook.
- **synthesize** (verb; RECYCLED) — menyatukan beberapa informasi menjadi pemahaman/ringkasan baru. *Example:* Students synthesize ideas from two short texts. *Synonym/related:* integrate, bring together. *Contrast:* separate, fragment.
- **coherent** (adjective; RECYCLED) — runtut dan saling berhubungan secara masuk akal. *Example:* A coherent summary presents ideas in a clear order. *Synonym/related:* logical, connected. *Contrast:* confusing, disconnected.
- **compare** (verb; RECYCLED) — membandingkan. *Example:* Compare the two accounts. *Synonym/related:* examine side by side. *Contrast:* —.
- **evaluate** (verb; RECYCLED) — menilai berdasarkan kriteria atau bukti. *Example:* Readers evaluate whether an option is supported. *Synonym/related:* assess, judge. *Contrast:* accept uncritically.
- **evidence** (noun; RECYCLED) — bukti. *Example:* The option needs evidence. *Synonym/related:* proof, support. *Contrast:* —.
- **specific** (adjective; RECYCLED) — khusus atau tertentu. *Example:* The question asks for a specific date. *Synonym/related:* particular, exact. *Contrast:* general.

## Answer key and explanations

### W12S1-Q01 — sequence (easy)
**Stimulus:** W12S1-T2

**Question:** Which activity is scheduled first after the group arrives at the visitor centre?

- **A.** The centre discussion
- **B.** The short break
- **C.** The plant area visit
- **D.** The observation deck visit

**Jawaban:** D. The observation deck visit

**Pembahasan:** Setelah tiba pukul 9:00, kegiatan berikutnya adalah observation deck pukul 9:20.

**Bukti teks:** “9:20 a.m. — Observation deck”

**Alasan setiap opsi:**
- **A. The centre discussion** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The centre discussion”. Bukti yang menjawab pertanyaan adalah “9:20 a.m. — Observation deck”, dan bukti itu mendukung “The observation deck visit”, bukan opsi ini.
- **B. The short break** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The short break”. Bukti yang menjawab pertanyaan adalah “9:20 a.m. — Observation deck”, dan bukti itu mendukung “The observation deck visit”, bukan opsi ini.
- **C. The plant area visit** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The plant area visit”. Bukti yang menjawab pertanyaan adalah “9:20 a.m. — Observation deck”, dan bukti itu mendukung “The observation deck visit”, bukan opsi ini.
- **D. The observation deck visit** — Benar. Setelah tiba pukul 9:00, kegiatan berikutnya adalah observation deck pukul 9:20. Bukti teks: “9:20 a.m. — Observation deck”

---

### W12S1-Q02 — conditional_instruction (developing)
**Stimulus:** W12S1-T2

**Question:** What should students do if the path is wet?

- **A.** Walk to the wetland alone
- **B.** Leave the group without telling anyone
- **C.** Follow the guide if the route changes
- **D.** Skip all instructions

**Jawaban:** C. Follow the guide if the route changes

**Pembahasan:** Jika jalur basah, pemandu dapat mengubah rute dan siswa harus mengikuti instruksi pemandu.

**Bukti teks:** “The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.”

**Alasan setiap opsi:**
- **A. Walk to the wetland alone** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Walk to the wetland alone”. Bukti yang menjawab pertanyaan adalah “The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.”, dan bukti itu mendukung “Follow the guide if the route changes”, bukan opsi ini.
- **B. Leave the group without telling anyone** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Leave the group without telling anyone”. Bukti yang menjawab pertanyaan adalah “The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.”, dan bukti itu mendukung “Follow the guide if the route changes”, bukan opsi ini.
- **C. Follow the guide if the route changes** — Benar. Jika jalur basah, pemandu dapat mengubah rute dan siswa harus mengikuti instruksi pemandu. Bukti teks: “The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.”
- **D. Skip all instructions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Skip all instructions”. Bukti yang menjawab pertanyaan adalah “The guide may change the route if the path is wet. Students should follow the guide's instructions if this happens.”, dan bukti itu mendukung “Follow the guide if the route changes”, bukan opsi ini.

---

### W12S1-Q03 — overgeneralization (developing)
**Stimulus:** W12S1-T1

**Question:** Which claim does the article warn students NOT to make?

- **A.** Wetlands may slow some water movement.
- **B.** Students can record observations.
- **C.** Wetlands can provide habitat.
- **D.** Every wetland removes every pollutant and makes water safe to drink.

**Jawaban:** D. Every wetland removes every pollutant and makes water safe to drink.

**Pembahasan:** Teks secara eksplisit memperingatkan agar tidak membuat klaim universal bahwa semua wetlands menghilangkan semua polutan dan membuat air layak minum.

**Bukti teks:** “students should not assume that every wetland removes every pollutant or makes water safe to drink.”

**Alasan setiap opsi:**
- **A. Wetlands may slow some water movement.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Wetlands may slow some water movement.”. Bukti yang menjawab pertanyaan adalah “students should not assume that every wetland removes every pollutant or makes water safe to drink.”, dan bukti itu mendukung “Every wetland removes every pollutant and makes water safe to drink.”, bukan opsi ini.
- **B. Students can record observations.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students can record observations.”. Bukti yang menjawab pertanyaan adalah “students should not assume that every wetland removes every pollutant or makes water safe to drink.”, dan bukti itu mendukung “Every wetland removes every pollutant and makes water safe to drink.”, bukan opsi ini.
- **C. Wetlands can provide habitat.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Wetlands can provide habitat.”. Bukti yang menjawab pertanyaan adalah “students should not assume that every wetland removes every pollutant or makes water safe to drink.”, dan bukti itu mendukung “Every wetland removes every pollutant and makes water safe to drink.”, bukan opsi ini.
- **D. Every wetland removes every pollutant and makes water safe to drink.** — Benar. Teks secara eksplisit memperingatkan agar tidak membuat klaim universal bahwa semua wetlands menghilangkan semua polutan dan membuat air layak minum. Bukti teks: “students should not assume that every wetland removes every pollutant or makes water safe to drink.”

---

### W12S1-Q04 — main_purpose (medium)
**Stimulus:** W12S1-T1

**Question:** What is the main purpose of the visit?

- **A.** To compare the types of plants found at different stops
- **B.** To decide whether every wetland makes water safe to drink
- **C.** To practise observing and recording information about a wetland
- **D.** To compare the visitor centre with a school classroom

**Jawaban:** C. To practise observing and recording information about a wetland

**Pembahasan:** Kunjungan dirancang sebagai kegiatan belajar melalui pengamatan, pencatatan, dan pencarian bukti.

**Bukti teks:** “A school visit to a wetland can include more than observing birds.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”

**Alasan setiap opsi:**
- **A. To compare the types of plants found at different stops** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To compare the types of plants found at different stops”. Bukti yang menjawab pertanyaan adalah “A school visit to a wetland can include more than observing birds.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “To practise observing and recording information about a wetland”, bukan opsi ini.
- **B. To decide whether every wetland makes water safe to drink** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To decide whether every wetland makes water safe to drink”. Bukti yang menjawab pertanyaan adalah “A school visit to a wetland can include more than observing birds.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “To practise observing and recording information about a wetland”, bukan opsi ini.
- **C. To practise observing and recording information about a wetland** — Benar. Kunjungan dirancang sebagai kegiatan belajar melalui pengamatan, pencatatan, dan pencarian bukti. Bukti teks: “A school visit to a wetland can include more than observing birds.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”
- **D. To compare the visitor centre with a school classroom** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To compare the visitor centre with a school classroom”. Bukti yang menjawab pertanyaan adalah “A school visit to a wetland can include more than observing birds.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “To practise observing and recording information about a wetland”, bukan opsi ini.

---

### W12S1-Q05 — strategy_reason (medium)
**Stimulus:** W12S1-T1

**Question:** Why are students asked to read the questions before each stop?

- **A.** So they can identify what information to observe and record
- **B.** So they can avoid looking at the wetland
- **C.** So they can finish before the guide arrives
- **D.** So they can choose a different school

**Jawaban:** A. So they can identify what information to observe and record

**Pembahasan:** Pertanyaan awal membantu siswa mengetahui target observasi dan bukti yang perlu dicatat.

**Bukti teks:** “students were asked to read the questions before each stop and note evidence that helped answer them.”

**Alasan setiap opsi:**
- **A. So they can identify what information to observe and record** — Benar. Pertanyaan awal membantu siswa mengetahui target observasi dan bukti yang perlu dicatat. Bukti teks: “students were asked to read the questions before each stop and note evidence that helped answer them.”
- **B. So they can avoid looking at the wetland** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “So they can avoid looking at the wetland”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “So they can identify what information to observe and record”, bukan opsi ini.
- **C. So they can finish before the guide arrives** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “So they can finish before the guide arrives”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “So they can identify what information to observe and record”, bukan opsi ini.
- **D. So they can choose a different school** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “So they can choose a different school”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “So they can identify what information to observe and record”, bukan opsi ini.

---

### W12S1-Q06 — cross_text_integration (medium)
**Stimulus:** W12S1-T1, W12S1-T2

**Question:** Which statement combines information from the article and schedule?

- **A.** The visit includes three learning stops and asks students to record evidence.
- **B.** The route includes only an observation deck and a plant area.
- **C.** Students are asked to record evidence but do not need to read questions first.
- **D.** The schedule gives three stops but includes no observation activity.

**Jawaban:** A. The visit includes three learning stops and asks students to record evidence.

**Pembahasan:** Artikel menjelaskan tujuan pencatatan bukti dan jadwal menyebut beberapa lokasi belajar; pilihan A menggabungkan kedua informasi.

**Bukti teks:** “The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”; “9:20 a.m. — Observation deck”; “10:00 a.m. — Plant area”; “11:00 a.m. — Visitor-centre discussion”

**Alasan setiap opsi:**
- **A. The visit includes three learning stops and asks students to record evidence.** — Benar. Artikel menjelaskan tujuan pencatatan bukti dan jadwal menyebut beberapa lokasi belajar; pilihan A menggabungkan kedua informasi. Bukti teks: “The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”; “9:20 a.m. — Observation deck”; “10:00 a.m. — Plant area”; “11:00 a.m. — Visitor-centre discussion”
- **B. The route includes only an observation deck and a plant area.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The route includes only an observation deck and a plant area.”. Bukti yang menjawab pertanyaan adalah “The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”; “9:20 a.m. — Observation deck”; “10:00 a.m. — Plant area”; “11:00 a.m. — Visitor-centre discussion”, dan bukti itu mendukung “The visit includes three learning stops and asks students to record evidence.”, bukan opsi ini.
- **C. Students are asked to record evidence but do not need to read questions first.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students are asked to record evidence but do not need to read questions first.”. Bukti yang menjawab pertanyaan adalah “The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”; “9:20 a.m. — Observation deck”; “10:00 a.m. — Plant area”; “11:00 a.m. — Visitor-centre discussion”, dan bukti itu mendukung “The visit includes three learning stops and asks students to record evidence.”, bukan opsi ini.
- **D. The schedule gives three stops but includes no observation activity.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The schedule gives three stops but includes no observation activity.”. Bukti yang menjawab pertanyaan adalah “The learning team planned a route with three stops: an observation deck, a plant area, and a visitor centre.”; “To make the visit useful, students were asked to read the questions before each stop and note evidence that helped answer them.”; “9:20 a.m. — Observation deck”; “10:00 a.m. — Plant area”; “11:00 a.m. — Visitor-centre discussion”, dan bukti itu mendukung “The visit includes three learning stops and asks students to record evidence.”, bukan opsi ini.

---

### W12S1-Q07 — not_mentioned (medium)
**Stimulus:** W12S1-T2

**Question:** Which item is NOT listed as something students should bring?

- **A.** Drinking water
- **B.** A camera
- **C.** A hat
- **D.** A notebook

**Jawaban:** B. A camera

**Pembahasan:** Camera tidak tercantum dalam daftar perlengkapan. Jangan menyimpulkan bahwa siswa dilarang membawa kamera; yang benar hanya tidak disebutkan.

**Bukti teks:** “Bring a notebook, drinking water, and a hat.”

**Alasan setiap opsi:**
- **A. Drinking water** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.
- **B. A camera** — Benar. Camera tidak tercantum dalam daftar perlengkapan. Jangan menyimpulkan bahwa siswa dilarang membawa kamera; yang benar hanya tidak disebutkan. Bukti teks: “Bring a notebook, drinking water, and a hat.”
- **C. A hat** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.
- **D. A notebook** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.

---

### W12S1-Q08 — vocabulary_meaning (easy)
**Stimulus:** W12S1-T2

**Question:** In the instruction to “allocate enough time for each stop,” what does “allocate” mean?

- **A.** Ignore the available time
- **B.** Give or assign a part of a resource for a purpose
- **C.** Compare two unrelated texts
- **D.** Remove every task from the plan

**Jawaban:** B. Give or assign a part of a resource for a purpose

**Pembahasan:** Allocate berarti menetapkan atau membagi sebagian sumber daya untuk tujuan tertentu. Dalam jadwal ini, siswa diminta menyediakan waktu yang cukup bagi setiap pemberhentian.

**Bukti teks:** “Use the timetable to allocate enough time for each stop.”

**Alasan setiap opsi:**
- **A. Ignore the available time** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore the available time”. Bukti yang menjawab pertanyaan adalah “Use the timetable to allocate enough time for each stop.”, dan bukti itu mendukung “Give or assign a part of a resource for a purpose”, bukan opsi ini.
- **B. Give or assign a part of a resource for a purpose** — Benar. Allocate berarti menetapkan atau membagi sebagian sumber daya untuk tujuan tertentu. Dalam jadwal ini, siswa diminta menyediakan waktu yang cukup bagi setiap pemberhentian. Bukti teks: “Use the timetable to allocate enough time for each stop.”
- **C. Compare two unrelated texts** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Compare two unrelated texts”. Bukti yang menjawab pertanyaan adalah “Use the timetable to allocate enough time for each stop.”, dan bukti itu mendukung “Give or assign a part of a resource for a purpose”, bukan opsi ini.
- **D. Remove every task from the plan** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove every task from the plan”. Bukti yang menjawab pertanyaan adalah “Use the timetable to allocate enough time for each stop.”, dan bukti itu mendukung “Give or assign a part of a resource for a purpose”, bukan opsi ini.

---

### W12S1-Q09 — vocabulary_meaning (developing)
**Stimulus:** W12S1-T2

**Question:** Which word is closest in meaning to “prioritize”?

- **A.** Forget the main task
- **B.** Delay everything
- **C.** Make something longer
- **D.** Give priority to

**Jawaban:** D. Give priority to

**Pembahasan:** Prioritize berarti mendahulukan hal yang dianggap paling penting.

**Bukti teks:** “Prioritize questions about times and places, but monitor the time available and any group instructions as well.”

**Alasan setiap opsi:**
- **A. Forget the main task** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Forget the main task”. Bukti yang menjawab pertanyaan adalah “Prioritize questions about times and places, but monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Give priority to”, bukan opsi ini.
- **B. Delay everything** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Delay everything”. Bukti yang menjawab pertanyaan adalah “Prioritize questions about times and places, but monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Give priority to”, bukan opsi ini.
- **C. Make something longer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Make something longer”. Bukti yang menjawab pertanyaan adalah “Prioritize questions about times and places, but monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Give priority to”, bukan opsi ini.
- **D. Give priority to** — Benar. Prioritize berarti mendahulukan hal yang dianggap paling penting. Bukti teks: “Prioritize questions about times and places, but monitor the time available and any group instructions as well.”

---

### W12S1-Q10 — vocabulary_meaning (medium)
**Stimulus:** W12S1-T2

**Question:** What does “duration” refer to?

- **A.** The place where an event happens
- **B.** The number of people attending
- **C.** The length of time something lasts
- **D.** The reason an event is cancelled

**Jawaban:** C. The length of time something lasts

**Pembahasan:** Duration adalah lama waktu berlangsungnya kegiatan.

**Bukti teks:** “The total duration is three hours and fifteen minutes.”

**Alasan setiap opsi:**
- **A. The place where an event happens** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The place where an event happens”. Bukti yang menjawab pertanyaan adalah “The total duration is three hours and fifteen minutes.”, dan bukti itu mendukung “The length of time something lasts”, bukan opsi ini.
- **B. The number of people attending** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The number of people attending”. Bukti yang menjawab pertanyaan adalah “The total duration is three hours and fifteen minutes.”, dan bukti itu mendukung “The length of time something lasts”, bukan opsi ini.
- **C. The length of time something lasts** — Benar. Duration adalah lama waktu berlangsungnya kegiatan. Bukti teks: “The total duration is three hours and fifteen minutes.”
- **D. The reason an event is cancelled** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The reason an event is cancelled”. Bukti yang menjawab pertanyaan adalah “The total duration is three hours and fifteen minutes.”, dan bukti itu mendukung “The length of time something lasts”, bukan opsi ini.

---

### W12S1-Q11 — vocabulary_in_context (developing)
**Stimulus:** W12S1-T2

**Question:** In the instruction to “monitor the time available,” what does “monitor” mean?

- **A.** Stop looking at the questions
- **B.** Check how much time is passing while you work
- **C.** Ask someone else to answer
- **D.** Give all your time to one question

**Jawaban:** B. Check how much time is passing while you work

**Pembahasan:** Monitor berarti memantau atau mengamati keadaan dari waktu ke waktu. Di sini siswa diminta memperhatikan waktu yang masih tersedia.

**Bukti teks:** “monitor the time available and any group instructions as well.”

**Alasan setiap opsi:**
- **A. Stop looking at the questions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Stop looking at the questions”. Bukti yang menjawab pertanyaan adalah “monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Check how much time is passing while you work”, bukan opsi ini.
- **B. Check how much time is passing while you work** — Benar. Monitor berarti memantau atau mengamati keadaan dari waktu ke waktu. Di sini siswa diminta memperhatikan waktu yang masih tersedia. Bukti teks: “monitor the time available and any group instructions as well.”
- **C. Ask someone else to answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ask someone else to answer”. Bukti yang menjawab pertanyaan adalah “monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Check how much time is passing while you work”, bukan opsi ini.
- **D. Give all your time to one question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Give all your time to one question”. Bukti yang menjawab pertanyaan adalah “monitor the time available and any group instructions as well.”, dan bukti itu mendukung “Check how much time is passing while you work”, bukan opsi ini.

---

### W12S1-Q12 — mixed_strategy_selection (medium)
**Stimulus:** W12S1-T1

**Question:** You are about to read a mixed set with a passage and a schedule. What is the most useful first move?

- **A.** Answer only the longest question
- **B.** Read every option and guess quickly
- **C.** Translate every word in both texts
- **D.** Read each question, identify its target, then choose the relevant text

**Jawaban:** D. Read each question, identify its target, then choose the relevant text

**Pembahasan:** Strategi FRTS dimulai dari pertanyaan dan target pencarian, lalu siswa memilih bagian teks yang relevan.

**Bukti teks:** “students were asked to read the questions before each stop and note evidence that helped answer them.”

**Alasan setiap opsi:**
- **A. Answer only the longest question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Answer only the longest question”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “Read each question, identify its target, then choose the relevant text”, bukan opsi ini.
- **B. Read every option and guess quickly** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Read every option and guess quickly”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “Read each question, identify its target, then choose the relevant text”, bukan opsi ini.
- **C. Translate every word in both texts** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Translate every word in both texts”. Bukti yang menjawab pertanyaan adalah “students were asked to read the questions before each stop and note evidence that helped answer them.”, dan bukti itu mendukung “Read each question, identify its target, then choose the relevant text”, bukan opsi ini.
- **D. Read each question, identify its target, then choose the relevant text** — Benar. Strategi FRTS dimulai dari pertanyaan dan target pencarian, lalu siswa memilih bagian teks yang relevan. Bukti teks: “students were asked to read the questions before each stop and note evidence that helped answer them.”

---

### W12S1-Q13 — main_idea (medium)
**Stimulus:** W12S1-T3

**Question:** Which statement best expresses the main idea of the report?

- **A.** The report recommended leaving fans on whenever windows were open.
- **B.** The club measured the exact electricity use in every classroom.
- **C.** Careful classroom observations can help a school identify ways to reduce unnecessary energy use.
- **D.** Wide windows were the only factor considered in the report.

**Jawaban:** C. Careful classroom observations can help a school identify ways to reduce unnecessary energy use.

**Pembahasan:** Gagasan utama mencakup kegiatan pengamatan dan tujuan laporan. Teks tidak mengklaim satu tindakan menyelesaikan semua masalah energi.

**Bukti teks:** “careful observation can help a school identify practical ways to reduce unnecessary energy use.”

**Alasan setiap opsi:**
- **A. The report recommended leaving fans on whenever windows were open.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The report recommended leaving fans on whenever windows were open.”. Bukti yang menjawab pertanyaan adalah “careful observation can help a school identify practical ways to reduce unnecessary energy use.”, dan bukti itu mendukung “Careful classroom observations can help a school identify ways to reduce unnecessary energy use.”, bukan opsi ini.
- **B. The club measured the exact electricity use in every classroom.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The club measured the exact electricity use in every classroom.”. Bukti yang menjawab pertanyaan adalah “careful observation can help a school identify practical ways to reduce unnecessary energy use.”, dan bukti itu mendukung “Careful classroom observations can help a school identify ways to reduce unnecessary energy use.”, bukan opsi ini.
- **C. Careful classroom observations can help a school identify ways to reduce unnecessary energy use.** — Benar. Gagasan utama mencakup kegiatan pengamatan dan tujuan laporan. Teks tidak mengklaim satu tindakan menyelesaikan semua masalah energi. Bukti teks: “careful observation can help a school identify practical ways to reduce unnecessary energy use.”
- **D. Wide windows were the only factor considered in the report.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Wide windows were the only factor considered in the report.”. Bukti yang menjawab pertanyaan adalah “careful observation can help a school identify practical ways to reduce unnecessary energy use.”, dan bukti itu mendukung “Careful classroom observations can help a school identify ways to reduce unnecessary energy use.”, bukan opsi ini.

---

### W12S1-Q14 — explicit_detail (developing)
**Stimulus:** W12S1-T3

**Question:** What did the club members record at the start of the energy check?

- **A.** Which lights and fans were on in empty rooms
- **B.** Whether every fan was working properly
- **C.** How many students used each classroom
- **D.** How much electricity the school used each day

**Jawaban:** A. Which lights and fans were on in empty rooms

**Pembahasan:** Detail ini dinyatakan secara langsung pada awal laporan.

**Bukti teks:** “members noted which lights and fans were on when rooms were empty.”

**Alasan setiap opsi:**
- **A. Which lights and fans were on in empty rooms** — Benar. Detail ini dinyatakan secara langsung pada awal laporan. Bukti teks: “members noted which lights and fans were on when rooms were empty.”
- **B. Whether every fan was working properly** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Whether every fan was working properly”. Bukti yang menjawab pertanyaan adalah “members noted which lights and fans were on when rooms were empty.”, dan bukti itu mendukung “Which lights and fans were on in empty rooms”, bukan opsi ini.
- **C. How many students used each classroom** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “How many students used each classroom”. Bukti yang menjawab pertanyaan adalah “members noted which lights and fans were on when rooms were empty.”, dan bukti itu mendukung “Which lights and fans were on in empty rooms”, bukan opsi ini.
- **D. How much electricity the school used each day** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “How much electricity the school used each day”. Bukti yang menjawab pertanyaan adalah “members noted which lights and fans were on when rooms were empty.”, dan bukti itu mendukung “Which lights and fans were on in empty rooms”, bukan opsi ini.

---

### W12S1-Q15 — supported_conclusion (medium)
**Stimulus:** W12S1-T3

**Question:** Which conclusion is best supported by the report?

- **A.** Checking room conditions may help people decide when electrical equipment is needed.
- **B.** Every classroom needs a fan throughout the day.
- **C.** One observation is enough to solve every energy problem.
- **D.** Opening windows always removes the need for electricity.

**Jawaban:** A. Checking room conditions may help people decide when electrical equipment is needed.

**Pembahasan:** Kesimpulan ini dibatasi dengan “may help” sehingga sesuai dengan rekomendasi laporan tanpa membuat klaim mutlak.

**Bukti teks:** “suggested checking room conditions before using electrical equipment.”

**Alasan setiap opsi:**
- **A. Checking room conditions may help people decide when electrical equipment is needed.** — Benar. Kesimpulan ini dibatasi dengan “may help” sehingga sesuai dengan rekomendasi laporan tanpa membuat klaim mutlak. Bukti teks: “suggested checking room conditions before using electrical equipment.”
- **B. Every classroom needs a fan throughout the day.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Every classroom needs a fan throughout the day.”. Bukti yang menjawab pertanyaan adalah “suggested checking room conditions before using electrical equipment.”, dan bukti itu mendukung “Checking room conditions may help people decide when electrical equipment is needed.”, bukan opsi ini.
- **C. One observation is enough to solve every energy problem.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “One observation is enough to solve every energy problem.”. Bukti yang menjawab pertanyaan adalah “suggested checking room conditions before using electrical equipment.”, dan bukti itu mendukung “Checking room conditions may help people decide when electrical equipment is needed.”, bukan opsi ini.
- **D. Opening windows always removes the need for electricity.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Opening windows always removes the need for electricity.”. Bukti yang menjawab pertanyaan adalah “suggested checking room conditions before using electrical equipment.”, dan bukti itu mendukung “Checking room conditions may help people decide when electrical equipment is needed.”, bukan opsi ini.

---

### W12S1-Q16 — vocabulary_in_context (easy)
**Stimulus:** W12S1-T3

**Question:** In the sentence “They monitored how often equipment was left running,” what does “monitored” mean?

- **A.** Repaired immediately
- **B.** Watched or checked over time
- **C.** Removed from the building
- **D.** Bought for the classroom

**Jawaban:** B. Watched or checked over time

**Pembahasan:** Dalam konteks pencatatan penggunaan peralatan, monitored berarti memantau atau memeriksa dari waktu ke waktu.

**Bukti teks:** “They monitored how often equipment was left running unnecessarily”

**Alasan setiap opsi:**
- **A. Repaired immediately** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Repaired immediately”. Bukti yang menjawab pertanyaan adalah “They monitored how often equipment was left running unnecessarily”, dan bukti itu mendukung “Watched or checked over time”, bukan opsi ini.
- **B. Watched or checked over time** — Benar. Dalam konteks pencatatan penggunaan peralatan, monitored berarti memantau atau memeriksa dari waktu ke waktu. Bukti teks: “They monitored how often equipment was left running unnecessarily”
- **C. Removed from the building** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Removed from the building”. Bukti yang menjawab pertanyaan adalah “They monitored how often equipment was left running unnecessarily”, dan bukti itu mendukung “Watched or checked over time”, bukan opsi ini.
- **D. Bought for the classroom** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Bought for the classroom”. Bukti yang menjawab pertanyaan adalah “They monitored how often equipment was left running unnecessarily”, dan bukti itu mendukung “Watched or checked over time”, bukan opsi ini.

---

### W12S1-Q17 — explicit_detail (easy)
**Stimulus:** W12S1-T4

**Question:** On which day will the Community Wetland Open Day take place?

- **A.** Wednesday, 21 June
- **B.** Wednesday, 18 June
- **C.** Saturday, 18 June
- **D.** Saturday, 21 June

**Jawaban:** D. Saturday, 21 June

**Pembahasan:** Tanggal acara ditulis langsung pada baris kedua pengumuman.

**Bukti teks:** “Saturday, 21 June”

**Alasan setiap opsi:**
- **A. Wednesday, 21 June** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Wednesday, 21 June”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”, dan bukti itu mendukung “Saturday, 21 June”, bukan opsi ini.
- **B. Wednesday, 18 June** — Tidak tepat. Detail “Wednesday, 18 June” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”, yang mendukung “Saturday, 21 June”.
- **C. Saturday, 18 June** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Saturday, 18 June”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”, dan bukti itu mendukung “Saturday, 21 June”, bukan opsi ini.
- **D. Saturday, 21 June** — Benar. Tanggal acara ditulis langsung pada baris kedua pengumuman. Bukti teks: “Saturday, 21 June”

---

### W12S1-Q18 — date_deadline_distinction (developing)
**Stimulus:** W12S1-T4

**Question:** When does registration close?

- **A.** At 11:30 a.m. on 21 June
- **B.** At 9:00 a.m. on 21 June
- **C.** Saturday, 21 June
- **D.** Wednesday, 18 June

**Jawaban:** D. Wednesday, 18 June

**Pembahasan:** Pendaftaran ditutup pada hari Rabu, 18 Juni. Tanggal tersebut harus dibedakan dari tanggal kegiatan.

**Bukti teks:** “Registration closes on Wednesday, 18 June.”

**Alasan setiap opsi:**
- **A. At 11:30 a.m. on 21 June** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At 11:30 a.m. on 21 June”. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “Wednesday, 18 June”, bukan opsi ini.
- **B. At 9:00 a.m. on 21 June** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “At 9:00 a.m. on 21 June”. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “Wednesday, 18 June”, bukan opsi ini.
- **C. Saturday, 21 June** — Tidak tepat. Detail “Saturday, 21 June” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, yang mendukung “Wednesday, 18 June”.
- **D. Wednesday, 18 June** — Benar. Pendaftaran ditutup pada hari Rabu, 18 Juni. Tanggal tersebut harus dibedakan dari tanggal kegiatan. Bukti teks: “Registration closes on Wednesday, 18 June.”

---

### W12S1-Q19 — main_purpose (medium)
**Stimulus:** W12S1-T4

**Question:** What is the main purpose of this announcement?

- **A.** To persuade visitors to buy equipment for the visit
- **B.** To explain the scientific history of wetlands
- **C.** To inform visitors about the event schedule and practical arrangements
- **D.** To report the results of a completed wetland study

**Jawaban:** C. To inform visitors about the event schedule and practical arrangements

**Pembahasan:** Tujuan pengumuman adalah memberi informasi agar calon peserta mengetahui jadwal dan persiapan.

**Bukti teks:** “Saturday, 21 June”; “8:30 a.m. — Welcome talk”; “The meeting point is the visitor entrance beside the information board.”; “Registration closes on Wednesday, 18 June.”

**Alasan setiap opsi:**
- **A. To persuade visitors to buy equipment for the visit** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To persuade visitors to buy equipment for the visit”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”; “8:30 a.m. — Welcome talk”; “The meeting point is the visitor entrance beside the information board.”; “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “To inform visitors about the event schedule and practical arrangements”, bukan opsi ini.
- **B. To explain the scientific history of wetlands** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To explain the scientific history of wetlands”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”; “8:30 a.m. — Welcome talk”; “The meeting point is the visitor entrance beside the information board.”; “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “To inform visitors about the event schedule and practical arrangements”, bukan opsi ini.
- **C. To inform visitors about the event schedule and practical arrangements** — Benar. Tujuan pengumuman adalah memberi informasi agar calon peserta mengetahui jadwal dan persiapan. Bukti teks: “Saturday, 21 June”; “8:30 a.m. — Welcome talk”; “The meeting point is the visitor entrance beside the information board.”; “Registration closes on Wednesday, 18 June.”
- **D. To report the results of a completed wetland study** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To report the results of a completed wetland study”. Bukti yang menjawab pertanyaan adalah “Saturday, 21 June”; “8:30 a.m. — Welcome talk”; “The meeting point is the visitor entrance beside the information board.”; “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “To inform visitors about the event schedule and practical arrangements”, bukan opsi ini.

---

### W12S1-Q20 — strategy_transfer (developing)
**Stimulus:** W12S1-T4

**Question:** You need to find the registration deadline quickly. Which action is the best first step?

- **A.** Scan for the word “Registration” or “closes” and check the date beside it
- **B.** Read every line slowly from beginning to end
- **C.** Use skimming to decide the writer’s overall purpose
- **D.** Guess from the event date without checking the notice

**Jawaban:** A. Scan for the word “Registration” or “closes” and check the date beside it

**Pembahasan:** Targetnya adalah tanggal batas pendaftaran, sehingga siswa dapat menggunakan scanning lalu memeriksa label dan tanggal.

**Bukti teks:** “Registration closes on Wednesday, 18 June.”

**Alasan setiap opsi:**
- **A. Scan for the word “Registration” or “closes” and check the date beside it** — Benar. Targetnya adalah tanggal batas pendaftaran, sehingga siswa dapat menggunakan scanning lalu memeriksa label dan tanggal. Bukti teks: “Registration closes on Wednesday, 18 June.”
- **B. Read every line slowly from beginning to end** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Read every line slowly from beginning to end”. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “Scan for the word “Registration” or “closes” and check the date beside it”, bukan opsi ini.
- **C. Use skimming to decide the writer’s overall purpose** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use skimming to decide the writer’s overall purpose”. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “Scan for the word “Registration” or “closes” and check the date beside it”, bukan opsi ini.
- **D. Guess from the event date without checking the notice** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Guess from the event date without checking the notice”. Bukti yang menjawab pertanyaan adalah “Registration closes on Wednesday, 18 June.”, dan bukti itu mendukung “Scan for the word “Registration” or “closes” and check the date beside it”, bukan opsi ini.

---

### W12S1-Q21 — cross_text_integration (medium)
**Stimulus:** W12S1-T5

**Question:** Which statement is supported by BOTH the student field note and the guide’s note?

- **A.** The guide recorded exactly the same observations as the student group.
- **B.** The group observed living things, and the guide explains that wetlands can provide habitat.
- **C.** The group observed all seasonal changes, and the guide confirmed that the pattern never changes.
- **D.** Both notes confirm that every wetland has the same species.

**Jawaban:** B. The group observed living things, and the guide explains that wetlands can provide habitat.

**Pembahasan:** Jawaban menggabungkan pengamatan siswa dengan penjelasan umum dari pemandu tanpa memperluas klaim.

**Bukti teks:** “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”

**Alasan setiap opsi:**
- **A. The guide recorded exactly the same observations as the student group.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The guide recorded exactly the same observations as the student group.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The group observed living things, and the guide explains that wetlands can provide habitat.”, bukan opsi ini.
- **B. The group observed living things, and the guide explains that wetlands can provide habitat.** — Benar. Jawaban menggabungkan pengamatan siswa dengan penjelasan umum dari pemandu tanpa memperluas klaim. Bukti teks: “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”
- **C. The group observed all seasonal changes, and the guide confirmed that the pattern never changes.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The group observed all seasonal changes, and the guide confirmed that the pattern never changes.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The group observed living things, and the guide explains that wetlands can provide habitat.”, bukan opsi ini.
- **D. Both notes confirm that every wetland has the same species.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Both notes confirm that every wetland has the same species.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The group observed living things, and the guide explains that wetlands can provide habitat.”, bukan opsi ini.

---

### W12S1-Q22 — text_purpose_comparison (medium)
**Stimulus:** W12S1-T5

**Question:** How are the two notes different in their main focus?

- **A.** Both notes give only a timetable for the visit.
- **B.** The student note reports observations, while the guide’s note explains general information and limits.
- **C.** The guide’s note lists prices, while the student note advertises the event.
- **D.** The student note gives scientific rules, while the guide’s note tells a fictional story.

**Jawaban:** B. The student note reports observations, while the guide’s note explains general information and limits.

**Pembahasan:** Perbedaan tujuan kedua catatan terlihat dari isi masing-masing: pengalaman pengamatan dan penjelasan umum.

**Bukti teks:** “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”

**Alasan setiap opsi:**
- **A. Both notes give only a timetable for the visit.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Both notes give only a timetable for the visit.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The student note reports observations, while the guide’s note explains general information and limits.”, bukan opsi ini.
- **B. The student note reports observations, while the guide’s note explains general information and limits.** — Benar. Perbedaan tujuan kedua catatan terlihat dari isi masing-masing: pengalaman pengamatan dan penjelasan umum. Bukti teks: “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”
- **C. The guide’s note lists prices, while the student note advertises the event.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The guide’s note lists prices, while the student note advertises the event.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The student note reports observations, while the guide’s note explains general information and limits.”, bukan opsi ini.
- **D. The student note gives scientific rules, while the guide’s note tells a fictional story.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The student note gives scientific rules, while the guide’s note tells a fictional story.”. Bukti yang menjawab pertanyaan adalah “Our group observed birds near the water and small plants along the boardwalk.”; “Wetlands can provide habitat for different living things and may slow the movement of water.”, dan bukti itu mendukung “The student note reports observations, while the guide’s note explains general information and limits.”, bukan opsi ini.

---

### W12S1-Q23 — vocabulary_in_context (developing)
**Stimulus:** W12S1-T5

**Question:** In the student note, what does “prioritize safety instructions” mean?

- **A.** Read the instructions after the visit has ended
- **B.** Remove all safety instructions from the activity
- **C.** Give safety instructions the first and greatest attention
- **D.** Compare the instructions with a timetable only

**Jawaban:** C. Give safety instructions the first and greatest attention

**Pembahasan:** Dalam konteks ini, prioritize berarti mendahulukan instruksi keselamatan sebelum mengumpulkan pengamatan lebih lanjut.

**Bukti teks:** “The guide asked us to prioritize safety instructions before collecting more observations.”

**Alasan setiap opsi:**
- **A. Read the instructions after the visit has ended** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Read the instructions after the visit has ended”. Bukti yang menjawab pertanyaan adalah “The guide asked us to prioritize safety instructions before collecting more observations.”, dan bukti itu mendukung “Give safety instructions the first and greatest attention”, bukan opsi ini.
- **B. Remove all safety instructions from the activity** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove all safety instructions from the activity”. Bukti yang menjawab pertanyaan adalah “The guide asked us to prioritize safety instructions before collecting more observations.”, dan bukti itu mendukung “Give safety instructions the first and greatest attention”, bukan opsi ini.
- **C. Give safety instructions the first and greatest attention** — Benar. Dalam konteks ini, prioritize berarti mendahulukan instruksi keselamatan sebelum mengumpulkan pengamatan lebih lanjut. Bukti teks: “The guide asked us to prioritize safety instructions before collecting more observations.”
- **D. Compare the instructions with a timetable only** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Compare the instructions with a timetable only”. Bukti yang menjawab pertanyaan adalah “The guide asked us to prioritize safety instructions before collecting more observations.”, dan bukti itu mendukung “Give safety instructions the first and greatest attention”, bukan opsi ini.

---

### W12S1-Q24 — vocabulary_meaning (easy)
**Stimulus:** W12S1-T4

**Question:** In the announcement, what does “duration” refer to?

- **A.** The number of people attending
- **B.** The place where an activity begins
- **C.** The total length of time an activity lasts
- **D.** The final date for registration

**Jawaban:** C. The total length of time an activity lasts

**Pembahasan:** Duration merujuk pada lamanya kegiatan berlangsung, yang pada teks disebut tiga jam.

**Bukti teks:** “The planned duration of the visit is three hours.”

**Alasan setiap opsi:**
- **A. The number of people attending** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The number of people attending”. Bukti yang menjawab pertanyaan adalah “The planned duration of the visit is three hours.”, dan bukti itu mendukung “The total length of time an activity lasts”, bukan opsi ini.
- **B. The place where an activity begins** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The place where an activity begins”. Bukti yang menjawab pertanyaan adalah “The planned duration of the visit is three hours.”, dan bukti itu mendukung “The total length of time an activity lasts”, bukan opsi ini.
- **C. The total length of time an activity lasts** — Benar. Duration merujuk pada lamanya kegiatan berlangsung, yang pada teks disebut tiga jam. Bukti teks: “The planned duration of the visit is three hours.”
- **D. The final date for registration** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The final date for registration”. Bukti yang menjawab pertanyaan adalah “The planned duration of the visit is three hours.”, dan bukti itu mendukung “The total length of time an activity lasts”, bukan opsi ini.

---

### W12S1-Q25 — vocabulary_meaning (developing)
**Stimulus:** W12S1-T5

**Question:** In the guide’s note, what does “coherent report” mean?

- **A.** A report that contains every possible detail
- **B.** A report whose ideas are connected in a clear and logical way
- **C.** A report written only as a list of unrelated words
- **D.** A report that changes its conclusion in every paragraph

**Jawaban:** B. A report whose ideas are connected in a clear and logical way

**Pembahasan:** Dalam konteks penulisan laporan, coherent menjelaskan keterkaitan dan keruntutan gagasan.

**Bukti teks:** “A coherent report connects observations with the limits of the evidence.”

**Alasan setiap opsi:**
- **A. A report that contains every possible detail** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A report that contains every possible detail”. Bukti yang menjawab pertanyaan adalah “A coherent report connects observations with the limits of the evidence.”, dan bukti itu mendukung “A report whose ideas are connected in a clear and logical way”, bukan opsi ini.
- **B. A report whose ideas are connected in a clear and logical way** — Benar. Dalam konteks penulisan laporan, coherent menjelaskan keterkaitan dan keruntutan gagasan. Bukti teks: “A coherent report connects observations with the limits of the evidence.”
- **C. A report written only as a list of unrelated words** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A report written only as a list of unrelated words”. Bukti yang menjawab pertanyaan adalah “A coherent report connects observations with the limits of the evidence.”, dan bukti itu mendukung “A report whose ideas are connected in a clear and logical way”, bukan opsi ini.
- **D. A report that changes its conclusion in every paragraph** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A report that changes its conclusion in every paragraph”. Bukti yang menjawab pertanyaan adalah “A coherent report connects observations with the limits of the evidence.”, dan bukti itu mendukung “A report whose ideas are connected in a clear and logical way”, bukan opsi ini.

---

### W12S1-Q26 — vocabulary_meaning (medium)
**Stimulus:** W12S1-T5

**Question:** What does “synthesize the information” mean in the final sentence?

- **A.** Combine information from different sources to form an overall understanding
- **B.** Copy one sentence without considering the other note
- **C.** Remove all information that seems different
- **D.** Choose the longest note and ignore the shorter one

**Jawaban:** A. Combine information from different sources to form an overall understanding

**Pembahasan:** Siswa diminta menggabungkan dua catatan tanpa membuat klaim yang melampaui pengamatan.

**Bukti teks:** “After reading both notes, students can synthesize the information without making claims that go beyond what they observed.”

**Alasan setiap opsi:**
- **A. Combine information from different sources to form an overall understanding** — Benar. Siswa diminta menggabungkan dua catatan tanpa membuat klaim yang melampaui pengamatan. Bukti teks: “After reading both notes, students can synthesize the information without making claims that go beyond what they observed.”
- **B. Copy one sentence without considering the other note** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copy one sentence without considering the other note”. Bukti yang menjawab pertanyaan adalah “After reading both notes, students can synthesize the information without making claims that go beyond what they observed.”, dan bukti itu mendukung “Combine information from different sources to form an overall understanding”, bukan opsi ini.
- **C. Remove all information that seems different** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove all information that seems different”. Bukti yang menjawab pertanyaan adalah “After reading both notes, students can synthesize the information without making claims that go beyond what they observed.”, dan bukti itu mendukung “Combine information from different sources to form an overall understanding”, bukan opsi ini.
- **D. Choose the longest note and ignore the shorter one** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the longest note and ignore the shorter one”. Bukti yang menjawab pertanyaan adalah “After reading both notes, students can synthesize the information without making claims that go beyond what they observed.”, dan bukti itu mendukung “Combine information from different sources to form an overall understanding”, bukan opsi ini.

---

### W12S1-Q27 — not_mentioned (medium)
**Stimulus:** W12S1-T3

**Question:** Which statement is NOT mentioned in the energy-check report?

- **A.** The club replaced every classroom fan with a new model
- **B.** One classroom had wide windows and needed fewer lights in the morning
- **C.** The club suggested checking room conditions before using electrical equipment
- **D.** Members checked which lights and fans were on in empty rooms

**Jawaban:** A. The club replaced every classroom fan with a new model

**Pembahasan:** Pernyataan tersebut tidak muncul dalam teks dan berbeda dari tindakan yang benar-benar dilakukan.

**Bukti teks:** “At the start, members noted which lights and fans were on when rooms were empty.”; “One classroom had wide windows and needed fewer lights in the morning.”; “In the final report, the club suggested checking room conditions before using electrical equipment.”

**Alasan setiap opsi:**
- **A. The club replaced every classroom fan with a new model** — Benar. Pernyataan tersebut tidak muncul dalam teks dan berbeda dari tindakan yang benar-benar dilakukan. Bukti teks: “At the start, members noted which lights and fans were on when rooms were empty.”; “One classroom had wide windows and needed fewer lights in the morning.”; “In the final report, the club suggested checking room conditions before using electrical equipment.”
- **B. One classroom had wide windows and needed fewer lights in the morning** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.
- **C. The club suggested checking room conditions before using electrical equipment** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.
- **D. Members checked which lights and fans were on in empty rooms** — Tidak tepat. Opsi ini tidak dicantumkan sebagai instruksi dalam stimulus; periksa keseluruhan daftar tindakan untuk memastikan pilihan yang benar-benar tidak disebutkan.

---

### W12S1-Q28 — explicit_detail (developing)
**Stimulus:** W12S1-T5

**Question:** What did the group record about the birds?

- **A.** The number of nests in every wetland
- **B.** The places where birds were most active
- **C.** The direction of every bird’s migration
- **D.** The exact age of every bird

**Jawaban:** B. The places where birds were most active

**Pembahasan:** Informasi ini disebutkan langsung dalam catatan siswa.

**Bukti teks:** “We recorded the places where birds were most active.”

**Alasan setiap opsi:**
- **A. The number of nests in every wetland** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The number of nests in every wetland”. Bukti yang menjawab pertanyaan adalah “We recorded the places where birds were most active.”, dan bukti itu mendukung “The places where birds were most active”, bukan opsi ini.
- **B. The places where birds were most active** — Benar. Informasi ini disebutkan langsung dalam catatan siswa. Bukti teks: “We recorded the places where birds were most active.”
- **C. The direction of every bird’s migration** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The direction of every bird’s migration”. Bukti yang menjawab pertanyaan adalah “We recorded the places where birds were most active.”, dan bukti itu mendukung “The places where birds were most active”, bukan opsi ini.
- **D. The exact age of every bird** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The exact age of every bird”. Bukti yang menjawab pertanyaan adalah “We recorded the places where birds were most active.”, dan bukti itu mendukung “The places where birds were most active”, bukan opsi ini.

---

### W12S1-Q29 — supported_conclusion (medium)
**Stimulus:** W12S1-T5

**Question:** Why should the students avoid describing the whole wetland from this short visit alone?

- **A.** Because a short visit cannot show every seasonal change or all conditions in the area
- **B.** Because the guide confirmed that wetland conditions never change across seasons
- **C.** Because the student group observed only one part of the wetland
- **D.** Because the guide says every wetland has identical conditions

**Jawaban:** A. Because a short visit cannot show every seasonal change or all conditions in the area

**Pembahasan:** Kesimpulan harus dibatasi oleh cakupan bukti: satu kunjungan singkat tidak mewakili seluruh waktu dan tempat.

**Bukti teks:** “A short visit cannot show every seasonal change” and “conditions vary from one wetland to another.”

**Alasan setiap opsi:**
- **A. Because a short visit cannot show every seasonal change or all conditions in the area** — Benar. Kesimpulan harus dibatasi oleh cakupan bukti: satu kunjungan singkat tidak mewakili seluruh waktu dan tempat. Bukti teks: “A short visit cannot show every seasonal change” and “conditions vary from one wetland to another.”
- **B. Because the guide confirmed that wetland conditions never change across seasons** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because the guide confirmed that wetland conditions never change across seasons”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change” and “conditions vary from one wetland to another.”, dan bukti itu mendukung “Because a short visit cannot show every seasonal change or all conditions in the area”, bukan opsi ini.
- **C. Because the student group observed only one part of the wetland** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because the student group observed only one part of the wetland”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change” and “conditions vary from one wetland to another.”, dan bukti itu mendukung “Because a short visit cannot show every seasonal change or all conditions in the area”, bukan opsi ini.
- **D. Because the guide says every wetland has identical conditions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Because the guide says every wetland has identical conditions”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change” and “conditions vary from one wetland to another.”, dan bukti itu mendukung “Because a short visit cannot show every seasonal change or all conditions in the area”, bukan opsi ini.

---

### W12S1-Q30 — strategy_transfer (medium)
**Stimulus:** W12S1-T5

**Question:** You are asked to decide whether the group’s observations describe every wetland. What is the best strategy?

- **A.** Choose the option that repeats the word “wetland” most often
- **B.** Use only the student note because it contains first-hand observations
- **C.** Ignore the guide’s note because it is shorter
- **D.** Combine both notes and check the guide’s limitations before making a conclusion

**Jawaban:** D. Combine both notes and check the guide’s limitations before making a conclusion

**Pembahasan:** Strategi yang tepat adalah menggabungkan informasi kedua sumber dan memperhatikan batas bukti agar tidak membuat generalisasi berlebihan.

**Bukti teks:** “A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area.”

**Alasan setiap opsi:**
- **A. Choose the option that repeats the word “wetland” most often** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the option that repeats the word “wetland” most often”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area.”, dan bukti itu mendukung “Combine both notes and check the guide’s limitations before making a conclusion”, bukan opsi ini.
- **B. Use only the student note because it contains first-hand observations** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use only the student note because it contains first-hand observations”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area.”, dan bukti itu mendukung “Combine both notes and check the guide’s limitations before making a conclusion”, bukan opsi ini.
- **C. Ignore the guide’s note because it is shorter** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore the guide’s note because it is shorter”. Bukti yang menjawab pertanyaan adalah “A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area.”, dan bukti itu mendukung “Combine both notes and check the guide’s limitations before making a conclusion”, bukan opsi ini.
- **D. Combine both notes and check the guide’s limitations before making a conclusion** — Benar. Strategi yang tepat adalah menggabungkan informasi kedua sumber dan memperhatikan batas bukti agar tidak membuat generalisasi berlebihan. Bukti teks: “A short visit cannot show every seasonal change, and one group's observations should not be treated as a complete description of the whole area.”

---

# W12-ONLINE-02 — Mixed Reading Practice: Accuracy, Review and Pacing
**Week:** 12 · **Questions:** 30 · **Difficulty:** Easy 3 / Developing 10 / Medium 17

## Stimuli

### W12S2-T1 — Choosing a Study Resource (Review / informational text; 110 words)

```text
A student group compared three resources for a reading project. The first was a short printed guide with clear headings and a small glossary. The second was a long article with useful examples but few subheadings. The third was a video with captions and a short summary at the end. The group did not decide that one format was best for every learner. Instead, they matched each resource to a task: the guide helped students locate key terms, the article offered more detail, and the video showed a process that was difficult to imagine from words alone. They planned to review their notes before choosing evidence for the final presentation.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W12S2-T2 — End-of-Unit Practice Instructions (Instructional notice; 81 words)

```text
READING PRACTICE — FINAL CHECK
You have 25 minutes for this practice set. Allocate your time sensibly and prioritize questions that you can answer with clear evidence. Do not spend too long on one difficult item; make a note and continue, then return if time remains. Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility. Accuracy matters more than speed alone. Reading stamina develops through regular practice, so reflect on your progress after the set.
```

*Scenario note:* Nama, sekolah, jadwal, angka, hasil kegiatan, dan tokoh khusus merupakan skenario fiktif untuk latihan. Fakta umum yang dipakai sebagai konteks dirujuk pada source_basis.

### W12S2-T3 — A Reading Resource Trial (Informational report / comparison; 116 words)

```text
A class tested three resources before preparing a short report. A printed guide had clear headings and a glossary, so students could locate key terms quickly. A longer article included more examples and explained the topic in greater detail, but its sections were not easy to scan. A short video showed the steps of a process that was difficult to picture from written instructions alone. The class decided that no single resource was best for every task. Students first identified what they needed to find, then selected the resource that matched the purpose. They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.
```

*Scenario note:* Uji coba sumber dan keputusan kelompok merupakan skenario fiktif.

### W12S2-T4 — A Learner Reviews a Practice Session (Recount with reflective comment; 113 words)

```text
On Monday, Arif completed a mixed reading practice set. At first, he tried to answer every question quickly and did not check the passages carefully. He finished early but made several mistakes on questions containing NOT and EXCEPT. On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later. His score improved slightly, but he also noticed that he spent less time changing correct answers without a reason. After the session, he reflected on the errors and wrote down which strategies he needed to practise again. He understood that steady practice could build reading stamina as well as accuracy.
```

*Scenario note:* Tokoh, skor, waktu, dan hasil latihan merupakan skenario pembelajaran fiktif.

### W12S2-T5 — Library Skills Challenge: Instructions and Results (Instructional notice with short results table; 128 words)

```text
LIBRARY SKILLS CHALLENGE
Participants have 20 minutes to answer the reading set. Read each question first, identify the target, and locate evidence before choosing an option. If an item takes too long, mark it and continue. Return to marked items after completing the others. Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.

CLASS RESULTS
Group A: 12 items attempted; 9 correct; 3 left for review.
Group B: 12 items attempted; 10 correct; 2 left for review.
Group C: 12 items attempted; 8 correct; 4 left for review.

The teacher suggested that groups allocate the final few minutes to reviewing marked items. The teacher also reminded students that these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.
```

*Scenario note:* Aturan tantangan dan hasil tiga kelompok sepenuhnya fiktif untuk latihan membaca tabel dan teks.

## Vocabulary cards

- **accuracy** (noun; NEW) — ketepatan atau kecermatan. *Example:* Accuracy matters more than speed alone. *Synonym/related:* correctness, precision. *Contrast:* inaccuracy, error.
- **stamina** (noun; NEW) — daya tahan untuk terus melakukan kegiatan. *Example:* Reading stamina grows through regular practice. *Synonym/related:* endurance, staying power. *Contrast:* fatigue (contrast).
- **reflect** (verb; NEW) — merenungkan atau meninjau kembali. *Example:* Reflect on the questions that were difficult. *Synonym/related:* think over, review. *Contrast:* ignore, overlook.
- **progress** (noun/verb; NEW) — kemajuan; berkembang atau bergerak maju. *Example:* The teacher records each learner's progress. *Synonym/related:* improvement, development. *Contrast:* setback, decline.
- **allocate** (verb; RECYCLED) — membagi atau menetapkan bagian/sumber untuk tujuan tertentu. *Example:* Allocate enough time to each section. *Synonym/related:* assign, distribute. *Contrast:* withhold, gather.
- **prioritize** (verb; RECYCLED) — mendahulukan hal yang paling penting. *Example:* Prioritize questions that need careful evidence checks. *Synonym/related:* rank, give priority to. *Contrast:* neglect, deprioritize.
- **duration** (noun; RECYCLED) — lama waktu berlangsung. *Example:* The duration of the visit is three hours. *Synonym/related:* length of time, period. *Contrast:* —.
- **monitor** (verb; RECYCLED) — memantau atau mengamati perkembangan. *Example:* Monitor your time while completing the practice. *Synonym/related:* track, observe. *Contrast:* ignore, overlook.
- **verify** (verb; RECYCLED) — memeriksa untuk memastikan kebenaran. *Example:* Please verify the room number before leaving. *Synonym/related:* check, confirm. *Contrast:* assume, guess.
- **evidence** (noun; RECYCLED) — bukti. *Example:* The option needs evidence. *Synonym/related:* proof, support. *Contrast:* —.

## Answer key and explanations

### W12S2-Q01 — resource_selection (easy)
**Stimulus:** W12S2-T1

**Question:** Which resource is best for quickly locating key terms?

- **A.** The video with captions and a short summary
- **B.** The group’s notes prepared after comparing the resources
- **C.** The printed guide with clear headings and a glossary
- **D.** The long article with few subheadings

**Jawaban:** C. The printed guide with clear headings and a glossary

**Pembahasan:** Panduan tercetak memiliki judul bagian dan glosarium, sehingga cocok untuk menemukan istilah kunci.

**Bukti teks:** “the guide helped students locate key terms”

**Alasan setiap opsi:**
- **A. The video with captions and a short summary** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The video with captions and a short summary”. Bukti yang menjawab pertanyaan adalah “the guide helped students locate key terms”, dan bukti itu mendukung “The printed guide with clear headings and a glossary”, bukan opsi ini.
- **B. The group’s notes prepared after comparing the resources** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The group’s notes prepared after comparing the resources”. Bukti yang menjawab pertanyaan adalah “the guide helped students locate key terms”, dan bukti itu mendukung “The printed guide with clear headings and a glossary”, bukan opsi ini.
- **C. The printed guide with clear headings and a glossary** — Benar. Panduan tercetak memiliki judul bagian dan glosarium, sehingga cocok untuk menemukan istilah kunci. Bukti teks: “the guide helped students locate key terms”
- **D. The long article with few subheadings** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The long article with few subheadings”. Bukti yang menjawab pertanyaan adalah “the guide helped students locate key terms”, dan bukti itu mendukung “The printed guide with clear headings and a glossary”, bukan opsi ini.

---

### W12S2-Q02 — explicit_detail (developing)
**Stimulus:** W12S2-T1

**Question:** What did the group use the video for?

- **A.** To show a process that was difficult to imagine from words alone
- **B.** To summarize the main points in written form
- **C.** To help students locate key terms quickly
- **D.** To provide more detailed written examples

**Jawaban:** A. To show a process that was difficult to imagine from words alone

**Pembahasan:** Video dipilih untuk memperlihatkan proses yang sulit dibayangkan hanya melalui kata-kata.

**Bukti teks:** “the video showed a process that was difficult to imagine from words alone.”

**Alasan setiap opsi:**
- **A. To show a process that was difficult to imagine from words alone** — Benar. Video dipilih untuk memperlihatkan proses yang sulit dibayangkan hanya melalui kata-kata. Bukti teks: “the video showed a process that was difficult to imagine from words alone.”
- **B. To summarize the main points in written form** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To summarize the main points in written form”. Bukti yang menjawab pertanyaan adalah “the video showed a process that was difficult to imagine from words alone.”, dan bukti itu mendukung “To show a process that was difficult to imagine from words alone”, bukan opsi ini.
- **C. To help students locate key terms quickly** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To help students locate key terms quickly”. Bukti yang menjawab pertanyaan adalah “the video showed a process that was difficult to imagine from words alone.”, dan bukti itu mendukung “To show a process that was difficult to imagine from words alone”, bukan opsi ini.
- **D. To provide more detailed written examples** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To provide more detailed written examples”. Bukti yang menjawab pertanyaan adalah “the video showed a process that was difficult to imagine from words alone.”, dan bukti itu mendukung “To show a process that was difficult to imagine from words alone”, bukan opsi ini.

---

### W12S2-Q03 — strategy_detail (developing)
**Stimulus:** W12S2-T2

**Question:** According to the instructions, what should a student do when one item takes too long?

- **A.** Make a note, continue, and return if time remains
- **B.** Skip the item permanently and submit without revisiting it
- **C.** Ask for extra time before attempting another question
- **D.** Spend the remaining time on that item and leave later items unanswered

**Jawaban:** A. Make a note, continue, and return if time remains

**Pembahasan:** Instruksi menyarankan siswa mencatat soal sulit, melanjutkan, lalu kembali jika waktu tersisa.

**Bukti teks:** “make a note and continue, then return if time remains.”

**Alasan setiap opsi:**
- **A. Make a note, continue, and return if time remains** — Benar. Instruksi menyarankan siswa mencatat soal sulit, melanjutkan, lalu kembali jika waktu tersisa. Bukti teks: “make a note and continue, then return if time remains.”
- **B. Skip the item permanently and submit without revisiting it** — Tidak tepat. Teks meminta siswa menandai soal dan kembali jika waktu tersisa, bukan melewatkannya secara permanen.
- **C. Ask for extra time before attempting another question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ask for extra time before attempting another question”. Bukti yang menjawab pertanyaan adalah “make a note and continue, then return if time remains.”, dan bukti itu mendukung “Make a note, continue, and return if time remains”, bukan opsi ini.
- **D. Spend the remaining time on that item and leave later items unanswered** — Tidak tepat. Teks menyarankan agar siswa tidak menghabiskan terlalu banyak waktu pada satu soal; siswa diminta membuat catatan dan melanjutkan.

---

### W12S2-Q04 — strategy_detail (medium)
**Stimulus:** W12S2-T2

**Question:** Which option matches the full list of special checks in the instructions?

- **A.** Contrast markers only, without checking possibility words
- **B.** Dates, numbers, and titles, but not NOT/EXCEPT wording
- **C.** Only unfamiliar vocabulary and long answer choices
- **D.** NOT/EXCEPT, dates, numbers, contrast, and possibility words

**Jawaban:** D. NOT/EXCEPT, dates, numbers, contrast, and possibility words

**Pembahasan:** Instruksi menekankan penanda negatif, tanggal, angka, kontras, dan kemungkinan karena dapat mengubah makna.

**Bukti teks:** “check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”

**Alasan setiap opsi:**
- **A. Contrast markers only, without checking possibility words** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Contrast markers only, without checking possibility words”. Bukti yang menjawab pertanyaan adalah “check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”, dan bukti itu mendukung “NOT/EXCEPT, dates, numbers, contrast, and possibility words”, bukan opsi ini.
- **B. Dates, numbers, and titles, but not NOT/EXCEPT wording** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Dates, numbers, and titles, but not NOT/EXCEPT wording”. Bukti yang menjawab pertanyaan adalah “check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”, dan bukti itu mendukung “NOT/EXCEPT, dates, numbers, contrast, and possibility words”, bukan opsi ini.
- **C. Only unfamiliar vocabulary and long answer choices** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Only unfamiliar vocabulary and long answer choices”. Bukti yang menjawab pertanyaan adalah “check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”, dan bukti itu mendukung “NOT/EXCEPT, dates, numbers, contrast, and possibility words”, bukan opsi ini.
- **D. NOT/EXCEPT, dates, numbers, contrast, and possibility words** — Benar. Instruksi menekankan penanda negatif, tanggal, angka, kontras, dan kemungkinan karena dapat mengubah makna. Bukti teks: “check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”

---

### W12S2-Q05 — main_idea (medium)
**Stimulus:** W12S2-T1

**Question:** Which statement best reflects the group's approach to choosing resources?

- **A.** Videos are always more reliable than articles.
- **B.** Different formats can help with different tasks.
- **C.** Printed guides contain more detail than all articles.
- **D.** One format is best for every learner.

**Jawaban:** B. Different formats can help with different tasks.

**Pembahasan:** Gagasan utama adalah mencocokkan format sumber dengan kebutuhan tugas, bukan memilih satu format untuk semua orang.

**Bukti teks:** “The group did not decide that one format was best for every learner. Instead, they matched each resource to a task:”

**Alasan setiap opsi:**
- **A. Videos are always more reliable than articles.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Videos are always more reliable than articles.”. Bukti yang menjawab pertanyaan adalah “The group did not decide that one format was best for every learner. Instead, they matched each resource to a task:”, dan bukti itu mendukung “Different formats can help with different tasks.”, bukan opsi ini.
- **B. Different formats can help with different tasks.** — Benar. Gagasan utama adalah mencocokkan format sumber dengan kebutuhan tugas, bukan memilih satu format untuk semua orang. Bukti teks: “The group did not decide that one format was best for every learner. Instead, they matched each resource to a task:”
- **C. Printed guides contain more detail than all articles.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Printed guides contain more detail than all articles.”. Bukti yang menjawab pertanyaan adalah “The group did not decide that one format was best for every learner. Instead, they matched each resource to a task:”, dan bukti itu mendukung “Different formats can help with different tasks.”, bukan opsi ini.
- **D. One format is best for every learner.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “One format is best for every learner.”. Bukti yang menjawab pertanyaan adalah “The group did not decide that one format was best for every learner. Instead, they matched each resource to a task:”, dan bukti itu mendukung “Different formats can help with different tasks.”, bukan opsi ini.

---

### W12S2-Q06 — purpose_and_evidence (medium)
**Stimulus:** W12S2-T1

**Question:** What is the purpose of reviewing notes before choosing evidence?

- **A.** To replace evidence with personal opinion
- **B.** To make the notes longer
- **C.** To check which information supports the presentation
- **D.** To avoid reading the sources

**Jawaban:** C. To check which information supports the presentation

**Pembahasan:** Catatan ditinjau sebelum memilih bukti agar informasi yang dipakai sesuai dengan presentasi.

**Bukti teks:** “They planned to review their notes before choosing evidence for the final presentation.”

**Alasan setiap opsi:**
- **A. To replace evidence with personal opinion** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To replace evidence with personal opinion”. Bukti yang menjawab pertanyaan adalah “They planned to review their notes before choosing evidence for the final presentation.”, dan bukti itu mendukung “To check which information supports the presentation”, bukan opsi ini.
- **B. To make the notes longer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To make the notes longer”. Bukti yang menjawab pertanyaan adalah “They planned to review their notes before choosing evidence for the final presentation.”, dan bukti itu mendukung “To check which information supports the presentation”, bukan opsi ini.
- **C. To check which information supports the presentation** — Benar. Catatan ditinjau sebelum memilih bukti agar informasi yang dipakai sesuai dengan presentasi. Bukti teks: “They planned to review their notes before choosing evidence for the final presentation.”
- **D. To avoid reading the sources** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To avoid reading the sources”. Bukti yang menjawab pertanyaan adalah “They planned to review their notes before choosing evidence for the final presentation.”, dan bukti itu mendukung “To check which information supports the presentation”, bukan opsi ini.

---

### W12S2-Q07 — gist_summary (medium)
**Stimulus:** W12S2-T2

**Question:** Which sentence best summarizes the practice instructions?

- **A.** Finish as quickly as possible, even if answers are inaccurate.
- **B.** Spend the same amount of time on every question.
- **C.** Never return to a passage after reading it.
- **D.** Use time sensibly, check difficult wording, and value accuracy as well as pace.

**Jawaban:** D. Use time sensibly, check difficult wording, and value accuracy as well as pace.

**Pembahasan:** Ringkasan yang tepat memuat pengelolaan waktu dan pemeriksaan akurasi, bukan kecepatan semata.

**Bukti teks:** “Do not spend too long on one difficult item; make a note and continue, then return if time remains.”; “Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”; “Accuracy matters more than speed alone.”

**Alasan setiap opsi:**
- **A. Finish as quickly as possible, even if answers are inaccurate.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Finish as quickly as possible, even if answers are inaccurate.”. Bukti yang menjawab pertanyaan adalah “Do not spend too long on one difficult item; make a note and continue, then return if time remains.”; “Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”; “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Use time sensibly, check difficult wording, and value accuracy as well as pace.”, bukan opsi ini.
- **B. Spend the same amount of time on every question.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Spend the same amount of time on every question.”. Bukti yang menjawab pertanyaan adalah “Do not spend too long on one difficult item; make a note and continue, then return if time remains.”; “Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”; “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Use time sensibly, check difficult wording, and value accuracy as well as pace.”, bukan opsi ini.
- **C. Never return to a passage after reading it.** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Never return to a passage after reading it.”. Bukti yang menjawab pertanyaan adalah “Do not spend too long on one difficult item; make a note and continue, then return if time remains.”; “Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”; “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Use time sensibly, check difficult wording, and value accuracy as well as pace.”, bukan opsi ini.
- **D. Use time sensibly, check difficult wording, and value accuracy as well as pace.** — Benar. Ringkasan yang tepat memuat pengelolaan waktu dan pemeriksaan akurasi, bukan kecepatan semata. Bukti teks: “Do not spend too long on one difficult item; make a note and continue, then return if time remains.”; “Before submitting, check questions with NOT, EXCEPT, dates, numbers, and words showing contrast or possibility.”; “Accuracy matters more than speed alone.”

---

### W12S2-Q08 — vocabulary_meaning (medium)
**Stimulus:** W12S2-T2

**Question:** What does “accuracy” mean?

- **A.** Reading as fast as possible
- **B.** Correctness or being free from mistakes
- **C.** The length of a practice session
- **D.** The number of pages in a book

**Jawaban:** B. Correctness or being free from mistakes

**Pembahasan:** Accuracy berarti ketepatan atau kecermatan.

**Bukti teks:** “Accuracy matters more than speed alone.”

**Alasan setiap opsi:**
- **A. Reading as fast as possible** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Reading as fast as possible”. Bukti yang menjawab pertanyaan adalah “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Correctness or being free from mistakes”, bukan opsi ini.
- **B. Correctness or being free from mistakes** — Benar. Accuracy berarti ketepatan atau kecermatan. Bukti teks: “Accuracy matters more than speed alone.”
- **C. The length of a practice session** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The length of a practice session”. Bukti yang menjawab pertanyaan adalah “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Correctness or being free from mistakes”, bukan opsi ini.
- **D. The number of pages in a book** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The number of pages in a book”. Bukti yang menjawab pertanyaan adalah “Accuracy matters more than speed alone.”, dan bukti itu mendukung “Correctness or being free from mistakes”, bukan opsi ini.

---

### W12S2-Q09 — vocabulary_meaning (developing)
**Stimulus:** W12S2-T2

**Question:** What does “stamina” mean in the context of reading practice?

- **A.** The ability to continue an activity over time
- **B.** A type of text structure
- **C.** A short break between questions
- **D.** A list of difficult words

**Jawaban:** A. The ability to continue an activity over time

**Pembahasan:** Stamina adalah daya tahan untuk terus melakukan kegiatan dalam waktu tertentu.

**Bukti teks:** “Reading stamina develops through regular practice”

**Alasan setiap opsi:**
- **A. The ability to continue an activity over time** — Benar. Stamina adalah daya tahan untuk terus melakukan kegiatan dalam waktu tertentu. Bukti teks: “Reading stamina develops through regular practice”
- **B. A type of text structure** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A type of text structure”. Bukti yang menjawab pertanyaan adalah “Reading stamina develops through regular practice”, dan bukti itu mendukung “The ability to continue an activity over time”, bukan opsi ini.
- **C. A short break between questions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A short break between questions”. Bukti yang menjawab pertanyaan adalah “Reading stamina develops through regular practice”, dan bukti itu mendukung “The ability to continue an activity over time”, bukan opsi ini.
- **D. A list of difficult words** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A list of difficult words”. Bukti yang menjawab pertanyaan adalah “Reading stamina develops through regular practice”, dan bukti itu mendukung “The ability to continue an activity over time”, bukan opsi ini.

---

### W12S2-Q10 — vocabulary_meaning (developing)
**Stimulus:** W12S2-T2

**Question:** What does “reflect on your progress” mean in the instructions?

- **A.** Compare only the answer length
- **B.** Copy them without checking
- **C.** Delete all your notes
- **D.** Think back about them and consider what was difficult

**Jawaban:** D. Think back about them and consider what was difficult

**Pembahasan:** Reflect berarti meninjau kembali dan memikirkan pengalaman atau hasil belajar.

**Bukti teks:** “reflect on your progress after the set.”

**Alasan setiap opsi:**
- **A. Compare only the answer length** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Compare only the answer length”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Think back about them and consider what was difficult”, bukan opsi ini.
- **B. Copy them without checking** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copy them without checking”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Think back about them and consider what was difficult”, bukan opsi ini.
- **C. Delete all your notes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Delete all your notes”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Think back about them and consider what was difficult”, bukan opsi ini.
- **D. Think back about them and consider what was difficult** — Benar. Reflect berarti meninjau kembali dan memikirkan pengalaman atau hasil belajar. Bukti teks: “reflect on your progress after the set.”

---

### W12S2-Q11 — vocabulary_meaning (medium)
**Stimulus:** W12S2-T2

**Question:** Which word is closest in meaning to “progress” in the passage?

- **A.** Delay
- **B.** Failure
- **C.** Development
- **D.** Confusion

**Jawaban:** C. Development

**Pembahasan:** Progress berarti kemajuan atau perkembangan.

**Bukti teks:** “reflect on your progress after the set.”

**Alasan setiap opsi:**
- **A. Delay** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Delay”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Development”, bukan opsi ini.
- **B. Failure** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Failure”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Development”, bukan opsi ini.
- **C. Development** — Benar. Progress berarti kemajuan atau perkembangan. Bukti teks: “reflect on your progress after the set.”
- **D. Confusion** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Confusion”. Bukti yang menjawab pertanyaan adalah “reflect on your progress after the set.”, dan bukti itu mendukung “Development”, bukan opsi ini.

---

### W12S2-Q12 — reflection_strategy (medium)
**Stimulus:** W12S2-T2

**Question:** After completing a mixed practice set, which action best supports improvement?

- **A.** Ignore the score and repeat the same answers
- **B.** Spend more time on questions already answered correctly
- **C.** Identify difficult items, check evidence, and plan what to review
- **D.** Memorize only the option letters

**Jawaban:** C. Identify difficult items, check evidence, and plan what to review

**Pembahasan:** Perbaikan membutuhkan refleksi, pemeriksaan bukti, dan penentuan bagian yang perlu dipelajari kembali.

**Bukti teks:** “make a note and continue, then return if time remains”; “reflect on your progress after the set.”

**Alasan setiap opsi:**
- **A. Ignore the score and repeat the same answers** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignore the score and repeat the same answers”. Bukti yang menjawab pertanyaan adalah “make a note and continue, then return if time remains”; “reflect on your progress after the set.”, dan bukti itu mendukung “Identify difficult items, check evidence, and plan what to review”, bukan opsi ini.
- **B. Spend more time on questions already answered correctly** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Spend more time on questions already answered correctly”. Bukti yang menjawab pertanyaan adalah “make a note and continue, then return if time remains”; “reflect on your progress after the set.”, dan bukti itu mendukung “Identify difficult items, check evidence, and plan what to review”, bukan opsi ini.
- **C. Identify difficult items, check evidence, and plan what to review** — Benar. Perbaikan membutuhkan refleksi, pemeriksaan bukti, dan penentuan bagian yang perlu dipelajari kembali. Bukti teks: “make a note and continue, then return if time remains”; “reflect on your progress after the set.”
- **D. Memorize only the option letters** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Memorize only the option letters”. Bukti yang menjawab pertanyaan adalah “make a note and continue, then return if time remains”; “reflect on your progress after the set.”, dan bukti itu mendukung “Identify difficult items, check evidence, and plan what to review”, bukan opsi ini.

---

### W12S2-Q13 — main_idea (medium)
**Stimulus:** W12S2-T3

**Question:** Which statement best summarizes the class’s approach to selecting reading resources?

- **A.** Select a resource before reading the question
- **B.** Match each resource to the information or task students need
- **C.** Choose the longest resource for every reading task
- **D.** Use videos and avoid all written materials

**Jawaban:** B. Match each resource to the information or task students need

**Pembahasan:** Gagasan utama laporan adalah memilih sumber berdasarkan kebutuhan tugas, bukan berdasarkan format yang selalu dianggap terbaik.

**Bukti teks:** “The class decided that no single resource was best for every task.”; “Students first identified what they needed to find, then selected the resource that matched the purpose.”

**Alasan setiap opsi:**
- **A. Select a resource before reading the question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Select a resource before reading the question”. Bukti yang menjawab pertanyaan adalah “The class decided that no single resource was best for every task.”; “Students first identified what they needed to find, then selected the resource that matched the purpose.”, dan bukti itu mendukung “Match each resource to the information or task students need”, bukan opsi ini.
- **B. Match each resource to the information or task students need** — Benar. Gagasan utama laporan adalah memilih sumber berdasarkan kebutuhan tugas, bukan berdasarkan format yang selalu dianggap terbaik. Bukti teks: “The class decided that no single resource was best for every task.”; “Students first identified what they needed to find, then selected the resource that matched the purpose.”
- **C. Choose the longest resource for every reading task** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Choose the longest resource for every reading task”. Bukti yang menjawab pertanyaan adalah “The class decided that no single resource was best for every task.”; “Students first identified what they needed to find, then selected the resource that matched the purpose.”, dan bukti itu mendukung “Match each resource to the information or task students need”, bukan opsi ini.
- **D. Use videos and avoid all written materials** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use videos and avoid all written materials”. Bukti yang menjawab pertanyaan adalah “The class decided that no single resource was best for every task.”; “Students first identified what they needed to find, then selected the resource that matched the purpose.”, dan bukti itu mendukung “Match each resource to the information or task students need”, bukan opsi ini.

---

### W12S2-Q14 — explicit_detail (developing)
**Stimulus:** W12S2-T3

**Question:** Which feature helped students locate key terms in the printed guide?

- **A.** Clear headings and a glossary
- **B.** A video showing each process step
- **C.** A list of results from the class trial
- **D.** A longer explanation with many examples

**Jawaban:** A. Clear headings and a glossary

**Pembahasan:** Judul bagian yang jelas dan glosarium membuat istilah kunci lebih mudah ditemukan.

**Bukti teks:** “A printed guide had clear headings and a glossary, so students could locate key terms quickly.”

**Alasan setiap opsi:**
- **A. Clear headings and a glossary** — Benar. Judul bagian yang jelas dan glosarium membuat istilah kunci lebih mudah ditemukan. Bukti teks: “A printed guide had clear headings and a glossary, so students could locate key terms quickly.”
- **B. A video showing each process step** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A video showing each process step”. Bukti yang menjawab pertanyaan adalah “A printed guide had clear headings and a glossary, so students could locate key terms quickly.”, dan bukti itu mendukung “Clear headings and a glossary”, bukan opsi ini.
- **C. A list of results from the class trial** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A list of results from the class trial”. Bukti yang menjawab pertanyaan adalah “A printed guide had clear headings and a glossary, so students could locate key terms quickly.”, dan bukti itu mendukung “Clear headings and a glossary”, bukan opsi ini.
- **D. A longer explanation with many examples** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A longer explanation with many examples”. Bukti yang menjawab pertanyaan adalah “A printed guide had clear headings and a glossary, so students could locate key terms quickly.”, dan bukti itu mendukung “Clear headings and a glossary”, bukan opsi ini.

---

### W12S2-Q15 — resource_selection (medium)
**Stimulus:** W12S2-T3

**Question:** A student needs to understand the steps of a process that is difficult to imagine from written instructions. Which resource is most suitable according to the passage?

- **A.** The class results table
- **B.** The longer article with more examples
- **C.** The printed guide with a glossary
- **D.** The short video

**Jawaban:** D. The short video

**Pembahasan:** Video dipilih karena dapat menunjukkan proses yang sulit dibayangkan hanya melalui kata-kata.

**Bukti teks:** “A short video showed the steps of a process that was difficult to picture from written instructions alone.”

**Alasan setiap opsi:**
- **A. The class results table** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The class results table”. Bukti yang menjawab pertanyaan adalah “A short video showed the steps of a process that was difficult to picture from written instructions alone.”, dan bukti itu mendukung “The short video”, bukan opsi ini.
- **B. The longer article with more examples** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The longer article with more examples”. Bukti yang menjawab pertanyaan adalah “A short video showed the steps of a process that was difficult to picture from written instructions alone.”, dan bukti itu mendukung “The short video”, bukan opsi ini.
- **C. The printed guide with a glossary** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The printed guide with a glossary”. Bukti yang menjawab pertanyaan adalah “A short video showed the steps of a process that was difficult to picture from written instructions alone.”, dan bukti itu mendukung “The short video”, bukan opsi ini.
- **D. The short video** — Benar. Video dipilih karena dapat menunjukkan proses yang sulit dibayangkan hanya melalui kata-kata. Bukti teks: “A short video showed the steps of a process that was difficult to picture from written instructions alone.”

---

### W12S2-Q16 — vocabulary_in_context (easy)
**Stimulus:** W12S2-T3

**Question:** In the sentence “They monitored whether each resource supported the task,” what does “monitored” mean?

- **A.** Replaced with another resource
- **B.** Checked or observed over time
- **C.** Purchased for the task
- **D.** Forgot or ignored

**Jawaban:** B. Checked or observed over time

**Pembahasan:** Monitor berarti memantau atau memeriksa perkembangan/keadaan dari waktu ke waktu. Dalam teks, siswa memeriksa apakah setiap sumber mendukung tugas mereka.

**Bukti teks:** “They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.”

**Alasan setiap opsi:**
- **A. Replaced with another resource** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Replaced with another resource”. Bukti yang menjawab pertanyaan adalah “They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.”, dan bukti itu mendukung “Checked or observed over time”, bukan opsi ini.
- **B. Checked or observed over time** — Benar. Monitor berarti memantau atau memeriksa perkembangan/keadaan dari waktu ke waktu. Dalam teks, siswa memeriksa apakah setiap sumber mendukung tugas mereka. Bukti teks: “They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.”
- **C. Purchased for the task** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Purchased for the task”. Bukti yang menjawab pertanyaan adalah “They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.”, dan bukti itu mendukung “Checked or observed over time”, bukan opsi ini.
- **D. Forgot or ignored** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Forgot or ignored”. Bukti yang menjawab pertanyaan adalah “They kept brief notes, monitored whether each resource supported the task, and checked important claims against the material rather than relying on memory.”, dan bukti itu mendukung “Checked or observed over time”, bukan opsi ini.

---

### W12S2-Q17 — sequence (easy)
**Stimulus:** W12S2-T4

**Question:** What did Arif do after marking the two difficult items?

- **A.** He stopped the practice completely
- **B.** He continued with questions he could support with clear evidence
- **C.** He asked the teacher to remove the questions
- **D.** He changed every answer immediately

**Jawaban:** B. He continued with questions he could support with clear evidence

**Pembahasan:** Setelah menandai dua soal sulit, Arif mengerjakan soal lain yang memiliki bukti jelas dan kembali kemudian.

**Bukti teks:** “On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”

**Alasan setiap opsi:**
- **A. He stopped the practice completely** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He stopped the practice completely”. Bukti yang menjawab pertanyaan adalah “On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He continued with questions he could support with clear evidence”, bukan opsi ini.
- **B. He continued with questions he could support with clear evidence** — Benar. Setelah menandai dua soal sulit, Arif mengerjakan soal lain yang memiliki bukti jelas dan kembali kemudian. Bukti teks: “On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”
- **C. He asked the teacher to remove the questions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He asked the teacher to remove the questions”. Bukti yang menjawab pertanyaan adalah “On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He continued with questions he could support with clear evidence”, bukan opsi ini.
- **D. He changed every answer immediately** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He changed every answer immediately”. Bukti yang menjawab pertanyaan adalah “On the next attempt, he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He continued with questions he could support with clear evidence”, bukan opsi ini.

---

### W12S2-Q18 — vocabulary_in_context (developing)
**Stimulus:** W12S2-T4

**Question:** What does “reflected on the errors” mean in the passage?

- **A.** Removed the practice results
- **B.** Copied the errors into every answer
- **C.** Thought carefully about the mistakes to learn from them
- **D.** Ignored the errors and continued

**Jawaban:** C. Thought carefully about the mistakes to learn from them

**Pembahasan:** Arif meninjau kesalahannya dan mencatat strategi yang perlu dilatih lagi.

**Bukti teks:** “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”

**Alasan setiap opsi:**
- **A. Removed the practice results** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Removed the practice results”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Thought carefully about the mistakes to learn from them”, bukan opsi ini.
- **B. Copied the errors into every answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Copied the errors into every answer”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Thought carefully about the mistakes to learn from them”, bukan opsi ini.
- **C. Thought carefully about the mistakes to learn from them** — Benar. Arif meninjau kesalahannya dan mencatat strategi yang perlu dilatih lagi. Bukti teks: “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”
- **D. Ignored the errors and continued** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ignored the errors and continued”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Thought carefully about the mistakes to learn from them”, bukan opsi ini.

---

### W12S2-Q19 — strategy_transfer (medium)
**Stimulus:** W12S2-T4

**Question:** You want to improve after receiving a score from one practice session. What should you do first?

- **A.** Memorize the correct option letters
- **B.** Review the errors and identify which strategies need more practice
- **C.** Avoid all difficult questions in future sessions
- **D.** Assume the score proves your permanent reading level

**Jawaban:** B. Review the errors and identify which strategies need more practice

**Pembahasan:** Tinjau kesalahan untuk menemukan strategi yang perlu diperbaiki. Skor satu sesi tidak cukup untuk menyimpulkan kemampuan secara tetap.

**Bukti teks:** “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”

**Alasan setiap opsi:**
- **A. Memorize the correct option letters** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Memorize the correct option letters”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Review the errors and identify which strategies need more practice”, bukan opsi ini.
- **B. Review the errors and identify which strategies need more practice** — Benar. Tinjau kesalahan untuk menemukan strategi yang perlu diperbaiki. Skor satu sesi tidak cukup untuk menyimpulkan kemampuan secara tetap. Bukti teks: “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”
- **C. Avoid all difficult questions in future sessions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Avoid all difficult questions in future sessions”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Review the errors and identify which strategies need more practice”, bukan opsi ini.
- **D. Assume the score proves your permanent reading level** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Assume the score proves your permanent reading level”. Bukti yang menjawab pertanyaan adalah “After the session, he reflected on the errors and wrote down which strategies he needed to practise again.”, dan bukti itu mendukung “Review the errors and identify which strategies need more practice”, bukan opsi ini.

---

### W12S2-Q20 — explicit_detail (medium)
**Stimulus:** W12S2-T5

**Question:** How much time do participants have for the Library Skills Challenge?

- **A.** 15 minutes
- **B.** 25 minutes
- **C.** 30 minutes
- **D.** 20 minutes

**Jawaban:** D. 20 minutes

**Pembahasan:** Batas waktu peserta adalah 20 menit.

**Bukti teks:** “Participants have 20 minutes to answer the reading set.”

**Alasan setiap opsi:**
- **A. 15 minutes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “15 minutes”. Bukti yang menjawab pertanyaan adalah “Participants have 20 minutes to answer the reading set.”, dan bukti itu mendukung “20 minutes”, bukan opsi ini.
- **B. 25 minutes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “25 minutes”. Bukti yang menjawab pertanyaan adalah “Participants have 20 minutes to answer the reading set.”, dan bukti itu mendukung “20 minutes”, bukan opsi ini.
- **C. 30 minutes** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “30 minutes”. Bukti yang menjawab pertanyaan adalah “Participants have 20 minutes to answer the reading set.”, dan bukti itu mendukung “20 minutes”, bukan opsi ini.
- **D. 20 minutes** — Benar. Batas waktu peserta adalah 20 menit. Bukti teks: “Participants have 20 minutes to answer the reading set.”

---

### W12S2-Q21 — instruction_sequence (developing)
**Stimulus:** W12S2-T5

**Question:** What should students do if an item takes too long?

- **A.** Submit the practice without answering anything else
- **B.** Mark it, continue, and return after completing other items
- **C.** Spend all the remaining time on that item
- **D.** Ask another student to choose an answer

**Jawaban:** B. Mark it, continue, and return after completing other items

**Pembahasan:** Instruksi menyarankan menandai soal, melanjutkan, lalu kembali setelah menyelesaikan soal lain.

**Bukti teks:** “If an item takes too long, mark it and continue. Return to marked items after completing the others.”

**Alasan setiap opsi:**
- **A. Submit the practice without answering anything else** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Submit the practice without answering anything else”. Bukti yang menjawab pertanyaan adalah “If an item takes too long, mark it and continue. Return to marked items after completing the others.”, dan bukti itu mendukung “Mark it, continue, and return after completing other items”, bukan opsi ini.
- **B. Mark it, continue, and return after completing other items** — Benar. Instruksi menyarankan menandai soal, melanjutkan, lalu kembali setelah menyelesaikan soal lain. Bukti teks: “If an item takes too long, mark it and continue. Return to marked items after completing the others.”
- **C. Spend all the remaining time on that item** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Spend all the remaining time on that item”. Bukti yang menjawab pertanyaan adalah “If an item takes too long, mark it and continue. Return to marked items after completing the others.”, dan bukti itu mendukung “Mark it, continue, and return after completing other items”, bukan opsi ini.
- **D. Ask another student to choose an answer** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ask another student to choose an answer”. Bukti yang menjawab pertanyaan adalah “If an item takes too long, mark it and continue. Return to marked items after completing the others.”, dan bukti itu mendukung “Mark it, continue, and return after completing other items”, bukan opsi ini.

---

### W12S2-Q22 — table_interpretation (medium)
**Stimulus:** W12S2-T5

**Question:** Which group had the highest number of correct answers?

- **A.** Group A
- **B.** Group C
- **C.** All groups had the same number
- **D.** Group B

**Jawaban:** D. Group B

**Pembahasan:** Group B memiliki 10 jawaban benar, lebih banyak daripada Group A (9) dan Group C (8).

**Bukti teks:** “Group A: 12 items attempted; 9 correct; 3 left for review.”; “Group B: 12 items attempted; 10 correct; 2 left for review.”; “Group C: 12 items attempted; 8 correct; 4 left for review.”

**Alasan setiap opsi:**
- **A. Group A** — Tidak tepat. Detail “Group A” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Group A: 12 items attempted; 9 correct; 3 left for review.”; “Group B: 12 items attempted; 10 correct; 2 left for review.”; “Group C: 12 items attempted; 8 correct; 4 left for review.”, yang mendukung “Group B”.
- **B. Group C** — Tidak tepat. Detail “Group C” memang muncul dalam salah satu stimulus terkait, tetapi tidak menjawab target pertanyaan ini. Bukti yang menjawab pertanyaan adalah “Group A: 12 items attempted; 9 correct; 3 left for review.”; “Group B: 12 items attempted; 10 correct; 2 left for review.”; “Group C: 12 items attempted; 8 correct; 4 left for review.”, yang mendukung “Group B”.
- **C. All groups had the same number** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “All groups had the same number”. Bukti yang menjawab pertanyaan adalah “Group A: 12 items attempted; 9 correct; 3 left for review.”; “Group B: 12 items attempted; 10 correct; 2 left for review.”; “Group C: 12 items attempted; 8 correct; 4 left for review.”, dan bukti itu mendukung “Group B”, bukan opsi ini.
- **D. Group B** — Benar. Group B memiliki 10 jawaban benar, lebih banyak daripada Group A (9) dan Group C (8). Bukti teks: “Group A: 12 items attempted; 9 correct; 3 left for review.”; “Group B: 12 items attempted; 10 correct; 2 left for review.”; “Group C: 12 items attempted; 8 correct; 4 left for review.”

---

### W12S2-Q23 — vocabulary_in_context (medium)
**Stimulus:** W12S2-T4

**Question:** In the passage, what does “accuracy” refer to?

- **A.** How quickly a learner completes the questions
- **B.** How many questions appear on the screen
- **C.** How correct the answers are
- **D.** How long the passage is

**Jawaban:** C. How correct the answers are

**Pembahasan:** Teks membedakan ketepatan dari kecepatan; accuracy mengacu pada jawaban yang benar dan minim kesalahan.

**Bukti teks:** “He understood that steady practice could build reading stamina as well as accuracy.”

**Alasan setiap opsi:**
- **A. How quickly a learner completes the questions** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “How quickly a learner completes the questions”. Bukti yang menjawab pertanyaan adalah “He understood that steady practice could build reading stamina as well as accuracy.”, dan bukti itu mendukung “How correct the answers are”, bukan opsi ini.
- **B. How many questions appear on the screen** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “How many questions appear on the screen”. Bukti yang menjawab pertanyaan adalah “He understood that steady practice could build reading stamina as well as accuracy.”, dan bukti itu mendukung “How correct the answers are”, bukan opsi ini.
- **C. How correct the answers are** — Benar. Teks membedakan ketepatan dari kecepatan; accuracy mengacu pada jawaban yang benar dan minim kesalahan. Bukti teks: “He understood that steady practice could build reading stamina as well as accuracy.”
- **D. How long the passage is** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “How long the passage is”. Bukti yang menjawab pertanyaan adalah “He understood that steady practice could build reading stamina as well as accuracy.”, dan bukti itu mendukung “How correct the answers are”, bukan opsi ini.

---

### W12S2-Q24 — main_purpose (developing)
**Stimulus:** W12S2-T5

**Question:** What is the main purpose of the Library Skills Challenge notice?

- **A.** To introduce a new set of library rules
- **B.** To compare the performance of three groups
- **C.** To explain why every question must be answered in the order shown
- **D.** To tell participants how to complete the practice and review their work

**Jawaban:** D. To tell participants how to complete the practice and review their work

**Pembahasan:** Tujuan utama adalah memberi petunjuk pengerjaan dan pemeriksaan sebelum mengumpulkan latihan.

**Bukti teks:** “Read each question first, identify the target, and locate evidence before choosing an option.”; “If an item takes too long, mark it and continue. Return to marked items after completing the others.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”

**Alasan setiap opsi:**
- **A. To introduce a new set of library rules** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To introduce a new set of library rules”. Bukti yang menjawab pertanyaan adalah “Read each question first, identify the target, and locate evidence before choosing an option.”; “If an item takes too long, mark it and continue. Return to marked items after completing the others.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”, dan bukti itu mendukung “To tell participants how to complete the practice and review their work”, bukan opsi ini.
- **B. To compare the performance of three groups** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To compare the performance of three groups”. Bukti yang menjawab pertanyaan adalah “Read each question first, identify the target, and locate evidence before choosing an option.”; “If an item takes too long, mark it and continue. Return to marked items after completing the others.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”, dan bukti itu mendukung “To tell participants how to complete the practice and review their work”, bukan opsi ini.
- **C. To explain why every question must be answered in the order shown** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “To explain why every question must be answered in the order shown”. Bukti yang menjawab pertanyaan adalah “Read each question first, identify the target, and locate evidence before choosing an option.”; “If an item takes too long, mark it and continue. Return to marked items after completing the others.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”, dan bukti itu mendukung “To tell participants how to complete the practice and review their work”, bukan opsi ini.
- **D. To tell participants how to complete the practice and review their work** — Benar. Tujuan utama adalah memberi petunjuk pengerjaan dan pemeriksaan sebelum mengumpulkan latihan. Bukti teks: “Read each question first, identify the target, and locate evidence before choosing an option.”; “If an item takes too long, mark it and continue. Return to marked items after completing the others.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”

---

### W12S2-Q25 — evidence_based_conclusion (medium)
**Stimulus:** W12S2-T4

**Question:** Which statement best describes what changed in Arif’s second attempt?

- **A.** He used a more deliberate approach by marking difficult items and checking evidence
- **B.** He stopped making mistakes on every question
- **C.** He no longer needed to review his answers
- **D.** He completed the work faster by skipping all evidence checks

**Jawaban:** A. He used a more deliberate approach by marking difficult items and checking evidence

**Pembahasan:** Perubahan yang dinyatakan adalah mengatur urutan pengerjaan dan menggunakan bukti; teks tidak menyatakan semua kesalahan hilang.

**Bukti teks:** “he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”

**Alasan setiap opsi:**
- **A. He used a more deliberate approach by marking difficult items and checking evidence** — Benar. Perubahan yang dinyatakan adalah mengatur urutan pengerjaan dan menggunakan bukti; teks tidak menyatakan semua kesalahan hilang. Bukti teks: “he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”
- **B. He stopped making mistakes on every question** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He stopped making mistakes on every question”. Bukti yang menjawab pertanyaan adalah “he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He used a more deliberate approach by marking difficult items and checking evidence”, bukan opsi ini.
- **C. He no longer needed to review his answers** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He no longer needed to review his answers”. Bukti yang menjawab pertanyaan adalah “he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He used a more deliberate approach by marking difficult items and checking evidence”, bukan opsi ini.
- **D. He completed the work faster by skipping all evidence checks** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “He completed the work faster by skipping all evidence checks”. Bukti yang menjawab pertanyaan adalah “he marked two difficult items, continued with questions he could support with clear evidence, and returned to the marked items later.”, dan bukti itu mendukung “He used a more deliberate approach by marking difficult items and checking evidence”, bukan opsi ini.

---

### W12S2-Q26 — vocabulary_meaning (developing)
**Stimulus:** W12S2-T5

**Question:** In the sentence “The teacher suggested that groups allocate the final few minutes to reviewing marked items,” what does “allocate” mean?

- **A.** Set aside part of a resource for a purpose
- **B.** Compare two resources with one another
- **C.** Remove a task from the schedule
- **D.** Use every available minute without a plan

**Jawaban:** A. Set aside part of a resource for a purpose

**Pembahasan:** Allocate berarti menetapkan atau membagi sebagian sumber daya untuk tujuan tertentu. Dalam teks, kelompok menyisihkan beberapa menit untuk meninjau soal yang ditandai.

**Bukti teks:** “The teacher suggested that groups allocate the final few minutes to reviewing marked items.”

**Alasan setiap opsi:**
- **A. Set aside part of a resource for a purpose** — Benar. Allocate berarti menetapkan atau membagi sebagian sumber daya untuk tujuan tertentu. Dalam teks, kelompok menyisihkan beberapa menit untuk meninjau soal yang ditandai. Bukti teks: “The teacher suggested that groups allocate the final few minutes to reviewing marked items.”
- **B. Compare two resources with one another** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Compare two resources with one another”. Bukti yang menjawab pertanyaan adalah “The teacher suggested that groups allocate the final few minutes to reviewing marked items.”, dan bukti itu mendukung “Set aside part of a resource for a purpose”, bukan opsi ini.
- **C. Remove a task from the schedule** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Remove a task from the schedule”. Bukti yang menjawab pertanyaan adalah “The teacher suggested that groups allocate the final few minutes to reviewing marked items.”, dan bukti itu mendukung “Set aside part of a resource for a purpose”, bukan opsi ini.
- **D. Use every available minute without a plan** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use every available minute without a plan”. Bukti yang menjawab pertanyaan adalah “The teacher suggested that groups allocate the final few minutes to reviewing marked items.”, dan bukti itu mendukung “Set aside part of a resource for a purpose”, bukan opsi ini.

---

### W12S2-Q27 — interpretation_limit (medium)
**Stimulus:** W12S2-T5

**Question:** Why does the teacher advise students to compare several sessions before deciding whether their progress is consistent?

- **A.** The table does not contain any correct answers
- **B.** Students are not allowed to review old results
- **C.** The groups completed different school years
- **D.** One practice result may not represent a lasting pattern

**Jawaban:** D. One practice result may not represent a lasting pattern

**Pembahasan:** Satu hasil hanya menggambarkan satu sesi. Membandingkan beberapa sesi memberi dasar lebih kuat untuk menilai konsistensi kemajuan.

**Bukti teks:** “these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.”

**Alasan setiap opsi:**
- **A. The table does not contain any correct answers** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The table does not contain any correct answers”. Bukti yang menjawab pertanyaan adalah “these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “One practice result may not represent a lasting pattern”, bukan opsi ini.
- **B. Students are not allowed to review old results** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Students are not allowed to review old results”. Bukti yang menjawab pertanyaan adalah “these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “One practice result may not represent a lasting pattern”, bukan opsi ini.
- **C. The groups completed different school years** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “The groups completed different school years”. Bukti yang menjawab pertanyaan adalah “these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “One practice result may not represent a lasting pattern”, bukan opsi ini.
- **D. One practice result may not represent a lasting pattern** — Benar. Satu hasil hanya menggambarkan satu sesi. Membandingkan beberapa sesi memberi dasar lebih kuat untuk menilai konsistensi kemajuan. Bukti teks: “these results describe one practice session only. They should compare several sessions before deciding whether their progress is consistent.”

---

### W12S2-Q28 — not_mentioned (medium)
**Stimulus:** W12S2-T5

**Question:** Which action is NOT included in the challenge instructions?

- **A.** Read the teacher’s answer guide before submitting
- **B.** Identify the target and locate evidence
- **C.** Review dates, numbers, and contrast words before submitting
- **D.** Read each question first

**Jawaban:** A. Read the teacher’s answer guide before submitting

**Pembahasan:** Instruksi meminta siswa membaca setiap pertanyaan, mengidentifikasi target, menemukan bukti, lalu meninjau NOT/EXCEPT, tanggal, angka, dan kata kontras. Tidak ada langkah yang meminta siswa membaca kunci jawaban guru sebelum mengumpulkan latihan.

**Bukti teks:** “Read each question first, identify the target, and locate evidence before choosing an option.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”

**Alasan setiap opsi:**
- **A. Read the teacher’s answer guide before submitting** — Benar. Instruksi meminta siswa membaca setiap pertanyaan, mengidentifikasi target, menemukan bukti, lalu meninjau NOT/EXCEPT, tanggal, angka, dan kata kontras. Tidak ada langkah yang meminta siswa membaca kunci jawaban guru sebelum mengumpulkan latihan. Bukti teks: “Read each question first, identify the target, and locate evidence before choosing an option.”; “Before submitting, review NOT/EXCEPT questions, dates, numbers, and contrast words.”
- **B. Identify the target and locate evidence** — Tidak tepat. Opsi ini tidak dicantumkan sebagai instruksi dalam stimulus; periksa keseluruhan daftar tindakan untuk memastikan pilihan yang benar-benar tidak disebutkan.
- **C. Review dates, numbers, and contrast words before submitting** — Tidak tepat. Opsi ini tidak dicantumkan sebagai instruksi dalam stimulus; periksa keseluruhan daftar tindakan untuk memastikan pilihan yang benar-benar tidak disebutkan.
- **D. Read each question first** — Tidak tepat. Informasi ini justru disebutkan dalam stimulus. Karena pertanyaan meminta tindakan yang TIDAK dicantumkan, pilihan yang sudah tercantum tidak dapat menjadi jawaban.

---

### W12S2-Q29 — vocabulary_meaning (developing)
**Stimulus:** W12S2-T5

**Question:** In the teacher’s note, what does “progress” mean?

- **A.** A refusal to check the answers
- **B.** A sudden cancellation of the activity
- **C.** A movement toward a better result
- **D.** A fixed amount of time

**Jawaban:** C. A movement toward a better result

**Pembahasan:** Progress berarti kemajuan atau perkembangan. Dalam konteks ini, guru menyarankan membandingkan beberapa sesi untuk melihat apakah hasil belajar menunjukkan kemajuan yang konsisten.

**Bukti teks:** “They should compare several sessions before deciding whether their progress is consistent.”

**Alasan setiap opsi:**
- **A. A refusal to check the answers** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A refusal to check the answers”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “A movement toward a better result”, bukan opsi ini.
- **B. A sudden cancellation of the activity** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A sudden cancellation of the activity”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “A movement toward a better result”, bukan opsi ini.
- **C. A movement toward a better result** — Benar. Progress berarti kemajuan atau perkembangan. Dalam konteks ini, guru menyarankan membandingkan beberapa sesi untuk melihat apakah hasil belajar menunjukkan kemajuan yang konsisten. Bukti teks: “They should compare several sessions before deciding whether their progress is consistent.”
- **D. A fixed amount of time** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “A fixed amount of time”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “A movement toward a better result”, bukan opsi ini.

---

### W12S2-Q30 — strategy_transfer (medium)
**Stimulus:** W12S2-T5

**Question:** You want to decide whether a learner’s reading has improved over time. Which approach provides the strongest evidence?

- **A.** Ask whether the learner felt confident and ignore the results
- **B.** Use the highest score from one practice session
- **C.** Compare results from several sessions and review the types of errors
- **D.** Count how many questions were displayed without checking answers

**Jawaban:** C. Compare results from several sessions and review the types of errors

**Pembahasan:** Untuk melihat kemajuan, gunakan pola hasil beberapa sesi dan jenis kesalahan yang berulang, bukan satu skor saja.

**Bukti teks:** “They should compare several sessions before deciding whether their progress is consistent.”

**Alasan setiap opsi:**
- **A. Ask whether the learner felt confident and ignore the results** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Ask whether the learner felt confident and ignore the results”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “Compare results from several sessions and review the types of errors”, bukan opsi ini.
- **B. Use the highest score from one practice session** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Use the highest score from one practice session”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “Compare results from several sessions and review the types of errors”, bukan opsi ini.
- **C. Compare results from several sessions and review the types of errors** — Benar. Untuk melihat kemajuan, gunakan pola hasil beberapa sesi dan jenis kesalahan yang berulang, bukan satu skor saja. Bukti teks: “They should compare several sessions before deciding whether their progress is consistent.”
- **D. Count how many questions were displayed without checking answers** — Tidak tepat. Stimulus terkait tidak mendukung pernyataan “Count how many questions were displayed without checking answers”. Bukti yang menjawab pertanyaan adalah “They should compare several sessions before deciding whether their progress is consistent.”, dan bukti itu mendukung “Compare results from several sessions and review the types of errors”, bukan opsi ini.

---
