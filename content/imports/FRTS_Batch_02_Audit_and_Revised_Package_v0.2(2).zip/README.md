# FRTS Batch 2 — Weeks 5–8 | Audit & Revised Package v0.2

**Status:** PARTIAL — REVISED DRAFT / OWNER REVIEW  
**Audit date:** 15 November 2026  
**Curriculum basis:** Module v0.1 (preserved unchanged)  
**Master Bank:** v0.2

## Files

1. `01_FRTS_Batch_02_Weeks_05-08_Module_v0.1.md` — original curriculum authority; no curriculum change.
2. `02_FRTS_Batch_02_Interactive_Question_Bank_v0.2.json` — revised master question bank and expanded reference register.
3. `03_FRTS_Batch_02_Student_Payload_v0.2.json` — rebuilt from Master Bank v0.2; contains no teacher-only answer fields.
4. `04_FRTS_Batch_02_Teacher_Answer_Payload_v0.2.json` — rebuilt teacher-only answers, explanations, evidence and four option rationales per question.
5. `05_FRTS_Batch_02_Audit_Report_v0.2.md` — findings, corrections, research register, validation and open limitations.
6. `README.md` — this file.

## Validation summary

- 8 sessions, 96 unique questions, 16 unique stimuli.
- Each session: 7 reading comprehension + 4 vocabulary + 1 strategy transfer.
- Each session: 10 vocabulary cards, exactly 4 NEW + 6 RECYCLED (new ratio 0.40).
- Difficulty counts match the Module v0.1 blueprint.
- Four options, one keyed answer and four option rationales per item.
- Master/Student/Teacher question IDs match exactly.
- Student payload forbidden answer/key fields: 0.
- Teacher answer records: 96.
- Correct-option positions: 24 A / 24 B / 24 C / 24 D.
- Evidence, stimulus links, word counts, JSON parsing and duplicate-key checks pass.

## Important status notes

This package is **not classroom validated, psychometrically calibrated, API-integrated or production-ready**. A student pilot, teacher review, final English copy-edit, vocabulary dictionary review and application schema/API/security integration are still required.

The input ZIP’s README listed `04A_FRTS_Batch_02_Teacher_Answer_Guide_v0.1.md`, but that file was not present. The audit prompt’s procedure requests a Teacher Answer Guide, while its exact final output list omits it. To comply with the exact six-file output list, no standalone guide is included; all teacher explanations and option rationales are available in the Teacher Answer Payload.
