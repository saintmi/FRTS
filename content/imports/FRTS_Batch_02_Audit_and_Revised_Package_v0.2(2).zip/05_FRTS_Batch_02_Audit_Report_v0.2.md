# FRTS Batch 2 — Independent Audit & Revision Report
## Weeks 5–8 | Master Bank v0.1 → v0.2

**Audit date:** 15 November 2026  
**Input package:** `FRTS_Week_05-08_Production_Package_v0.1.zip`  
**Curriculum authority:** `01_FRTS_Batch_02_Weeks_05-08_Module_v0.1.md`  
**Master source:** `02_FRTS_Batch_02_Interactive_Question_Bank_v0.1.json`  
**Final status:** **PARTIAL — REVISED DRAFT / OWNER REVIEW**  
**Classroom validation:** Not performed  
**Application schema/API integration:** Not performed

---

## 1. Executive summary

The complete six-file input ZIP was opened and reviewed. The audit covered the module, Master Question Bank, Student Payload, Teacher Answer Payload, README and the embedded audit prompt. All 16 stimuli and 96 question records were reviewed for their intended skill, stimulus linkage, answer key, options, hints, teacher explanation, textual evidence and option rationales. Required research sources were opened and additional sources were consulted.

The initial package had the correct top-level counts (8 sessions, 96 questions, 16 stimuli) and the expected 7/4/1 item-role distribution. However, the baseline contained substantive problems that were not visible from count-only validation:

- The correct-option position was highly predictable: **83 of 96 answers were A**; both Week 6 sessions and Week 7 Online 02 had all 12 keys at A.
- A Week 7 stimulus explicitly explained the answers to reference questions before the questions were asked.
- Some question records pointed to the wrong stimulus or quoted wording not present in their linked stimulus.
- Some vocabulary questions tested words absent from the linked stimulus while being labelled as vocabulary-in-context.
- Recycled vocabulary cards in W7S1, W7S2 and W8S1 did not match the authoritative module recycle register.
- Several recycled vocabulary examples were copied verbatim across sessions rather than providing a new retrieval context.
- W8S1-Q04 was labelled as an inference item although its answer was explicitly stated.
- The baseline did not mark invented school scenarios and survey figures as fictional.

The Master Bank was revised locally, then the Student and Teacher Payloads were rebuilt from the revised Master Bank. The Module v0.1 was preserved unchanged because no curriculum objective or sequence change was needed.

**Structural and cross-file QA now passes:** 8 sessions, 96 unique question IDs, 16 unique stimuli, exact role composition, module-aligned difficulty counts, 10 cards per session, 4 NEW + 6 RECYCLED per session, 4 options per item, valid keys, four rationales per item, exact evidence excerpts, zero student answer-field leaks, and matching Master/Student/Teacher IDs. Correct-option positions are now balanced at exactly 3 A, 3 B, 3 C and 3 D per session.

The status remains PARTIAL rather than production-ready because classroom readability, psychometric difficulty, student pilot performance, dictionary-level review of every vocabulary entry, and application/API integration have not been tested. A separate Teacher Answer Guide is also absent from the input package and is not listed in the prompt’s final six-file output specification; this conflict is recorded below.

---

## 2. Input inventory and authority

| Input file | Role | Audit result |
|---|---|---|
| `01_FRTS_Batch_02_Weeks_05-08_Module_v0.1.md` | Curriculum authority | Read; retained unchanged |
| `02_FRTS_Batch_02_Interactive_Question_Bank_v0.1.json` | Master source of truth | Read and revised to v0.2 |
| `03_FRTS_Batch_02_Student_Payload_v0.1.json` | Student-facing payload | Read; rebuilt from revised Master Bank |
| `04_FRTS_Batch_02_Teacher_Answer_Payload_v0.1.json` | Teacher-only answers | Read; rebuilt from revised Master Bank |
| `05_FRTS_Batch_02_Audit_Prompt_v0.1.md` | Audit instructions | Read and followed |
| `README.md` | Package inventory | Read; replaced with accurate v0.2 inventory |

### Inventory discrepancy

The input README lists `04A_FRTS_Batch_02_Teacher_Answer_Guide_v0.1.md`, but that file is not present in the ZIP. The procedure section of the prompt says to rebuild a Teacher Answer Guide, while its exact final output list specifies only the Module, Master Bank, Student Payload, Teacher Payload, Audit Report and README. To honour the prompt’s “exactly these five deliverables plus README” instruction, no seventh file was added. The Teacher Payload retains all 96 teacher explanations, evidence excerpts and four option rationales. If a standalone Teacher Answer Guide is required, it should be explicitly added to a later output specification.

---

## 3. Baseline structural audit

| Check | Baseline | Result |
|---|---:|---|
| Weeks | 4 (W5–W8) | Pass |
| Online sessions | 8 | Pass |
| Questions | 96 | Pass |
| Stimuli | 16 | Pass |
| Stimuli per session | 2 | Pass |
| Reading comprehension items | 56 | Pass |
| Vocabulary items | 32 | Pass |
| Strategy-transfer items | 8 | Pass |
| Questions per session | 12 | Pass |
| Vocabulary cards per session | 10 | Pass |
| NEW cards per session | 4 | Pass |
| RECYCLED cards per session | 6 | Pass |
| Four options per item | 96/96 | Pass |
| Student hints present | 96/96 | Pass |
| Teacher explanation/evidence/rationales present | 96/96 | Pass |
| Duplicate question IDs | 0 | Pass |
| Duplicate stimulus IDs | 0 | Pass |
| JSON parse errors | 0 | Pass |
| Duplicate JSON keys | 0 | Pass |

The baseline count checks passed, but the semantic and answer-position checks below identified important defects.

---

## 4. Findings register

Severity reflects the impact on item validity, curriculum alignment, security or package integrity. “Resolved” means corrected in v0.2 and rechecked.

| ID | Severity | Item / area | Finding and impact | Action / status |
|---|---|---|---|---|
| B2-AUD-001 | HIGH | W7S1-T1; W7S1-Q01–Q04 | The stimulus directly stated that “they” referred to the birds and “there” referred to the fence. This disclosed answers before the questions and weakened the reference-tracking assessment. | Removed the answer-giving sentence; rewrote the surrounding text to preserve clear reference links. Q02 now tests demonstrative “This” referring to an action. **RESOLVED** |
| B2-AUD-002 | HIGH | All 96 keys | Baseline key positions were A=83, B=8, C=3, D=2. W6S1, W6S2 and W7S2 each had all 12 keys at A. This creates a strong test-taking cue unrelated to reading skill. | Reordered options and remapped keys/rationales. Every session now has exactly 3 keys at each position A/B/C/D. **RESOLVED** |
| B2-AUD-003 | HIGH | W5S2-Q08, W7S2-Q06, W7S2-Q10 and related evidence | Several items quoted wording from another stimulus, from a vocabulary-card example, or from text that was not in the linked stimulus. This undermined evidence traceability and could cause students to answer from the wrong passage. | Corrected stimulus IDs, question wording, linked stimulus text and evidence excerpts. **RESOLVED** |
| B2-AUD-004 | HIGH | W7S1-Q02 | The baseline item asked what “there” referred to while being classified as pronoun reference. “There” is a locative adverb, not a personal pronoun or demonstrative target in the module’s stated Week 7 scope. | Replaced with a demonstrative-reference item about “This” referring to the action of placing the map beside the notebook. **RESOLVED** |
| B2-AUD-005 | HIGH | W7S1, W7S2, W8S1 vocabulary cards | The Master Bank’s RECYCLED cards did not match the module’s authoritative recycle register. Examples included W7S1 using `reason/available/purpose` instead of `detail/refer to/identify`, W7S2 using `purpose` instead of `mention`, and W8S1 using `protect` instead of `detail`. | Rebuilt those card lists to match the module exactly; recalculated NEW/RECYCLED metadata. **RESOLVED** |
| B2-AUD-006 | MEDIUM | W5S1-Q09, W5S2-Q11, W6S1-Q11, W7S2-Q08–Q11, W8S2-Q10 | Some words were tested as vocabulary-in-context even though the target wording did not appear in the linked stimulus. | Added the target word in a natural context, revised the linked passage, or linked the item to the passage/card context where appropriate. **RESOLVED** |
| B2-AUD-007 | MEDIUM | Recycled vocabulary cards across W5–W8 | Several recycled cards reused the exact same example sentence from the session where the word was first introduced. This conflicted with the module’s instruction to retrieve old words in new contexts. | Rewrote recycled examples to create distinct contexts in each session. Duplicate word/example pairs across the 80 card records: 0. **RESOLVED** |
| B2-AUD-008 | MEDIUM | W8S1-Q04 | The question was classified as a reasonable inference, but the claimed preparation (“the first sentence she had practised”) was explicitly stated in the passage. | Rewrote the item to infer what Nadia’s ability to answer two questions suggests about her understanding of the project. **RESOLVED** |
| B2-AUD-009 | MEDIUM | 24 option sets | In 24 items, the correct answer was noticeably longer than the distractors, creating a possible answer-length cue. | Shortened or balanced the affected options while retaining the intended key and distractor meaning. No remaining item has a correct option at least five words longer than the shortest option while also being the longest. **RESOLVED** |
| B2-AUD-010 | MEDIUM | Reference SRC-11 | The baseline reference register attributed the PDF’s publication year to Baumann et al. (2005). The opened PDF is *The Reading Teacher’s Sourcebook*, ©2007, by Denton, Bryan, Wexler, Reed and Vaughn; Baumann et al. (2005) is cited within the chapter. | Corrected the bibliographic metadata and distinguished the sourcebook from the chapter’s cited research. **RESOLVED** |
| B2-AUD-011 | MEDIUM | Selected distractors, including W5S1-Q04, W5S2-Q02, W6S1-Q02/Q07 and W6S2-Q03 | Several distractors were implausibly unrelated or obviously impossible, weakening discrimination. | Improved the most conspicuous sets with text-related alternatives and more defensible contrasts. Remaining distractor plausibility should still be reviewed by an English reading teacher during item review. **PARTIALLY RESOLVED** |
| B2-AUD-012 | MEDIUM | Difficulty labels across all sessions | The numerical difficulty distributions match the module, but some vocabulary items labelled Medium still rely on relatively direct lexical retrieval. Labels remain internal estimates, not empirically calibrated difficulty. | Retained the module’s required distribution; flagged for teacher review and student item analysis rather than relabelling solely to force counts. **OPEN — PILOT REQUIRED** |
| B2-AUD-013 | MEDIUM | Teacher Answer Guide / README / output spec | README claimed a Teacher Answer Guide that was not in the ZIP. The prompt procedure requests a rebuilt guide, but the final minimal file list omits it. | Rebuilt the Teacher Payload and documented the conflict. No extra file was added because the output list says exactly six files. **OPEN — OWNER DECISION IF STANDALONE GUIDE IS REQUIRED** |
| B2-AUD-014 | LOW | All 16 stimuli | Fictional school scenarios, names, survey numbers and events were not consistently distinguished from source-derived general facts. | Added `scenario_note` to all 16 stimuli. **RESOLVED** |
| B2-AUD-015 | LOW | All 16 stimuli | Word counts needed to reflect the final text after local corrections. | Recomputed `word_count` using whitespace tokenisation for all 16 stimuli. **RESOLVED** |
| B2-AUD-016 | MEDIUM | All 96 items | Difficulty, naturalness, and distractor effectiveness cannot be fully validated without target learners and classroom data. | Preserved internal labels and documented the requirement for pilot testing and item analysis. **OPEN — PILOT REQUIRED** |
| B2-AUD-017 | MEDIUM | Application integration and teacher-only security | Payload separation is correct at file level, but the application’s actual API/schema and authorization implementation were not supplied for inspection. | Student payload has zero forbidden teacher fields; Teacher Payload is marked server-authorized only. Server-side role enforcement and API mapping remain an integration task. **OPEN — INTEGRATION REQUIRED** |

No CRITICAL finding was identified. All HIGH findings are resolved in v0.2. The remaining open findings concern teacher judgement, missing standalone guide scope, classroom calibration and application integration.

---

## 5. Corrections applied to the Master Bank

### 5.1 Stimulus and item corrections

- **W5S1-T1 / W5S1-Q09:** revised the tree-root sentence to include `absorb` and aligned the stem/evidence to the actual sentence.
- **W5S2-T1 / W5S2-Q11:** added a compost-related sentence using `layer`; the item now tests the word in its linked passage.
- **W5S2-Q08:** corrected its stimulus link to W5S2-T2, where the survey summary sentence actually appears.
- **W6S1-T1 / W6S1-Q11:** added a natural use of `conserve` and changed the stem to test its contextual meaning.
- **W7S1-T1:** removed the answer disclosure and made the “This” reference item refer to the action of placing a map beside the notebook.
- **W7S1-Q06 and W7S1-Q12:** aligned the quoted notice wording with the actual stimulus sentence (“If students borrow both items…”).
- **W7S2-T1:** added a short reading tip containing `preceding`, `following` and `substitute`; W7S2-Q08–Q10 now refer to that passage text.
- **W7S2-T2 / W7S2-Q06/Q07/Q11:** corrected the “She” sentence, label reference, and `indicated` wording so each item matches the stimulus.
- **W7S2-Q10:** corrected its stimulus link to W7S2-T1, where the reading tip appears.
- **W8S1-Q04:** replaced an explicit-detail retrieval item with an inference about Nadia’s ability to answer questions.
- **W8S2-T2 / W8S2-Q10:** used `likely` in the linked stimulus while preserving the following statement that the librarian is not certain which change mattered most.
- Corrected exact evidence excerpts and revised affected Indonesian explanations/rationales.

### 5.2 Vocabulary alignment

The authoritative module’s card lists are now reflected in the Master Bank:

| Session | NEW (4) | RECYCLED (6) |
|---|---|---|
| W5 Online 01 | overview, canopy, absorb, surface | purpose, record, available, sequence, specific, general |
| W5 Online 02 | summary, relevant, contribute, layer | overview, canopy, absorb, surface, purpose, record |
| W6 Online 01 | reservoir, scarce, capture, adequate | summary, relevant, contribute, layer, conserve, supply |
| W6 Online 02 | pollutant, filter, runoff, prevent | reservoir, scarce, capture, adequate, protect, reduce |
| W7 Online 01 | antecedent, referent, pronoun, demonstrative | specific, detail, sequence, refer to, identify, record |
| W7 Online 02 | preceding, following, substitute, indicate | antecedent, referent, pronoun, demonstrative, available, mention |
| W8 Online 01 | imply, hesitate, glance, relieved | specific, reason, detail, purpose, sequence, record |
| W8 Online 02 | conclude, assumption, likely, uncertain | imply, hesitate, glance, relieved, specific, reason |

All 32 NEW target words are unique across W5–W8. Each session contains exactly 10 cards, 4 NEW and 6 RECYCLED, giving a target-card new ratio of 0.40. Recycled examples were rewritten to use different contexts rather than copied verbatim.

### 5.3 Option positions and answer-length cues

Baseline key distribution:

| Key | Count |
|---|---:|
| A | 83 |
| B | 8 |
| C | 3 |
| D | 2 |

Revised key distribution:

| Key | Count |
|---|---:|
| A | 24 |
| B | 24 |
| C | 24 |
| D | 24 |

Each session now has exactly three correct answers at each position. Option values, correct keys, correct-answer strings and option rationales were remapped together. Twenty-four option sets were also adjusted to reduce answer-length cues.

---

## 6. Research review and reference register

All eight references mandated by the prompt were opened or their access limitations recorded. Additional sources were consulted for referential cohesion, EFL vocabulary, assessment design and environmental facts. Access date for the research review: **15 November 2026**.

| Source | Material actually read | Audit use and limitation |
|---|---|---|
| Vaughn et al. (2022), IES/WWC, *Providing Reading Interventions for Students in Grades 4–9*, Recommendation 3 Part C — [PDF](https://ies.ed.gov/ncee/WWC/Docs/PracticeGuide/WWC-practice-guide-reading-intervention-full-text.pdf) | Full PDF; Recommendation 3 Part C, gist routine and instructional examples | Supports identifying who/what a section is about, selecting important information, synthesizing a short complete gist, and separating relevant from irrelevant details. A practice guide, not a guarantee of effects for FRTS. |
| IES, *PRISMS Toolkit*, Module 4 — [Toolkit](https://ies.ed.gov/ncee/rel/reading-intervention-grades-6-8) | Module 4 overview, Ask and Answer Questions and Gist resources | Supports modelling, guided practice, discussion and routines for middle-grade readers with reading difficulties. The toolkit is designed for intervention contexts, not automatically all EFL learners. |
| Denton et al. (2007), *The Reading Teacher’s Sourcebook*, Chapter 7 — [PDF](https://d1yqpar94jqbqm.cloudfront.net/documents/The%20Reading%20Teacher%27s%20Sourcebook%20Effective%20Instruction_Vocabulary_0.pdf) | Chapter 7, especially pp. 201–211 | Lists definition, synonym, antonym, example and general clues; recommends rereading the sentence and nearby sentences, inferring a meaning, then testing it. The chapter itself cautions that context clues are not a formula. The PDF is ©2007; Baumann et al. (2005) is a cited chapter source. |
| Gibbs (2020), Iowa Reading Research Center, *Using Context Clues to Understand New Words* — [Article](https://irrc.education.uiowa.edu/blog/2020/10/supporting-your-childrens-and-teens-home-learning-using-context-clues-understand-new) | Full article page and sections on definition, restatement and contrast clues | Supports context clues in the same sentence or nearby sentences. This is an educational outreach article, not a controlled intervention study. |
| Barth & Elleman (2017), *Evaluating the Impact of a Multistrategy Inference Intervention for Middle-Grade Struggling Readers* — [Publisher page](https://pubs.asha.org/doi/10.1044/2016_LSHSS-16-0041) | Bibliographic page and abstract; full article access restricted | Abstract describes 66 middle-grade struggling readers and explicit instruction in four inference strategies. The reported standardized reading-comprehension effect was preliminary. Full article was not accessible. |
| Barnes et al. (2024), *A Randomized Controlled Trial of Tutor- and Computer-Delivered Inferential Comprehension Interventions for Middle School Students with Reading Difficulties* — [DOI](https://doi.org/10.1080/10888438.2024.2331517) | Publisher-indexed article content: abstract, method, intervention, measures, results and discussion. Direct DOI page open returned 403. | Study involved 145 Grade 6–8 students with reading difficulties. Tutor-led Connect-IT outperformed computer-led and business-as-usual on the study-specific inference measure; computer-led did not differ from business-as-usual on that measure. This does not validate FRTS or prove equivalent results for Indonesian EFL learners. |
| British Council, *B1 Graded Reading* — [Page](https://learnenglishteens.britishcouncil.org/study-break/reading-zone/b1-graded-reading) | Page and listed B1 stories/articles | Used only as an orientation to teen reading topics and text formats; does not certify FRTS passages as B1. |
| British Council, *B1 Reading* — [Page](https://learnenglishteens.britishcouncil.org/skills/reading/b1-reading) | Page and listed reading formats | Used as a format reference for reading practice; not an independent level assessment of FRTS. |
| U.S. EPA, *Stormwater to Street Trees* — [PDF](https://www.epa.gov/sites/default/files/2015-11/documents/stormwater2streettrees.pdf) | Section 2, tree canopy interception and infiltration | Supports general facts about canopy interception and roots/soil infiltration used in W5S1. Technical stormwater guidance, not a language-level reference. |
| U.S. EPA, *Constructed Treatment Wetlands* — [PDF](https://www.epa.gov/system/files/documents/2025-12/constructed-treatment-wetlands-factsheet-2004.pdf) | Wetland filtration processes | Supports the limited claim that wetland vegetation/soil can slow water and trap some suspended particles. It does not support claims that all wetlands remove all pollutants or make water drinkable. |
| U.S. EPA, *Urbanization and Stormwater Runoff* — [Page](https://www.epa.gov/sourcewaterprotection/urbanization-and-stormwater-runoff) | Runoff definition, impervious surfaces and pollutant transport | Supports general W6S2 runoff facts. No quantitative or school-specific claim was taken from the page. |
| Bayat, Aydın & Şekercioğlu (2025), *The Role of Referential Cohesion in the Process of Text Comprehension* — [Article](https://doi.org/10.47750/pegegog.15.02.17) | Publisher page and abstract | Study of 198 Grade 6–8 students reports referential-cohesion understanding significantly predicts reading-comprehension achievement. Abstract-level review; predictive association does not establish causation. |
| Kandel Cisco & Padrón (2012), *Investigating Vocabulary and Reading Strategies with Middle Grades English Language Learners* — [Full PDF](https://files.eric.ed.gov/fulltext/EJ989796.pdf) | Full 23-page research synthesis | Synthesis of 11 studies identifies vocabulary knowledge and strategic reading as important for middle-grade ELL reading comprehension. Context use, monitoring, prior knowledge, restating and inference are discussed. Many included studies concern U.S. ELL contexts and Spanish-English learners, so transfer to Indonesian EFL requires adaptation. |
| Zeng et al. (2025), *Vocabulary Instruction for English Learners: A Systematic Review* — [Article](https://doi.org/10.3390/educsci15030262) | Publisher open-access page, abstract and metadata | Supports adapting vocabulary-instruction practices to developmental needs of English learners. This audit used the abstract/page metadata, not a full item-by-item extraction of the 22-page review. |
| NAEP, *Reading Assessment Framework* — [Framework](https://www.nationsreportcard.gov/reading/about/framework/) | Assessment overview, text types and cognitive targets | Provides a comparison framework for locating/recalling, integrating/interpreting (including inference and main idea), and critique/evaluation. It is a U.S. national framework, not an Indonesian EFL curriculum standard. |

### Research implications for this package

- Week 5 gist instruction is consistent with the IES/WWC process: identify who/what, identify important information, synthesize, and check that the gist is short and complete.
- Week 6 uses the five context-clue categories in the Sourcebook. The module correctly cautions that context clues can be incomplete or misleading and that students may need a glossary or teacher support.
- Week 7 reference tracking is supported as a meaningful comprehension target by research on referential cohesion and the 2024 Connect-IT intervention, but the studies do not prescribe FRTS’s exact lesson sequence.
- Week 8 maintains the distinction between explicit facts, reasonable inference and unsupported assumption. Modal strength (`may`, `could`, `likely`) should not be converted into certainty.
- EFL vocabulary research supports treating vocabulary as part of reading comprehension, not merely as isolated word memorisation. The card system should continue to use new contexts and explicit checks of word meaning.

---

## 7. Post-correction validation

| Validation | Result |
|---|---:|
| Sessions | 8 |
| Unique questions | 96 |
| Unique stimuli | 16 |
| Stimuli per session | 2 |
| Reading comprehension / vocabulary / strategy transfer | 56 / 32 / 8 |
| Questions per session | 12 |
| Vocabulary cards per session | 10 |
| NEW / RECYCLED cards per session | 4 / 6 |
| New ratio per session | 0.40 |
| Unique NEW target words across W5–W8 | 32 |
| Options per question | 4 |
| Valid correct key in option set | 96/96 |
| Correct-answer text matches keyed option | 96/96 |
| Option rationales | 4 per question |
| Teacher explanations | 96/96 |
| Evidence excerpts match linked stimulus | 96/96 |
| Question-to-stimulus references | 96/96 valid |
| Student forbidden answer fields | 0 |
| Teacher answer records | 96 |
| Master/Student/Teacher ID sets | Exact match |
| Duplicate question IDs | 0 |
| Duplicate stimulus IDs | 0 |
| Duplicate JSON keys | 0 |
| JSON parse errors | 0 |
| Stimulus word-count mismatches | 0 |
| Correct-option positions | 24 A / 24 B / 24 C / 24 D |
| Duplicate word/example pairs across cards | 0 |

### Difficulty distribution

| Session | Easy | Developing | Medium | Total |
|---|---:|---:|---:|---:|
| W5 Online 01 | 4 | 5 | 3 | 12 |
| W5 Online 02 | 3 | 5 | 4 | 12 |
| W6 Online 01 | 3 | 4 | 5 | 12 |
| W6 Online 02 | 3 | 4 | 5 | 12 |
| W7 Online 01 | 2 | 5 | 5 | 12 |
| W7 Online 02 | 2 | 4 | 6 | 12 |
| W8 Online 01 | 2 | 4 | 6 | 12 |
| W8 Online 02 | 1 | 4 | 7 | 12 |

These counts match the module exactly. They remain design labels, not psychometric difficulty estimates.

---

## 8. Remaining limitations and required next checks

1. **Classroom pilot:** test with the intended SMP Grades 7–9 learners. Collect completion time, item facility, discrimination, distractor selection and student feedback.
2. **Difficulty calibration:** review items labelled Medium that may function as direct vocabulary recall; revise based on pilot data, not solely on the target count.
3. **English language review:** conduct a final independent copy-edit for naturalness, register, collocation and age appropriateness.
4. **Vocabulary review:** verify all 80 card entries (POS, Indonesian meaning, contextual synonym/contrast and examples) against reliable learner dictionaries and teacher judgement. This audit reviewed the cards contextually but did not conduct a full dictionary lookup for every entry.
5. **Application integration:** map v0.2 JSON to the actual application schema/API and run end-to-end tests.
6. **Security:** enforce teacher authorization on the server. The teacher payload’s filename or client-side hiding is not an access-control mechanism.
7. **Teacher Answer Guide:** decide whether a standalone guide is required and amend the exact output list if so. The current ZIP follows the prompt’s six-file final list and keeps the complete explanations in the Teacher Payload.

**Release interpretation:** v0.2 is a corrected and structurally reconciled draft. It is not classroom validated, psychometrically calibrated, API-integrated or production-ready.

---

## 9. Final package contents

The revised ZIP contains exactly these six files:

1. `01_FRTS_Batch_02_Weeks_05-08_Module_v0.1.md` — original module preserved unchanged.
2. `02_FRTS_Batch_02_Interactive_Question_Bank_v0.2.json` — revised Master Bank and expanded source register.
3. `03_FRTS_Batch_02_Student_Payload_v0.2.json` — rebuilt student payload with no teacher answer fields.
4. `04_FRTS_Batch_02_Teacher_Answer_Payload_v0.2.json` — rebuilt teacher-only answer payload.
5. `05_FRTS_Batch_02_Audit_Report_v0.2.md` — this audit report.
6. `README.md` — inventory, status and validation summary.

### Revision history

| Version | Date | Change |
|---|---|---|
| 0.1 | 15 Nov 2026 | Baseline production draft |
| 0.2 | 15 Nov 2026 | Independent audit corrections; payload rebuild; research and QA reconciliation |

