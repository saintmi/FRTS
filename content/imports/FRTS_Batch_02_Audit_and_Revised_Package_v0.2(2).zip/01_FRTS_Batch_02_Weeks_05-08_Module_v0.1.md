# FRTS — BATCH 2 INTEGRATED LEARNING DOCUMENT
## Weeks 5–8 | Student Modules + Teacher Guides + Vocabulary + Assessment Alignment

**Document ID:** FRTS-BATCH-02  
**Version:** 0.1 — Initial integrated draft  
**Status:** DRAFT FOR OWNER REVIEW — classroom pilot and independent QA pending  
**Program:** English Reading Preparation for SMP Grades 7–9  
**Cakupan:** Skimming dan gist/main idea; context clues; reference tracking; inference dan evidence.  
**Offline format:** 60 menit/minggu; penjelasan dan pemodelan guru maksimal 30 menit.

## 1. Hubungan Batch 2 dengan Batch 1

Batch 2 melanjutkan fondasi W1–W4. Siswa sudah mengenal topic, main idea, purpose, Question-First Reading, scanning, kosakata kontekstual, sinonim, antonim, dan parafrasa sederhana. Pada Batch 2, keterampilan tersebut digunakan pada bacaan yang lebih kaya informasi.

| Minggu | Fokus baru | Hasil belajar utama | Hubungan dengan W1–W4 |
|---:|---|---|---|
| 5 | Skimming, main idea, paragraph gist | Menyusun gagasan inti dari satu bagian teks dan membedakan detail penting/tidak penting | Memperdalam topic vs main idea dan skimming W1 |
| 6 | Context clues | Memperkirakan makna kata baru dengan petunjuk sekitar, lalu menguji dugaan | Menggunakan kembali strategi kosakata dalam konteks W4 |
| 7 | Reference tracking | Menentukan rujukan pronoun/demonstrative pada noun, phrase, atau gagasan sebelumnya | Menggunakan pencarian target dan pembacaan konteks W2–W3 |
| 8 | Inference and evidence | Membuat kesimpulan wajar yang didukung petunjuk teks; membedakan fakta, inferensi, dan asumsi | Menggabungkan Question-First, bukti, konteks, dan pemantauan pemahaman |

Question-First Reading tetap menjadi rutinitas FRTS. Namun, ketika pertanyaan menanyakan gist, main idea, rujukan lintas kalimat, atau inferensi, siswa harus membaca bagian yang lebih luas daripada hanya mencari kata yang sama.

---

# PART A — STUDENT MODULES

# WEEK 5 — SKIMMING, MAIN IDEA, AND GIST

## 1. Tujuan belajar

Setelah mempelajari minggu ini, siswa diharapkan mampu:
1. Membedakan topic (topik), main idea (gagasan utama), dan gist (inti ringkas bagian teks).
2. Menggunakan skimming untuk memperoleh gambaran umum.
3. Memilih informasi penting yang mendukung pokok bahasan.
4. Membedakan supporting detail (detail pendukung) dari informasi yang tidak relevan.
5. Menulis atau memilih gist satu kalimat tanpa menambahkan informasi baru.

## 2. Topic, main idea, dan gist

- **Topic (topik):** hal yang dibicarakan. Biasanya berupa frasa singkat, misalnya *school gardens*.
- **Main idea (gagasan utama):** hal terpenting yang disampaikan penulis tentang topik. Biasanya dapat ditulis sebagai satu kalimat.
- **Gist (inti ringkas):** ringkasan sangat singkat dari satu bagian teks—sering satu paragraf atau satu-dua paragraf—yang menyebut hal yang dibahas dan informasi paling penting tentangnya.
- **Supporting details (detail pendukung):** fakta, alasan, contoh, atau penjelasan yang membantu pembaca memahami gagasan utama.
- **Irrelevant details (detail tidak relevan):** informasi yang tidak membantu menjelaskan gagasan utama pada bagian yang sedang dibaca.

Contoh:

> Trees along busy streets provide shade. Their leaves and branches may hold some rain before it reaches the ground. Trees also create small habitats for birds and insects. However, young trees need suitable soil and regular care.

- Topic: street trees.
- Main idea: street trees provide useful environmental and comfort benefits, but they need care.
- Gist: Street trees offer shade and support local nature, but they must be planted and maintained appropriately.
- Detail pendukung: leaves and branches may hold some rain.
- Detail tidak relevan: harga tiket bus, jika tidak disebut dan tidak berhubungan dengan gagasan pohon.

## 3. Cara memperoleh gist

Gunakan rutinitas berikut:
1. **Tentukan siapa/apa yang dibahas.** Perhatikan judul, subjudul, kata yang sering muncul, dan kalimat pembuka.
2. **Tandai informasi terpenting.** Cari informasi yang menjelaskan apa yang terjadi, apa manfaat/masalahnya, atau apa hasil utamanya.
3. **Pilah detail.** Contoh kecil, angka sampingan, nama yang tidak penting, dan rincian proses mungkin tidak perlu dimasukkan ke gist.
4. **Rangkai dengan kata sendiri.** Jangan hanya menyalin satu kalimat jika isi bagian teks mencakup beberapa gagasan.
5. **Periksa kembali.** Apakah gist mewakili bagian yang dibaca? Apakah ada informasi penting yang hilang? Apakah ada klaim yang tidak didukung?

Skimming (membaca sekilas untuk gambaran umum) membantu menemukan arah teks. Namun, gist tidak boleh dibuat hanya dari judul atau kalimat pertama jika paragraf berikutnya mengubah atau memperluas gagasan.

## 4. Penting: gist bukan salinan dan bukan opini

Gist harus singkat, mencakup gagasan paling penting, dan setia pada teks. Hindari tiga kesalahan:
- **Terlalu sempit:** hanya menyebut satu contoh kecil.
- **Terlalu luas:** menambahkan klaim yang tidak disampaikan teks.
- **Terlalu rinci:** memasukkan seluruh angka, nama, dan urutan kecil sehingga tidak lagi menjadi ringkasan.

## 5. Contoh latihan

> A school survey found that many students used the library during lunch. Some borrowed books, while others used the tables to finish assignments. The librarian added a quiet reading corner after students asked for a calmer place. The corner became popular during the next month.

Pertanyaan: *What is the main idea?*

Jawaban terbaik: The library responded to student needs by adding a quiet reading corner that became useful to students.

Mengapa? Kalimat tersebut mencakup kebutuhan siswa, perubahan perpustakaan, dan hasilnya. Jawaban yang hanya menyebut siswa meminjam buku terlalu sempit.

## 6. Kosakata inti dan perluasan

Kosakata baru W5:
- **overview (n.)** — gambaran umum; *The report gives an overview of the project.*
- **canopy (n.)** — tajuk pohon; lapisan cabang dan daun; *The canopy provides shade.*
- **absorb (v.)** — menyerap; *Dry soil can absorb water.*
- **surface (n.)** — permukaan; *Rainwater flows across a hard surface.*
- **summary (n.)** — ringkasan; *Write a short summary of the article.*
- **relevant (adj.)** — relevan/berkaitan; *Keep details that are relevant to the main idea.*
- **contribute (v.)** — berkontribusi; *Students contribute ideas to the project.*
- **layer (n.)** — lapisan; *A layer of leaves covered the soil.*

Kata yang diulang dari W1–W4 antara lain *purpose, record, available, sequence, specific, general, improve,* dan *reduce*. Pengulangan berarti kata lama digunakan lagi pada kalimat dan topik berbeda.

## 7. Pemeriksaan mandiri

1. Apa perbedaan topic dan main idea?
2. Mengapa gist tidak boleh hanya menyalin angka atau contoh kecil?
3. Apa yang harus diperiksa setelah menulis gist?
4. Apakah semua detail dalam paragraf harus masuk ke gist?
5. Bagaimana menentukan apakah suatu detail relevan?

---

# WEEK 6 — CONTEXT CLUES

## 1. Tujuan belajar

Siswa diharapkan mampu:
1. Menemukan petunjuk makna kata pada kalimat yang sama atau kalimat di sekitarnya.
2. Mengenali petunjuk definisi/penjelasan, sinonim/restatement, antonim/kontras, contoh, dan konteks umum.
3. Memperkirakan makna kata baru tanpa menganggap tebakan selalu benar.
4. Menguji apakah makna dugaan cocok dengan kalimat.
5. Mengetahui kapan perlu memakai glosarium atau bertanya kepada guru.

## 2. Apa itu context clues?

**Context clues (petunjuk konteks)** adalah kata, frasa, kalimat, atau informasi di sekitar kata yang membantu pembaca memperkirakan maknanya. Petunjuk dapat muncul di kalimat yang sama, kalimat sebelum, atau kalimat sesudah.

Konteks membantu, tetapi tidak selalu memberikan definisi yang pasti. Jika kata penting tetap tidak jelas, periksa kamus/glosarium yang sesuai atau tanyakan kepada guru.

## 3. Jenis petunjuk konteks

### A. Definition or explanation clue — petunjuk definisi/penjelasan
Penulis menjelaskan makna secara langsung.

> A reservoir is a place where water is stored for later use.

Petunjuk: *a place where water is stored for later use*.

### B. Synonym or restatement clue — petunjuk sinonim/penyebutan ulang
Penulis menjelaskan kembali dengan kata atau frasa yang maknanya dekat.

> The path was narrow, or very small from side to side.

Petunjuk: *very small from side to side* membantu memahami *narrow*.

### C. Antonym or contrast clue — petunjuk antonim/kontras
Penulis membandingkan dengan makna yang berlawanan. Kata seperti *but, however, whereas, unlike,* dan *in contrast* dapat membantu, tetapi tetap periksa keseluruhan kalimat.

> The first tank was full, whereas the second was almost empty.

Petunjuk: *full* berlawanan dengan *almost empty*.

### D. Example clue — petunjuk contoh
Penulis memberikan contoh yang termasuk dalam kelompok atau menjelaskan makna kata.

> Wetland pollutants may include plastic pieces, oil and other harmful materials.

Contoh membantu memahami bahwa *pollutants* adalah bahan pencemar.

### E. General context clue — petunjuk umum
Tidak ada satu kata yang menjadi definisi. Pembaca menggabungkan beberapa informasi sekitar.

> After several dry weeks, the village water supply became scarce. Families had to use less water and collect rain when it arrived.

Situasi penggunaan air yang harus dihemat membantu memperkirakan bahwa *scarce* berarti terbatas atau sulit diperoleh.

## 4. Rutinitas aman menggunakan petunjuk konteks

1. Baca kalimat yang memuat kata tersebut.
2. Baca kalimat sebelum dan sesudahnya.
3. Cari definisi, penyebutan ulang, kontras, contoh, atau petunjuk umum.
4. Buat dugaan makna sementara.
5. Masukkan makna dugaan ke dalam kalimat.
6. Periksa apakah kalimat tetap masuk akal dan sesuai isi teks.
7. Jika masih ragu dan kata penting, gunakan sumber bantuan.

Jangan memilih makna hanya karena bentuk katanya mirip dengan kata Bahasa Indonesia atau karena satu sinonim tampak cocok di luar konteks.

## 5. Kosakata inti dan perluasan

Kosakata baru W6:
- **reservoir (n.)** — tempat penyimpanan air; *The tank acts as a reservoir.*
- **scarce (adj.)** — langka/terbatas; *Water becomes scarce in a long dry period.*
- **capture (v.)** — menampung/menangkap; *The channel can capture rainwater.*
- **adequate (adj.)** — cukup/memadai; *The water is adequate for cleaning tools.*
- **pollutant (n.)** — bahan pencemar; *Plastic can become a pollutant.*
- **filter (n./v.)** — penyaring/menyaring; *Wetland soil can filter some particles.*
- **runoff (n.)** — limpasan permukaan; *Runoff carried soil to the stream.*
- **prevent (v.)** — mencegah; *Plants may prevent some soil loss.*

Kata kumulatif yang diulang: *summary, relevant, contribute, layer, conserve, supply, protect, reduce,* dan kosakata W1–W4 lainnya.

## 6. Pemeriksaan mandiri

1. Di mana petunjuk konteks dapat ditemukan?
2. Apa perbedaan petunjuk definisi dan contoh?
3. Mengapa kata *whereas* dapat menjadi petunjuk kontras?
4. Mengapa dugaan arti perlu diuji kembali dalam kalimat?
5. Apa yang sebaiknya dilakukan jika konteks tidak cukup jelas?

---

# WEEK 7 — REFERENCE TRACKING

## 1. Tujuan belajar

Siswa diharapkan mampu:
1. Mengenali pronoun (kata ganti) dan demonstrative (kata penunjuk).
2. Menentukan antecedent (kata/frasa sebelumnya) dan referent (orang/benda/gagasan yang dirujuk).
3. Menggunakan petunjuk jumlah, makna, peran kalimat, dan konteks lokal.
4. Menentukan apakah *this/that/these/those* merujuk pada noun atau pada gagasan/tindakan sebelumnya.
5. Menghindari tebakan berdasarkan kata terdekat saja.

## 2. Mengapa reference tracking penting?

Penulis sering tidak mengulang nama benda atau orang berkali-kali. Mereka menggunakan kata ganti seperti *he, she, it, they, them, their,* atau kata penunjuk seperti *this, that, these,* dan *those*. Pembaca perlu mengetahui kata atau gagasan yang dirujuk supaya hubungan antarkalimat tetap jelas.

## 3. Antecedent dan referent

- **Antecedent:** kata atau frasa yang disebut sebelumnya dan menjadi sumber rujukan pronoun.
- **Referent:** orang, benda, tempat, tindakan, atau gagasan yang dirujuk.

Contoh:

> Lina found a shell. She put it in a small box.

- *She* merujuk pada Lina.
- *It* merujuk pada a shell.
- Antecedent untuk *She* adalah Lina; antecedent untuk *it* adalah a shell.

## 4. Personal pronouns (kata ganti orang/benda)

| Pronoun | Rujukan umum | Contoh |
|---|---|---|
| he / him / his | laki-laki atau tokoh yang dikenalkan | Rafi lost his map. He looked for it. |
| she / her / hers | perempuan atau tokoh yang dikenalkan | Mira found a box. She opened it. |
| it / its | benda/hewan/hal yang telah disebut | The label is small. It is clear. |
| they / them / their | lebih dari satu orang/benda; dalam penggunaan modern dapat juga menjadi singular they | The students brought books. They placed them on a shelf. |

Periksa jumlah, peran dalam kalimat, dan makna. Jangan memilih hanya berdasarkan jarak kata.

## 5. Demonstratives (kata penunjuk)

| Kata | Penggunaan umum | Contoh |
|---|---|---|
| this | satu hal dekat / gagasan yang sedang ditunjuk | This rule is important. |
| that | satu hal lebih jauh / hal yang sudah disebut | That box is for paper. |
| these | beberapa hal dekat | These books are new. |
| those | beberapa hal lebih jauh / yang telah disebut | Those are the forms. |

Kata penunjuk dapat merujuk pada satu kata benda, satu frasa, atau satu gagasan/tindakan dalam kalimat sebelumnya.

Contoh rujukan gagasan:

> The team checked the dates and corrected two mistakes. This made the display more accurate.

*This* merujuk pada tindakan memeriksa tanggal dan mengoreksi kesalahan, bukan hanya satu benda.

## 6. Langkah reference tracking

1. Tandai pronoun atau demonstrative yang ditanyakan.
2. Baca kalimat itu dan kalimat sebelumnya.
3. Cari calon antecedent atau gagasan yang dirujuk.
4. Periksa kecocokan jumlah (singular/plural), peran (pelaku/objek/tempat), dan makna.
5. Ganti kata rujukan dengan calon referent.
6. Baca ulang: apakah kalimat tetap masuk akal?

Jika ada dua calon yang tampak mungkin, baca konteks yang lebih luas. Jangan memaksakan jawaban jika teks memang ambigu; soal yang disusun FRTS harus menyediakan satu rujukan yang dapat dipertanggungjawabkan.

## 7. Kosakata inti dan perluasan

Kosakata baru W7:
- **antecedent (n.)** — kata/frasa yang disebut sebelumnya dan dirujuk pronoun.
- **referent (n.)** — orang, benda, atau gagasan yang dirujuk.
- **pronoun (n.)** — kata ganti.
- **demonstrative (n./adj.)** — bentuk penunjuk seperti *this, that, these,* dan *those*.
- **preceding (adj.)** — yang mendahului/sebelumnya.
- **following (adj.)** — yang mengikuti/sesudahnya.
- **substitute (v./n.)** — menggantikan/pengganti.
- **indicate (v.)** — menunjukkan/menandakan.

Kata kumulatif yang diulang: *specific, detail, sequence, record, identify, mention, available,* dan kata dari W5–W6.

## 8. Pemeriksaan mandiri

1. Apa perbedaan antecedent dan referent?
2. Dalam “The students found a map. They read it,” apa rujukan *they* dan *it*?
3. Apakah *this* selalu merujuk pada satu noun terdekat?
4. Mengapa jumlah kata benda penting ketika memilih referent?
5. Apa yang harus dilakukan jika rujukan belum jelas dari satu kalimat?

---

# WEEK 8 — INFERENCE AND TEXTUAL EVIDENCE

## 1. Tujuan belajar

Siswa diharapkan mampu:
1. Membedakan explicit information (informasi yang disebut langsung) dan implied information (informasi yang disiratkan).
2. Membuat inference (inferensi/kesimpulan wajar) dari petunjuk teks.
3. Memilih textual evidence (bukti tekstual) yang mendukung kesimpulan.
4. Membedakan inferensi yang didukung dengan assumption (anggapan yang belum terbukti).
5. Menggunakan bahasa hati-hati seperti *may, might, could,* atau *likely* ketika bukti tidak menyatakan kepastian.

## 2. Apa itu inference?

**Inference (inferensi)** adalah kesimpulan wajar yang dibuat dengan menggabungkan petunjuk dalam teks dan pengetahuan latar yang relevan. Jawaban inferensi tidak selalu tertulis dengan kata yang sama, tetapi harus tetap didukung bukti bacaan.

Contoh:

> Rina came into the room carrying a wet umbrella. She placed it near the door and took off her raincoat.

Teks tidak menyatakan “It was raining outside.” Namun pembaca dapat menyimpulkan bahwa Rina kemungkinan datang dari luar saat hujan, karena membawa payung basah dan jas hujan.

## 3. Fakta, inferensi, dan asumsi

- **Explicit fact (fakta eksplisit):** informasi tertulis langsung dalam teks.
- **Reasonable inference (inferensi wajar):** kesimpulan yang didukung satu atau beberapa petunjuk tekstual dan pengetahuan relevan.
- **Assumption (anggapan):** dugaan yang belum memiliki bukti memadai. Asumsi bisa benar atau salah, tetapi belum boleh dinyatakan sebagai kesimpulan.

Contoh:

Teks: *Nadia checked the clock several times, held her note cards tightly, and paused when her teacher called her name.*

- Fakta: Nadia memeriksa jam beberapa kali dan memegang kartu catatan.
- Inferensi wajar: Nadia mungkin merasa gugup atau belum yakin.
- Asumsi tanpa bukti: Nadia pasti tidak belajar sama sekali.

## 4. Routine menjawab soal inference

1. Baca pertanyaan dan tentukan apa yang perlu disimpulkan.
2. Temukan satu atau lebih petunjuk teks.
3. Hubungkan petunjuk dengan pengetahuan latar yang benar-benar relevan.
4. Buat kesimpulan yang paling masuk akal dan tidak melebihi bukti.
5. Tunjukkan kalimat atau frasa yang mendukung.
6. Periksa tingkat kepastian: apakah teks membuktikan, menyiratkan, atau hanya memungkinkan?

## 5. Menghindari over-inference

Jangan:
- Mengubah *may/could/likely* menjadi *definitely/always*.
- Menebak niat tokoh tanpa petunjuk.
- Menggunakan pengalaman pribadi sebagai pengganti bukti teks.
- Menambah sebab yang tidak disebut atau tidak didukung.
- Menganggap satu contoh membuktikan semua keadaan.

Jika pilihan jawaban lebih luas atau lebih pasti daripada teks, periksa kembali. Kesimpulan terbaik biasanya yang paling sesuai dengan bukti dan tidak berlebihan.

## 6. Kosakata inti dan perluasan

Kosakata baru W8:
- **imply (v.)** — menyiratkan; *The writer implies that the character is worried.*
- **hesitate (v.)** — ragu-ragu/berhenti sejenak karena belum yakin; *She hesitated before answering.*
- **glance (v./n.)** — melirik/pandangan sekilas; *He glanced at the clock.*
- **relieved (adj.)** — lega; *She felt relieved after the presentation.*
- **conclude (v.)** — menyimpulkan; *The team will conclude after checking the data.*
- **assumption (n.)** — anggapan yang belum tentu terbukti; *Do not treat an assumption as a fact.*
- **likely (adj./adv.)** — mungkin besar/berpeluang; *The quieter room likely helped.*
- **uncertain (adj.)** — belum pasti/tidak yakin; *The cause is still uncertain.*

Kata kumulatif yang diulang: *specific, reason, detail, purpose, sequence, record,* serta kosakata W5–W7.

## 7. Pemeriksaan mandiri

1. Apa perbedaan explicit fact dan inference?
2. Mengapa inferensi harus mempunyai bukti tekstual?
3. Apa perbedaan inference dan assumption?
4. Mengapa kata *likely* tidak sama dengan *definitely*?
5. Bagaimana cara menghindari kesimpulan yang terlalu jauh?

---

# PART B — TEACHER GUIDES

## Prinsip umum pertemuan tatap muka

Setiap pertemuan tepat 60 menit. Penjelasan/pemodelan guru maksimal 30 menit; minimal 30 menit digunakan untuk praktik siswa, umpan balik, dan refleksi. Guru tidak perlu membaca seluruh modul.

### WEEK 5 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Aktivasi: minta siswa membedakan topic, main idea, dan purpose dari contoh singkat W1. |
| 4–10 | Jelaskan gist sebagai inti ringkas satu bagian teks. |
| 10–17 | Modelkan langkah menemukan siapa/apa yang dibahas dan informasi terpenting. |
| 17–23 | Bandingkan gist yang terlalu sempit, terlalu luas, dan tepat. |
| 23–27 | Modelkan pemilahan detail relevan dan tidak relevan. |
| 27–30 | Quick check: siswa menyebut satu pokok dan satu detail yang dapat dihilangkan. |
| 30–40 | Pasangan membuat gist dari paragraf pendek yang belum digunakan di modul. |
| 40–49 | Siswa memilih supporting details dan menghapus satu detail tidak relevan. |
| 49–56 | Umpan balik berbasis bukti. |
| 56–60 | Exit ticket dan pengingat latihan online. |

Kesalahan umum: menyalin kalimat pertama, memasukkan semua detail, menambahkan opini, atau mengubah kata *may* menjadi *always*. Tindak lanjut: gunakan template “Teks ini terutama membahas ___; hal terpentingnya adalah ___.”

### WEEK 6 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall: sinonim/parafrasa W4 dan makna kata dalam konteks. |
| 4–10 | Jelaskan context clues dan keterbatasannya. |
| 10–18 | Modelkan definition dan example clues. |
| 18–24 | Modelkan synonym/restatement dan antonym/contrast clues. |
| 24–28 | Modelkan general context dan uji makna dalam kalimat. |
| 28–30 | Quick check: siswa menunjukkan petunjuk, bukan hanya menyebut tebakan. |
| 30–40 | Siswa menandai petunjuk konteks pada tiga kalimat pendek. |
| 40–49 | Pasangan mengusulkan makna dan menguji penggantiannya dalam kalimat. |
| 49–56 | Bahas satu contoh ketika konteks belum cukup jelas. |
| 56–60 | Exit ticket dan pengingat sesi online. |

Kesalahan umum: menganggap satu kata selalu memiliki satu makna, menebak dari kemiripan ejaan, menganggap context clues selalu cukup. Tindak lanjut: beri glosarium untuk kata yang penting tetapi petunjuknya terbatas.

### WEEK 7 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall: Question-First dan membaca kalimat sekitar. |
| 4–10 | Jelaskan pronoun dan antecedent menggunakan contoh dua kalimat. |
| 10–17 | Modelkan rujukan it/they/them dengan pemeriksaan jumlah dan peran. |
| 17–23 | Jelaskan demonstratives this/that/these/those. |
| 23–27 | Modelkan this yang merujuk pada tindakan/gagasan sebelumnya. |
| 27–30 | Quick check: siswa mengganti pronoun dengan referent dan membaca ulang. |
| 30–40 | Pasangan mencari referent dalam paragraf pendek. |
| 40–49 | Siswa membedakan antecedent dan referent. |
| 49–56 | Bahas distractor yang hanya memilih noun terdekat. |
| 56–60 | Exit ticket dan pengingat sesi online. |

Kesalahan umum: memilih kata benda terdekat, tidak memeriksa tunggal/jamak, menganggap this selalu merujuk pada benda. Tindak lanjut: tandai pronoun dengan satu warna dan antecedent/referent dengan warna lain.

### WEEK 8 — Teacher Guide (60 menit)

| Menit | Kegiatan |
|---:|---|
| 0–4 | Recall: jawaban langsung dan bukti dari W2. |
| 4–10 | Bedakan fakta eksplisit, inferensi, dan asumsi. |
| 10–17 | Modelkan inferensi dari dua petunjuk tindakan tokoh. |
| 17–23 | Modelkan mengutip/menunjuk bukti tekstual. |
| 23–27 | Bandingkan bahasa hati-hati: may/likely/could vs definitely/always. |
| 27–30 | Quick check: siswa membedakan kesimpulan yang didukung dan asumsi. |
| 30–40 | Pasangan menyusun inferensi dari narasi pendek dan memberi dua bukti. |
| 40–49 | Siswa menilai apakah pilihan terlalu luas atau terlalu pasti. |
| 49–56 | Umpan balik: minta siswa menyebutkan “petunjuk → kesimpulan”. |
| 56–60 | Refleksi dan exit ticket. |

Kesalahan umum: menggunakan pengalaman pribadi sebagai satu-satunya dasar, membaca kemungkinan sebagai kepastian, menebak niat tokoh. Tindak lanjut: berikan kerangka “Saya menyimpulkan ___ karena teks menyebut ___ dan ___.”

---

# PART C — VOCABULARY RECYCLE REGISTER

Setiap sesi online memiliki 10 target cards: tepat 4 NEW dan 6 RECYCLED. Rasio dihitung berdasarkan target cards yang didefinisikan per sesi, bukan seluruh kata yang muncul di passage.

| Sesi | 4 kata baru | 6 kata yang diulang |
|---|---|---|
| W5 Online 01 | overview, canopy, absorb, surface | purpose, record, available, sequence, specific, general |
| W5 Online 02 | summary, relevant, contribute, layer | overview, canopy, absorb, surface, purpose, record |
| W6 Online 01 | reservoir, scarce, capture, adequate | summary, relevant, contribute, layer, conserve, supply |
| W6 Online 02 | pollutant, filter, runoff, prevent | reservoir, scarce, capture, adequate, protect, reduce |
| W7 Online 01 | antecedent, referent, pronoun, demonstrative | specific, detail, sequence, refer to, identify, record |
| W7 Online 02 | preceding, following, substitute, indicate | antecedent, referent, pronoun, demonstrative, available, mention |
| W8 Online 01 | imply, hesitate, glance, relieved | specific, reason, detail, purpose, sequence, record |
| W8 Online 02 | conclude, assumption, likely, uncertain | imply, hesitate, glance, relieved, specific, reason |

### Prinsip vocabulary cards

- Berikan kelas kata dan arti Bahasa Indonesia.
- Berikan contoh kalimat orisinal yang alami.
- Berikan sinonim/related term hanya jika cocok dalam konteks.
- Berikan antonim hanya jika ada pasangan makna yang benar; gunakan “—” jika tidak ada antonim langsung.
- Jangan menilai siswa berdasarkan sinonim/antonim yang belum diajarkan.
- Kata lama harus digunakan dalam konteks baru, bukan menyalin soal yang sama.

---

# PART D — ASSESSMENT ALIGNMENT AND ONLINE BLUEPRINT

## Komposisi setiap sesi

- 7 soal reading comprehension.
- 4 soal vocabulary.
- 1 soal strategy transfer.
- Total 12 soal.
- 10 vocabulary targets: 4 NEW + 6 RECYCLED.
- Seluruh soal MCQ empat pilihan dengan satu jawaban paling tepat pada skema produksi awal ini.

## Peta kompetensi

| Minggu | Kompetensi | Kinerja terukur | Bukti jawaban |
|---:|---|---|---|
| 5 | Main idea/gist | Memilih/merumuskan inti bagian teks | Pokok bahasan + informasi paling penting |
| 5 | Relevant detail | Membedakan informasi penting dan tidak relevan | Detail yang mendukung gist |
| 5 | Summary accuracy | Menghindari ringkasan terlalu sempit/luas | Cakupan dan kesetiaan pada teks |
| 6 | Definition/Explanation clues | Mengambil arti dari definisi langsung | Frasa penjelas |
| 6 | Synonym/Restatement clues | Mengenali penyebutan ulang | Kata/frasa bermakna dekat |
| 6 | Antonym/Contrast clues | Menggunakan hubungan kontras | Penanda kontras dan ide pembanding |
| 6 | Example/General clues | Menggabungkan contoh dan konteks umum | Daftar contoh atau informasi sekitar |
| 7 | Personal pronoun reference | Menentukan antecedent/referent | Kecocokan jumlah, makna, peran |
| 7 | Demonstrative reference | Menentukan rujukan this/that/these/those | Noun, frasa, tindakan, atau gagasan sebelumya |
| 7 | Local context | Menguji rujukan dengan kalimat sekitar | Hubungan antarkalimat |
| 8 | Explicit vs implied | Membedakan fakta tertulis dan kesimpulan | Kalimat eksplisit vs petunjuk gabungan |
| 8 | Inference with evidence | Membuat kesimpulan yang didukung | Satu atau lebih bukti tekstual |
| 8 | Avoid assumptions | Menolak klaim berlebihan | Kesesuaian tingkat kepastian dengan bukti |

## Distribusi kesulitan internal

| Sesi | Mudah | Berkembang | Menengah | Total |
|---|---:|---:|---:|---:|
| W5 Online 01 | 4 | 5 | 3 | 12 |
| W5 Online 02 | 3 | 5 | 4 | 12 |
| W6 Online 01 | 3 | 4 | 5 | 12 |
| W6 Online 02 | 3 | 4 | 5 | 12 |
| W7 Online 01 | 2 | 5 | 5 | 12 |
| W7 Online 02 | 2 | 4 | 6 | 12 |
| W8 Online 01 | 2 | 4 | 6 | 12 |
| W8 Online 02 | 1 | 4 | 7 | 12 |

Label mudah/berkembang/menengah adalah estimasi desain internal. Belum dikalibrasi secara psikometrik dan tidak boleh disebut sertifikasi CEFR. Bacaan yang diinspirasi tingkat B1 bukan otomatis bacaan B1 tervalidasi.

---

# PART E — REFERENCE REGISTER AND DESIGN LIMITATIONS

**Referensi utama yang diperiksa:**

1. **Vaughn et al. (2022), IES/WWC — Providing Reading Interventions for Students in Grades 4–9, Recommendation 3 Part C.** Gist merupakan sintesis informasi terpenting dari bagian pendek teks; siswa dibimbing mengenali siapa/apa yang dibahas, informasi utama, dan membedakan informasi relevan/tidak relevan. https://ies.ed.gov/ncee/WWC/Docs/PracticeGuide/WWC-practice-guide-reading-intervention-full-text.pdf
2. **IES — PRISMS Toolkit, Module 4: Asking and Answering Questions and Determining the Gist.** Mendukung pemodelan, latihan kolaboratif, umpan balik, dan peralihan bertahap menuju kerja mandiri. https://ies.ed.gov/ncee/rel/reading-intervention-grades-6-8
3. **The Reading Teacher’s Sourcebook — Types of Context Clues (Baumann et al., 2005).** Memaparkan petunjuk definisi, sinonim, antonim, contoh, dan konteks umum. https://d1yqpar94jqbqm.cloudfront.net/documents/The%20Reading%20Teacher%27s%20Sourcebook%20Effective%20Instruction_Vocabulary_0.pdf
4. **Gibbs (2020), Iowa Reading Research Center — Using Context Clues to Understand New Words.** Menjelaskan petunjuk dapat ada pada kalimat yang sama atau kalimat sebelum/sesudah dan perlu diperiksa dalam konteks. https://irrc.education.uiowa.edu/blog/2020/10/supporting-your-childrens-and-teens-home-learning-using-context-clues-understand-new
5. **Barth & Elleman (2017), Evaluating the Impact of a Multistrategy Inference Intervention for Middle-Grade Struggling Readers.** Studi intervensi awal pada pembaca middle-grade; relevan untuk pentingnya instruksi eksplisit dan penggunaan petunjuk teks, tetapi tidak membuktikan setiap urutan FRTS. https://pubs.asha.org/doi/10.1044/2016_LSHSS-16-0041
6. **2024 study, A Randomized Controlled Trial of Tutor- and Computer-Delivered Inferential Comprehension Interventions for Middle School Students with Reading Difficulties.** Deskripsi intervensi mencakup pronoun reference, hubungan teks, dan latihan inferensi. Halaman penerbit memiliki keterbatasan akses; metadata/abstrak digunakan secara hati-hati. https://doi.org/10.1080/10888438.2024.2331517
7. **British Council LearnEnglish Teens — B1 Graded Reading.** Acuan variasi cerita dan artikel untuk pembelajar menengah; bukan sertifikasi level stimulus FRTS. https://learnenglishteens.britishcouncil.org/study-break/reading-zone/b1-graded-reading
8. **British Council LearnEnglish Teens — B1 Reading.** Acuan variasi format bacaan. https://learnenglishteens.britishcouncil.org/skills/reading/b1-reading

### Batas klaim

- Panduan dan penelitian di atas mendukung pengajaran eksplisit gist, kosakata dalam konteks, pemahaman rujukan, dan inferensi berbasis teks; tidak membuktikan bahwa susunan 19 minggu FRTS adalah satu-satunya atau urutan paling unggul.
- Sebagian studi berfokus pada pembaca dengan kesulitan membaca, bukan persis populasi SMP Indonesia. Terapkan secara adaptif.
- Level bacaan FRTS adalah estimasi dan perlu uji keterbacaan oleh guru/siswa sasaran.
- Semua teks stimulus dalam question bank dibuat orisinal berdasarkan tema/fakta referensi. Tidak ada klaim bahwa stimulus merupakan teks resmi British Council atau Cambridge.

---

# PART F — ISSUE LOG AND QA STATUS

| ID | Prioritas | Masalah yang perlu diperhatikan | Status |
|---|---|---|---|
| B2-ISS-01 | HIGH | Estimasi kesulitan perlu diuji dengan siswa kelas 7–9 | OPEN — classroom pilot required |
| B2-ISS-02 | HIGH | Skema JSON belum dipetakan ke schema/API aplikasi | OPEN — integration mapping required |
| B2-ISS-03 | MEDIUM | Reference tracking harus diperiksa agar setiap pronoun/demonstrative memiliki satu referen yang jelas | CHECKED IN DRAFT; independent language QA required |
| B2-ISS-04 | MEDIUM | Context clues bukan metode yang selalu berhasil; sediakan glosarium saat konteks tidak cukup | INCLUDED; teacher review required |
| B2-ISS-05 | MEDIUM | Inference harus dibedakan dari asumsi dan overclaim | INCLUDED; independent QA required |
| B2-ISS-06 | MEDIUM | Vocabulary cards perlu ditinjau register, kelas kata, dan kelaziman sinonim/antonim | DRAFT; dictionary/teacher verification required |
| B2-ISS-07 | LOW | Bacaan orisinal harus menjalani copy-edit Bahasa Inggris dan penghitungan kata final | OPEN |

Status dokumen: **DRAFT FOR OWNER REVIEW — NOT CLASSROOM VALIDATED.**

---

# PART G — REVISION HISTORY

| Versi | Tanggal | Perubahan |
|---|---|---|
| 0.1 | 15 November 2026 | Draf terpadu W5–W8; modul siswa, panduan guru, kosakata kumulatif, blueprint 8 sesi, 96 soal dan payload siswa/guru dibuat untuk ditinjau. |
